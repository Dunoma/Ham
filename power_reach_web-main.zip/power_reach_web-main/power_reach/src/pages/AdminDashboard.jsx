import { useEffect } from 'react';
import { useAdmin } from '../context/AdminContext';
import { useLocation } from 'react-router-dom';
import { Users, AlertTriangle, Activity, Briefcase } from 'lucide-react';
import { formatDateTime } from '../utils/dateFormat';

export default function AdminDashboard() {
    const { user, stats, recentActivity, loading, fetchDashboardData } = useAdmin();
    const location = useLocation();

    useEffect(() => {
        if (user && location.pathname === '/admin/dashboard') {
            fetchDashboardData();
        }
    }, [location.pathname, user]);

    if (loading) {
        return (
            <div className="flex items-center justify-center h-full">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
            </div>
        );
    }

    const statCards = [
        {
            title: 'Total Users',
            value: stats.totalUsers,
            icon: Users,
            color: 'bg-blue-500',
            description: 'Registered Customers'
        },
        {
            title: 'Active Staff',
            value: stats.activeStaff,
            icon: Briefcase,
            color: 'bg-indigo-500', // Or primary-600 to match agent dashboard more closely if desired
            description: 'Agents & Engineers'
        },
        {
            title: 'Open Faults',
            value: stats.openFaults,
            icon: AlertTriangle,
            color: 'bg-orange-500',
            description: 'Action Required',
            urgent: stats.openFaults > 5
        },
        {
            title: 'System Health',
            value: stats.systemHealth,
            icon: Activity,
            color: 'bg-green-500',
            description: 'Operational Status'
        }
    ];

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
                    <p className="text-gray-600 mt-1">Welcome back, {user?.name || 'Administrator'}</p>
                </div>
            </div>

            {/* Stats Grid - Matching Agent Dashboard Styling */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {statCards.map((stat, index) => {
                    const Icon = stat.icon;
                    return (
                        <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition text-left">
                            <div className="flex items-center justify-between mb-4">
                                <div className={`${stat.color} p-3 rounded-lg`}>
                                    <Icon className="w-6 h-6 text-white" />
                                </div>
                                {stat.urgent && (
                                    <span className="px-2 py-1 bg-red-100 text-red-700 text-xs font-bold rounded-full animate-pulse">
                                        High Load
                                    </span>
                                )}
                            </div>
                            <h3 className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</h3>
                            <p className="text-sm text-gray-600">{stat.title}</p>
                            {/* Optional Description if we want to keep it, but Agent Dashboard doesn't show description. 
                                The user said "Use the exact same Stats Card component...".
                                But Agent Dashboard DOES NOT have description in the loop, just Title/Value/Icon. 
                                However, Admin data might benefit from description. I'll keep it subtle or remove to match EXACTLY if strict.
                                I'll keep it for now as it adds value for Admin context.
                             */}
                        </div>
                    )
                })}
            </div>

            {/* Recent Activity Feed - Matching Agent's "Recent Reports" table styling */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-semibold text-gray-900">System Activity Log</h2>
                    <button className="text-primary-600 hover:text-primary-700 text-sm font-medium">View All</button>
                </div>
                <div className="space-y-3">
                    {recentActivity.length === 0 ? (
                        <p className="text-gray-500 text-center py-4">No recent activity.</p>
                    ) : (
                        recentActivity.map((log) => (
                            <div key={log.id} className="flex items-start gap-3 p-3 hover:bg-gray-50 rounded-lg transition">
                                <div className={`mt-1 p-2 rounded-full flex-shrink-0 ${log.userType === 'admin' ? 'bg-red-100 text-red-600' :
                                        log.userType === 'agent' ? 'bg-blue-100 text-blue-600' :
                                            log.userType === 'engineer' ? 'bg-yellow-100 text-yellow-600' :
                                                'bg-gray-100 text-gray-600'
                                    }`}>
                                    <Activity className="w-4 h-4" />
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2 mb-1">
                                        <p className="font-medium text-gray-900 truncate">{log.action}</p>
                                    </div>
                                    <p className="text-sm text-gray-600 truncate">{log.description}</p>
                                    <p className="text-xs text-gray-500 mt-1">
                                        {formatDateTime(log.timestamp)} • <span className="capitalize">{log.userType}</span>
                                    </p>
                                </div>
                            </div>
                        ))
                    )}
                </div>
            </div>
        </div>
    );
}
