import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAgent } from '../context/AgentContext';
import { ArrowLeft, FileText, Send } from 'lucide-react';
import UserAvatar from '../components/UserAvatar';
import ReportFormModal from '../components/ReportFormModal';
import UserProfileModal from '../components/UserProfileModal';
import { formatDateTime } from '../utils/dateFormat';

export default function ChatView() {
  const params = useParams();
  // Support both chatId and messageId for backward compatibility
  const chatId = params.chatId || params.messageId;
  const navigate = useNavigate();
  const { user, users, chats, messages, addMessage, loading } = useAgent();
  const [newMessage, setNewMessage] = useState('');
  const [showReportForm, setShowReportForm] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const messagesEndRef = useRef(null);

  // Constant UUID for Sparky
  const SPARKY_BOT_ID = 'sparky-bot-id';

  // Find the chat
  const chat = chats && chats.length > 0 ? chats.find((c) => c.id === chatId) : null;
  
  // Get all messages for this conversation (same chatId)
  const conversationMessages = chat && messages && messages.length > 0
    ? messages.filter((m) => m.chatId === chatId).sort(
        (a, b) => new Date(a.createdAt) - new Date(b.createdAt)
      )
    : [];

  const customer = chat && users && users.length > 0
    ? users.find((u) => u.id === chat.customerId)
    : null;

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [conversationMessages]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !chat || !user) return;

    try {
      await addMessage({
        chatId: chat.id,
        senderId: user.id, // Agent ID
        content: newMessage,
        isSparkyReport: false,
        status: 'claimed',
        isRead: false,
      });
      setNewMessage('');
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  const getReportPrefillData = () => {
    if (!chat || !customer) return null;
    const lastCustomerMessage = conversationMessages
      .filter((m) => m.senderId === customer.id)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];
    return {
      userId: customer.readableId || customer.id,
      title: `Report from ${customer.name}`,
      description: lastCustomerMessage?.content || '',
      faultType: 'Power Outage',
      isSparkyReport: false,
    };
  };

  // Show loading state while data is being fetched
  if (loading) {
    return (
      <div className="p-6">
        <div className="text-center py-12">
          <p className="text-gray-500">Loading conversation...</p>
        </div>
      </div>
    );
  }

  // Show error if chat or customer not found (only after loading is complete)
  if (!loading && (!chat || !customer)) {
    return (
      <div className="p-6">
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg mb-2">Conversation not found</p>
          <p className="text-gray-400 text-sm mb-4">The chat you're looking for doesn't exist or has been removed.</p>
          <button
            onClick={() => navigate('/agent/messages')}
            className="mt-4 px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg transition"
          >
            Back to Messages
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col" style={{ height: 'calc(100vh - 4rem)' }}>
      {/* Chat Header */}
      <div className="bg-white border-b border-gray-200 px-4 sm:px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3 sm:gap-4 flex-1 min-w-0">
          <button
            onClick={() => navigate('/agent/messages')}
            className="p-2 hover:bg-gray-100 rounded-lg transition shrink-0"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="shrink-0">
            <UserAvatar
              userId={customer.id}
              userName={customer.name}
              profilePicture={customer.profile_picture}
              size="md"
              onClick={() => setSelectedUserId(customer.id)}
            />
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="font-semibold text-gray-900 truncate">{customer.name}</h2>
            <p className="text-sm text-gray-500 truncate">{customer.location}</p>
          </div>
        </div>
        <button
          onClick={() => setShowReportForm(true)}
          className="flex items-center justify-center gap-2 bg-accent-500 hover:bg-accent-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition w-full sm:w-auto shrink-0"
        >
          <FileText className="w-4 h-4" />
          File Report
        </button>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto bg-gray-50 p-6">
        <div className="max-w-4xl mx-auto space-y-4">
          {conversationMessages.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">No messages yet. Start the conversation!</p>
            </div>
          ) : (
            conversationMessages.map((message) => {
            // Determine sender: Customer, Agent, or Sparky
            const isSparky = message.senderId === SPARKY_BOT_ID;
            const isAgent = message.senderId === user?.id;
            const isCustomer = !isSparky && !isAgent;
            
            return (
              <div
                key={message.id}
                className={`flex gap-3 ${isAgent || isSparky ? 'flex-row-reverse' : ''}`}
              >
                {isCustomer && (
                  <UserAvatar
                    userId={customer.id}
                    userName={customer.name}
                    profilePicture={customer.profile_picture}
                    size="sm"
                  />
                )}
                <div
                  className={`flex-1 ${
                    isAgent || isSparky ? 'flex justify-end' : ''
                  }`}
                >
                  <div
                    className={`inline-block max-w-[70%] rounded-lg px-4 py-2 ${
                      isAgent || isSparky
                        ? 'bg-primary-600 text-white'
                        : 'bg-white border border-gray-200 text-gray-900'
                    }`}
                  >
                    <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                    <p
                      className={`text-xs mt-1 ${
                        isAgent || isSparky ? 'text-primary-100' : 'text-gray-500'
                      }`}
                    >
                      {formatDateTime(message.createdAt)}
                    </p>
                  </div>
                </div>
              </div>
            );
          })
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Message Input */}
      <div className="bg-white border-t border-gray-200 px-6 py-4">
        <form onSubmit={handleSendMessage} className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3">
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type a message..."
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none"
            />
            <button
              type="submit"
              disabled={!newMessage.trim()}
              className="p-2 bg-primary-600 hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg transition"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </form>
      </div>

      {/* Report Form Modal */}
      {showReportForm && (
        <ReportFormModal
          onClose={() => setShowReportForm(false)}
          prefillData={getReportPrefillData()}
        />
      )}

      {/* User Profile Modal */}
      {selectedUserId && (
        <UserProfileModal
          userId={selectedUserId}
          onClose={() => setSelectedUserId(null)}
        />
      )}
    </div>
  );
}

