import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAgent } from '../context/AgentContext';
import { Zap, Plus, Eye, Copy, Check, X, CheckCircle } from 'lucide-react';
import UserAvatar from '../components/UserAvatar';
import ReportFormModal from '../components/ReportFormModal';
import UserProfileModal from '../components/UserProfileModal';
import EngineerProfileModal from '../components/EngineerProfileModal';
import { formatDateTime } from '../utils/dateFormat';

export default function Reports() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { user, users, reports, engineers, updateReport } = useAgent();
  console.log(reports)
  const [showFormModal, setShowFormModal] = useState(false);
  
  // Initialize filter from URL query parameter or default to 'all'
  const [filter, setFilter] = useState(() => {
    const filterParam = searchParams.get('filter');
    const validFilters = ['all', 'sparky', 'agent', 'assigned', 'unassigned'];
    return validFilters.includes(filterParam) ? filterParam : 'all';
  });

  // Update filter when URL query parameter changes
  useEffect(() => {
    const filterParam = searchParams.get('filter');
    const validFilters = ['all', 'sparky', 'agent', 'assigned', 'unassigned'];
    if (filterParam && validFilters.includes(filterParam)) {
      setFilter(filterParam);
    }
  }, [searchParams]);

  // Update URL when filter changes (but don't add to history if it's the initial load)
  const handleFilterChange = (newFilter) => {
    setFilter(newFilter);
    setSearchParams({ filter: newFilter }, { replace: true });
  };
  const [selectedReport, setSelectedReport] = useState(null);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [selectedEngineerId, setSelectedEngineerId] = useState(null);
  const [forwardEngineerId, setForwardEngineerId] = useState('');
  const [copiedUserId, setCopiedUserId] = useState(null);
  const [showSuccessAnimation, setShowSuccessAnimation] = useState(false);
  const [selectedPriority, setSelectedPriority] = useState('');

  const filteredReports = reports.filter((report) => {
    if (filter === 'all') return true;
    if (filter === 'sparky') return report.isSparkyReport;
    if (filter === 'agent') return !report.isSparkyReport;
    if (filter === 'assigned') return report.assignedEngineerId !== null;
    if (filter === 'unassigned') return report.assignedEngineerId === null;
    return true;
  });

  // Calculate filter counts
  const filterCounts = {
    all: reports.length,
    sparky: reports.filter((r) => r.isSparkyReport).length,
    agent: reports.filter((r) => !r.isSparkyReport).length,
    assigned: reports.filter((r) => r.assignedEngineerId !== null).length,
    unassigned: reports.filter((r) => r.assignedEngineerId === null).length,
  };

  const sortedReports = [...filteredReports].sort(
    (a, b) => new Date(b.createdAt) - new Date(a.createdAt)
  );

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high':
        return 'bg-red-100 text-red-700';
      case 'medium':
        return 'bg-yellow-100 text-yellow-700';
      case 'low':
        return 'bg-green-100 text-green-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const handleForwardToEngineer = async () => {
    if (!forwardEngineerId.trim()) {
      alert('Please enter an Engineer UUID or ID');
      return;
    }

    if (!selectedPriority && !selectedReport.priority) {
      alert('Please select a priority before assigning to an engineer.');
      return;
    }

    const cleanId = forwardEngineerId.trim();
    const engineer = engineers.find((e) => e.id === cleanId || e.readableId === cleanId);
    if (!engineer) {
      alert('Engineer not found. Please check the ID.');
      return;
    }

    try {
      await updateReport(selectedReport.id, {
        assignedEngineerId: engineer.id,
        assignedBy: user?.id,
        priority: selectedPriority || selectedReport.priority,
        status: 'in_progress',
      });
      
      // Show success animation
      setShowSuccessAnimation(true);
      setTimeout(() => {
        setShowSuccessAnimation(false);
        setSelectedReport(null);
        setForwardEngineerId('');
        setSelectedPriority('');
      }, 2000);
    } catch (error) {
      alert('Failed to forward report. Please try again.');
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Reports</h1>
          <p className="text-gray-600 mt-1">Manage and track customer reports</p>
        </div>
        <button
          onClick={() => setShowFormModal(true)}
          className="flex items-center justify-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg transition w-full sm:w-auto"
        >
          <Plus className="w-5 h-5" />
          File Report
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 overflow-x-auto whitespace-nowrap no-scrollbar">
        <div className="flex flex-nowrap md:flex-wrap items-center gap-2">
          <span className="text-sm font-medium text-gray-700 mr-2">Filter:</span>
          {['all', 'sparky', 'agent', 'assigned', 'unassigned'].map((filterType) => (
            <button
              key={filterType}
              onClick={() => handleFilterChange(filterType)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                filter === filterType
                  ? 'bg-primary-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {filterType === 'all'
                ? `All (${filterCounts.all})`
                : filterType === 'sparky'
                ? `Sparky (${filterCounts.sparky})`
                : filterType === 'agent'
                ? `Manual (${filterCounts.agent})`
                : filterType === 'assigned'
                ? `Assigned (${filterCounts.assigned})`
                : `Unassigned (${filterCounts.unassigned})`}
            </button>
          ))}
        </div>
      </div>

      {/* Reports List */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        {sortedReports.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-gray-500 text-lg">No reports found</p>
            <button
              onClick={() => setShowFormModal(true)}
              className="mt-4 text-primary-600 hover:text-primary-700 font-medium"
            >
              Create your first report
            </button>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {sortedReports.map((report) => (
              <div
                key={report.id}
                className="p-6 hover:bg-gray-50 transition"
              >
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0">
                    <UserAvatar
                      userId={report.userId}
                      userName={report.userName}
                      profilePicture={users.find((u) => u.id === report.userId)?.profile_picture}
                      size="md"
                      onClick={() => setSelectedUserId(report.userId)}
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          {report.isSparkyReport && (
                            <Zap className="w-4 h-4 text-accent-500" />
                          )}
                          <h3 className="text-lg font-semibold text-gray-900">
                            {report.title}
                          </h3>
                          {report.assignedEngineerId && (
                            <CheckCircle className="w-4 h-4 text-green-500" />
                          )}
                        </div>
                        <p className="text-gray-600 mb-2">{report.description}</p>
                        <div className="flex flex-wrap items-center gap-2 text-sm text-gray-500">
                          <div className="flex items-center gap-1 min-w-min">
                            <span className="truncate">{report.userName}</span>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                navigator.clipboard.writeText(report.userId);
                                setCopiedUserId(report.userId);
                                setTimeout(() => setCopiedUserId(null), 2000);
                              }}
                              className="p-1 hover:bg-gray-200 rounded transition"
                              title="Copy User ID"
                            >
                              {copiedUserId === report.userId ? (
                                <Check className="w-3 h-3 text-green-600" />
                              ) : (
                                <Copy className="w-3 h-3 text-gray-400" />
                              )}
                            </button>
                          </div>
                          <span className="hidden sm:inline">•</span>
                          <span className="truncate">{report.userLocation}</span>
                          <span className="hidden sm:inline">•</span>
                          <span className="truncate">{report.faultType}</span>
                          <span className="hidden sm:inline">•</span>
                          <span className="truncate">{formatDateTime(report.createdAt)}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0 w-full sm:w-auto justify-end">
                        {report.priority && (
                          <span
                            className={`px-3 py-1 text-xs font-medium rounded-full ${getPriorityColor(
                              report.priority
                            )}`}
                          >
                            {report.priority}
                          </span>
                        )}
                        <button
                          onClick={() => setSelectedReport(report)}
                          className="p-2 hover:bg-gray-100 rounded-lg transition"
                          title="View Details"
                        >
                          <Eye className="w-5 h-5 text-gray-600" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Report Form Modal */}
      {showFormModal && (
        <ReportFormModal onClose={() => setShowFormModal(false)} />
      )}

      {/* Report Details Modal */}
      {selectedReport && (
        <div className="fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]" style={{ margin: 0, padding: 0 }}>
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto m-4">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h2 className="text-2xl font-bold text-gray-900">Report Details</h2>
              <button
                onClick={() => {
                  setSelectedReport(null);
                  setForwardEngineerId('');
                }}
                className="p-2 hover:bg-gray-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-500">Title</label>
                <p className="text-gray-900 mt-1">{selectedReport.title}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Description</label>
                <p className="text-gray-900 mt-1">{selectedReport.description}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Fault Type</label>
                <p className="text-gray-900 mt-1">{selectedReport.faultType}</p>
              </div>
              {/* Priority Section */}
              {selectedReport.priority ? (
                <div>
                  <label className="text-sm font-medium text-gray-500">Priority</label>
                  <p className="text-gray-900 mt-1">{selectedReport.priority}</p>
                </div>
              ) : (
                <div>
                  <label className="text-sm font-medium text-gray-500">Priority</label>
                  <p className="text-gray-500 mt-1 italic">Not set</p>
                </div>
              )}

              {/* Attachments Section */}
              <div>
                <label className="text-sm font-medium text-gray-500">Attachments</label>
                <div className="mt-2 p-4 bg-gray-50 rounded-lg border border-gray-200">
                  <p className="text-sm text-gray-500">No attachments available</p>
                </div>
              </div>

              {/* Assigned Engineer Section */}
              {selectedReport.assignedEngineerId ? (
                <div>
                  <label className="text-sm font-medium text-gray-500">Assigned Engineer</label>
                  <div className="flex items-center gap-2 mt-1">
                    <UserAvatar
                      userId={selectedReport.assignedEngineerId}
                      userName={engineers.find((e) => e.id === selectedReport.assignedEngineerId)?.name || 'Unknown Engineer'}
                      profilePicture={engineers.find((e) => e.id === selectedReport.assignedEngineerId)?.profile_picture}
                      size="sm"
                      onClick={() => {
                        const engineer = engineers.find((e) => e.id === selectedReport.assignedEngineerId);
                        if (engineer) setSelectedEngineerId(engineer.id);
                      }}
                    />
                    <p className="text-gray-900">
                      {engineers.find((e) => e.id === selectedReport.assignedEngineerId)?.name || 'Unknown Engineer'}
                    </p>
                  </div>
                </div>
              ) : null}

              <div>
                <label className="text-sm font-medium text-gray-500">Customer</label>
                <div className="flex items-center gap-2 mt-1">
                  <UserAvatar
                    userId={selectedReport.userId}
                    userName={selectedReport.userName}
                    profilePicture={users.find((u) => u.id === selectedReport.userId)?.profile_picture}
                    size="sm"
                    onClick={() => setSelectedUserId(selectedReport.userId)}
                  />
                  <p className="text-gray-900">{selectedReport.userName}</p>
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Location</label>
                <p className="text-gray-900 mt-1">{selectedReport.userLocation}</p>
              </div>

              {/* Assignment Section - Only show if not assigned */}
              {!selectedReport.assignedEngineerId && (
                <div className="pt-4 border-t border-gray-200 space-y-4">
                  {/* Priority Selection - Show if no priority */}
                  {!selectedReport.priority && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Priority <span className="text-red-500">*</span>
                      </label>
                      <select
                        value={selectedPriority}
                        onChange={(e) => setSelectedPriority(e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none"
                      >
                        <option value="">Select Priority</option>
                        <option value="high">High</option>
                        <option value="medium">Medium</option>
                        <option value="low">Low</option>
                      </select>
                    </div>
                  )}
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Assign to Engineer
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={forwardEngineerId}
                        onChange={(e) => setForwardEngineerId(e.target.value)}
                        placeholder="Enter Engineer ID or UUID"
                        className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none"
                      />
                      <button
                        onClick={handleForwardToEngineer}
                        disabled={!selectedPriority && !selectedReport.priority}
                        className="px-4 py-2 bg-primary-600 hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg transition"
                      >
                        Assign
                      </button>
                    </div>
                    {!selectedPriority && !selectedReport.priority && (
                      <p className="text-xs text-red-500 mt-1">Please select a priority first</p>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Success Animation */}
      {showSuccessAnimation && (
        <div className="fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-50 flex items-center justify-center z-[10000]" style={{ margin: 0, padding: 0 }}>
          <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full mx-4 transform transition-all animate-bounce-in">
            <div className="text-center">
              <div className="relative inline-block mb-4">
                <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto animate-scale-pulse">
                  <svg
                    className="w-12 h-12 text-white animate-checkmark"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={3}
                      d="M5 13l4 4L19 7"
                    />
                  </svg>
                </div>
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-accent-500 rounded-full animate-ping"></div>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Report Forwarded!</h3>
              <p className="text-gray-600">The report has been successfully forwarded to the engineer.</p>
            </div>
          </div>
        </div>
      )}

      {/* User Profile Modal */}
      {selectedUserId && (
        <UserProfileModal
          userId={selectedUserId}
          onClose={() => setSelectedUserId(null)}
        />
      )}

      {/* Engineer Profile Modal */}
      {selectedEngineerId && (
        <EngineerProfileModal
          engineer={engineers.find((e) => e.id === selectedEngineerId)}
          onClose={() => setSelectedEngineerId(null)}
        />
      )}
    </div>
  );
}
