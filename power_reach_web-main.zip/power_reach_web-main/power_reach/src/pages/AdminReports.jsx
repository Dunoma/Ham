import { useState, useMemo, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { useAdmin } from '../context/AdminContext';
import {
    Search,
    MapPin,
    AlertTriangle,
    Filter,
    Clock,
    User,
    CheckCircle,
    XCircle,
    RotateCcw,
    Zap,
    Briefcase,
    Eye,
    X
} from 'lucide-react';
import { formatDateTime } from '../utils/dateFormat';

export default function AdminReports() {
    const { reports, engineers, agents, customers, updateReportAssignment, updateReportStatus } = useAdmin();
    const [searchTerm, setSearchTerm] = useState('');
    const [showDetailsModal, setShowDetailsModal] = useState(false);
    const [selectedDetailsReport, setSelectedDetailsReport] = useState(null);
    const [filterLocation, setFilterLocation] = useState('All');
    const [filterStatus, setFilterStatus] = useState('All');
    const [filterType, setFilterType] = useState('All'); // 'Sparky', 'Manual'
    const [selectedReport, setSelectedReport] = useState(null);
    const [showOverrideModal, setShowOverrideModal] = useState(false);

    // Derive unique locations from reports + defaults
    const locations = ['All', 'Wuse II', 'Gwarimpa', 'Jabi', 'Maitama', 'Asokoro', ...new Set(reports.map(r => r.userLocation))].filter((v, i, a) => a.indexOf(v) === i && v !== 'All');

    const filteredReports = reports.filter(report => {
        const matchSearch =
            report.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
            report.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
            (report.readableId && report.readableId.toLowerCase().includes(searchTerm.toLowerCase()));

        const matchLocation = filterLocation === 'All' || report.userLocation === filterLocation;
        const matchStatus = filterStatus === 'All' || report.status === filterStatus;
        const matchType = filterType === 'All' ||
            (filterType === 'Sparky' && report.isSparkyReport) ||
            (filterType === 'Manual' && !report.isSparkyReport);

        return matchSearch && matchLocation && matchStatus && matchType;
    });

    const getStatusColor = (status) => {
        switch (status) {
            case 'Received': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
            case 'In Progress': return 'bg-blue-100 text-blue-800 border-blue-200';
            case 'Resolved': return 'bg-green-100 text-green-800 border-green-200';
            default: return 'bg-gray-100 text-gray-800 border-gray-200';
        }
    };

    const getEngineerName = (idOrReadable) => {
        if (!idOrReadable) return 'Unassigned';
        const engineer = engineers.find(
            (e) => e.id === idOrReadable || e.readableId === idOrReadable
        );
        return engineer ? engineer.name : String(idOrReadable);
    };

    /** Resolve AG-/EN-/CU- style readable ids from the reporting API to a display name. */
    const getCreatorDisplay = (report) => {
        const rid = report.createdByReadableId;
        if (!rid) return '—';
        const agent = agents.find((a) => a.readableId === rid);
        if (agent) return agent.name;
        const eng = engineers.find((e) => e.readableId === rid);
        if (eng) return eng.name;
        const cust = customers.find((c) => c.readableId === rid);
        if (cust) return cust.name;
        return rid;
    };

    const handleOpenModal = (report) => {
        setSelectedReport(report);
        setShowOverrideModal(true);
    };

    const handleOpenDetails = (report) => {
        setSelectedDetailsReport(report);
        setShowDetailsModal(true);
    };

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Reports Governance</h1>
                    <p className="text-gray-600">Global overview and override controls for all fault reports.</p>
                </div>
            </div>

            {/* Filters & Search */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 space-y-4">
                <div className="flex flex-col md:flex-row gap-4">
                    <div className="flex-1 relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input
                            type="text"
                            placeholder="Search reports..."
                            className="w-full pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>

                    <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0">
                        <select
                            value={filterLocation}
                            onChange={(e) => setFilterLocation(e.target.value)}
                            className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white focus:ring-2 focus:ring-red-500 outline-none cursor-pointer"
                        >
                            <option value="All">All Locations</option>
                            {locations.map(loc => <option key={loc} value={loc}>{loc}</option>)}
                        </select>

                        <select
                            value={filterStatus}
                            onChange={(e) => setFilterStatus(e.target.value)}
                            className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white focus:ring-2 focus:ring-red-500 outline-none cursor-pointer"
                        >
                            <option value="All">All Statuses</option>
                            <option value="Received">Received</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Resolved">Resolved</option>
                        </select>

                        <select
                            value={filterType}
                            onChange={(e) => setFilterType(e.target.value)}
                            className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white focus:ring-2 focus:ring-red-500 outline-none cursor-pointer"
                        >
                            <option value="All">All Types</option>
                            <option value="Sparky">Sparky Auto</option>
                            <option value="Manual">Manual</option>
                        </select>
                    </div>
                </div>
            </div>

            {/* Report List */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="bg-gray-50 border-b border-gray-200 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                            <tr>
                                <th className="px-6 py-3">Report Details</th>
                                <th className="px-6 py-3">Assigned To</th>
                                <th className="px-6 py-3">Created By</th>
                                <th className="px-6 py-3">Status</th>
                                <th className="px-6 py-3 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {filteredReports.length === 0 ? (
                                <tr>
                                    <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                                        No reports found matching criteria.
                                    </td>
                                </tr>
                            ) : (
                                filteredReports.map((report) => (
                                    <tr key={report.id} className="hover:bg-gray-50 transition cursor-pointer" onClick={() => handleOpenDetails(report)}>
                                        <td className="px-6 py-4">
                                            <div className="flex items-start gap-3">
                                                <div className={`mt-1 p-1.5 rounded-lg flex-shrink-0 ${report.isSparkyReport ? 'bg-purple-100 text-purple-600' : 'bg-gray-100 text-gray-600'}`}>
                                                    {report.isSparkyReport ? <Zap className="w-4 h-4" /> : <User className="w-4 h-4" />}
                                                </div>
                                                <div>
                                                    <p className="font-medium text-gray-900 line-clamp-1">{report.title}</p>
                                                    <div className="flex items-center gap-2 text-xs text-gray-500 mt-1">
                                                        <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {report.userLocation}</span>
                                                        <span>•</span>
                                                        <span className="font-mono">{report.readableId}</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="flex items-center gap-2">
                                                <Briefcase className="w-4 h-4 text-gray-400" />
                                                <span className="text-sm text-gray-700">{getEngineerName(report.assignedEngineerId)}</span>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="flex flex-col text-xs text-gray-500">
                                                <span className="text-gray-700 font-medium">{getCreatorDisplay(report)}</span>
                                                <span className="text-gray-500">
                                                    {report.isSparkyReport ? 'Sparky' : 'Direct'}
                                                    {report.createdByReadableId ? ` · ${report.createdByReadableId}` : ''}
                                                </span>
                                                <span className="text-gray-400 text-[10px]">{formatDateTime(report.createdAt)}</span>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium border ${getStatusColor(report.status)}`}>
                                                {report.status}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-right">
                                            <div className="flex items-center justify-end gap-3">
                                                <button onClick={(e) => { e.stopPropagation(); handleOpenDetails(report); }} className="text-gray-400 hover:text-primary-600 transition" title="View Details">
                                                    <Eye className="w-5 h-5" />
                                                </button>
                                                <button onClick={(e) => { e.stopPropagation(); handleOpenModal(report); }} className="text-gray-400 hover:text-red-700 font-medium text-sm transition py-1 rounded-md">
                                                    Manage
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {showOverrideModal && selectedReport && (
                <OverrideModal
                    key={selectedReport.id}
                    report={selectedReport}
                    onClose={() => setShowOverrideModal(false)}
                    engineers={engineers}
                    onReassign={updateReportAssignment}
                    onStatusChange={updateReportStatus}
                />
            )}

            {showDetailsModal && selectedDetailsReport && (
                <ReportDetailsModal
                    report={selectedDetailsReport}
                    onClose={() => setShowDetailsModal(false)}
                    engineers={engineers}
                />
            )}
        </div>
    );
}

function normalizeReadableId(value) {
    return String(value || '')
        .trim()
        .toUpperCase()
        .replace(/\s/g, '');
}

function findEngineerByReadableId(engineersList, readableId) {
    const norm = normalizeReadableId(readableId);
    if (!norm) return null;
    return (
        engineersList.find((e) => normalizeReadableId(e.readableId) === norm) ||
        null
    );
}

function OverrideModal({ report, onClose, engineers, onReassign, onStatusChange }) {
    const [selectedEngineer, setSelectedEngineer] = useState(report.assignedEngineerId || '');
    const [engineerSearch, setEngineerSearch] = useState('');
    const [manualReadableId, setManualReadableId] = useState('');
    const [manualIdError, setManualIdError] = useState('');
    const [selectedStatus, setSelectedStatus] = useState(report.status || 'Received');
    const [loading, setLoading] = useState(false);
    const [statusLoading, setStatusLoading] = useState(false);

    useEffect(() => {
        const eng = engineers.find((e) => e.id === report.assignedEngineerId);
        setSelectedEngineer(report.assignedEngineerId || '');
        setEngineerSearch('');
        setManualIdError('');
        setSelectedStatus(report.status || 'Received');
        setManualReadableId(report.assignedToReadableId || eng?.readableId || '');
    }, [report.id, report.assignedEngineerId, report.assignedToReadableId, report.status, engineers]);

    const filteredEngineers = useMemo(() => {
        const q = engineerSearch.trim().toLowerCase();
        if (!q) return engineers;
        return engineers.filter(
            (e) =>
                (e.name || '').toLowerCase().includes(q) ||
                (e.readableId || '').toLowerCase().includes(q) ||
                (e.email || '').toLowerCase().includes(q)
        );
    }, [engineers, engineerSearch]);

    const selectedEngineerRecord = engineers.find((e) => e.id === selectedEngineer);

    const selectEngineer = (eng) => {
        setManualIdError('');
        setSelectedEngineer(eng.id);
        setManualReadableId(eng.readableId || '');
    };

    const applyManualReadableId = () => {
        setManualIdError('');
        const raw = manualReadableId.trim();
        if (!raw) {
            setSelectedEngineer('');
            return;
        }
        const match = findEngineerByReadableId(engineers, raw);
        if (match) {
            setSelectedEngineer(match.id);
        } else {
            setManualIdError('No engineer matches that ID. Check the format (e.g. EN-00002).');
        }
    };

    const handleReassign = async () => {
        if (!selectedEngineer) return;
        setLoading(true);
        try {
            await onReassign(report.id, selectedEngineer);
            onClose();
        } catch (e) {
            alert('Failed to reassign');
        } finally {
            setLoading(false);
        }
    };

    const handleStatusUpdate = async () => {
        if (selectedStatus === report.status) return;
        setStatusLoading(true);
        try {
            await onStatusChange(report.id, selectedStatus);
            onClose();
        } catch (e) {
            alert('Failed to update status');
        } finally {
            setStatusLoading(false);
        }
    };

    const isResolved = report.status === 'Resolved';

    return createPortal(
        <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-xl w-full max-w-lg animate-fade-in-up">
                <div className="flex items-center justify-between p-6 border-b border-gray-200">
                    <div>
                        <h2 className="text-xl font-bold text-gray-900">Manage Report</h2>
                        <p className="text-xs text-gray-500 font-mono mt-1">ID: {report.id}</p>
                    </div>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition">
                        <XCircle className="w-6 h-6" />
                    </button>
                </div>

                <div className="p-6 space-y-6">
                    {/* Status Update Block */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Change Status</label>
                        <div className="flex gap-2">
                            <select
                                value={selectedStatus}
                                onChange={(e) => setSelectedStatus(e.target.value)}
                                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 outline-none bg-white font-medium text-sm"
                            >
                                <option value="Received">Received</option>
                                <option value="In Progress">In Progress</option>
                                <option value="Resolved">Resolved</option>
                            </select>
                            <button
                                onClick={handleStatusUpdate}
                                disabled={statusLoading || selectedStatus === report.status}
                                className="px-4 py-2 bg-gray-900 hover:bg-gray-800 text-white text-sm font-medium rounded-lg disabled:opacity-50 transition"
                            >
                                Update
                            </button>
                        </div>
                    </div>

                    {/* Reassign Section */}
                    <div className="pt-6 border-t border-gray-200 space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Override Assignment</label>
                            {selectedEngineerRecord ? (
                                <p className="text-xs text-gray-600 mb-2">
                                    Selected: <span className="font-semibold text-gray-900">{selectedEngineerRecord.name}</span>
                                    <span className="font-mono text-gray-500 ml-1">({selectedEngineerRecord.readableId})</span>
                                </p>
                            ) : (
                                <p className="text-xs text-gray-500 mb-2">No engineer selected — choose from the list or enter an ID below.</p>
                            )}
                        </div>

                        <div>
                            <label className="block text-xs font-medium text-gray-600 mb-1.5">Search engineers by name</label>
                            <div className="relative">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
                                <input
                                    type="search"
                                    value={engineerSearch}
                                    onChange={(e) => setEngineerSearch(e.target.value)}
                                    disabled={isResolved}
                                    placeholder="Type a name, email, or ID…"
                                    className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none disabled:bg-gray-100"
                                />
                            </div>
                            <div className="mt-2 max-h-44 overflow-y-auto rounded-lg border border-gray-200 divide-y divide-gray-100">
                                {filteredEngineers.length === 0 ? (
                                    <p className="px-3 py-4 text-sm text-gray-500 text-center">No engineers match your search.</p>
                                ) : (
                                    filteredEngineers.map((eng) => {
                                        const isSel = eng.id === selectedEngineer;
                                        return (
                                            <button
                                                key={eng.id}
                                                type="button"
                                                disabled={isResolved}
                                                onClick={() => selectEngineer(eng)}
                                                className={`w-full text-left px-3 py-2.5 text-sm flex items-center justify-between gap-2 transition disabled:opacity-50 ${
                                                    isSel ? 'bg-red-50 text-red-900' : 'hover:bg-gray-50 text-gray-800'
                                                }`}
                                            >
                                                <span>
                                                    <span className="font-medium">{eng.name}</span>
                                                    <span className="text-gray-500 font-mono text-xs ml-2">{eng.readableId}</span>
                                                    <span className="block text-xs text-gray-500 mt-0.5">
                                                        {eng.branch || eng.location || '—'}
                                                    </span>
                                                </span>
                                                {isSel ? <CheckCircle className="w-5 h-5 text-red-600 shrink-0" /> : null}
                                            </button>
                                        );
                                    })
                                )}
                            </div>
                        </div>

                        <div>
                            <label className="block text-xs font-medium text-gray-600 mb-1.5">Or enter engineer ID manually</label>
                            <div className="flex gap-2">
                                <input
                                    type="text"
                                    value={manualReadableId}
                                    onChange={(e) => {
                                        setManualReadableId(e.target.value);
                                        setManualIdError('');
                                    }}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter') {
                                            e.preventDefault();
                                            applyManualReadableId();
                                        }
                                    }}
                                    disabled={isResolved}
                                    placeholder="e.g. EN-00002"
                                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono focus:ring-2 focus:ring-red-500 outline-none disabled:bg-gray-100 uppercase placeholder:normal-case"
                                />
                                <button
                                    type="button"
                                    onClick={applyManualReadableId}
                                    disabled={isResolved}
                                    className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50"
                                >
                                    Apply ID
                                </button>
                            </div>
                            {manualIdError ? (
                                <p className="text-xs text-red-600 mt-1.5">{manualIdError}</p>
                            ) : null}
                        </div>

                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pt-2">
                            <button
                                type="button"
                                onClick={() => {
                                    setSelectedEngineer('');
                                    setManualReadableId('');
                                    setManualIdError('');
                                }}
                                disabled={isResolved || (!selectedEngineer && !manualReadableId.trim())}
                                className="text-sm text-gray-600 hover:text-gray-900 disabled:opacity-40"
                            >
                                Clear selection
                            </button>
                            <button
                                onClick={handleReassign}
                                disabled={loading || !selectedEngineer || selectedEngineer === report.assignedEngineerId || isResolved}
                                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-medium rounded-lg disabled:opacity-50 transition"
                            >
                                Reassign
                            </button>
                        </div>

                        {isResolved ? (
                            <p className="text-xs text-red-500 font-medium">
                                Cannot reassign a resolved report. Change status to &apos;Received&apos; or &apos;In Progress&apos; first.
                            </p>
                        ) : (
                            <p className="text-xs text-gray-500 flex items-center gap-1">
                                <AlertTriangle className="w-3 h-3 shrink-0" />
                                Overriding assignment will notify the new engineer immediately.
                            </p>
                        )}
                    </div>
                </div>
            </div>
        </div>,
        document.body
    );
}

function ReportDetailsModal({ report, onClose, engineers }) {
    return createPortal(
        <div className="fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]" style={{ margin: 0, padding: 0 }}>
            <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto m-4 animate-fade-in-up">
                <div className="flex items-center justify-between p-6 border-b border-gray-200">
                    <h2 className="text-2xl font-bold text-gray-900">Report Details</h2>
                    <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg transition">
                        <X className="w-5 h-5 text-gray-600" />
                    </button>
                </div>

                <div className="p-6 space-y-4">
                    <div>
                        <label className="text-sm font-medium text-gray-500">Title</label>
                        <p className="text-gray-900 mt-1 font-medium">{report.title}</p>
                    </div>
                    <div>
                        <label className="text-sm font-medium text-gray-500">Description</label>
                        <p className="text-gray-900 mt-1 whitespace-pre-wrap">{report.description}</p>
                    </div>
                    <div>
                        <label className="text-sm font-medium text-gray-500">Fault Type</label>
                        <p className="text-gray-900 mt-1">{report.faultType}</p>
                    </div>
                    {report.priority ? (
                        <div>
                            <label className="text-sm font-medium text-gray-500">Priority</label>
                            <span className={`block w-fit px-3 py-1 mt-1 text-xs font-medium rounded-full capitalize ${report.priority === 'high' || report.priority === 'critical' ? 'bg-red-100 text-red-800' : report.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' : 'bg-blue-100 text-blue-800'}`}>
                                {report.priority}
                            </span>
                        </div>
                    ) : (
                        <div>
                            <label className="text-sm font-medium text-gray-500">Priority</label>
                            <p className="text-gray-500 mt-1 italic">Not set</p>
                        </div>
                    )}

                    {report.address ? (
                        <div>
                            <label className="text-sm font-medium text-gray-500">Address</label>
                            <p className="text-gray-900 mt-1">{report.address}</p>
                        </div>
                    ) : null}

                    <div>
                        <label className="text-sm font-medium text-gray-500">Attachments</label>
                        <div className="mt-2 p-4 bg-gray-50 rounded-lg border border-gray-200 space-y-2">
                            {report.mediaUrls?.length ? (
                                report.mediaUrls.map((url, i) => (
                                    <a
                                        key={i}
                                        href={url}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="block text-sm text-primary-600 hover:underline truncate"
                                    >
                                        {url}
                                    </a>
                                ))
                            ) : (
                                <p className="text-sm text-gray-500">No attachments available</p>
                            )}
                        </div>
                    </div>

                    {report.assignedEngineerId && (
                        <div>
                            <label className="text-sm font-medium text-gray-500">Assigned Engineer</label>
                            <p className="text-gray-900 mt-1 font-medium">
                                {engineers.find((e) => e.id === report.assignedEngineerId)?.name || 'Unknown Engineer'}
                            </p>
                        </div>
                    )}

                    <div>
                        <label className="text-sm font-medium text-gray-500">Customer</label>
                        <p className="text-gray-900 mt-1 font-medium">{report.userName || 'Unknown'}</p>
                    </div>
                    <div>
                        <label className="text-sm font-medium text-gray-500">Location</label>
                        <p className="text-gray-900 mt-1">{report.userLocation}</p>
                    </div>
                </div>
            </div>
        </div>,
        document.body
    );
}
