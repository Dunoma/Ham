import { useState } from 'react';
import { useEngineer } from '../context/EngineerContext';
import UserAvatar from '../components/UserAvatar';
import UserProfileModal from '../components/UserProfileModal';
import { Search, Users, X, Copy, Check } from 'lucide-react';

export default function EngineerCustomers() {
  const { searchCustomers } = useEngineer();
  const [searchTerm, setSearchTerm] = useState('');
  const [searchMode, setSearchMode] = useState('name'); // 'name' or 'id'
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [searchResults, setSearchResults] = useState([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [copiedId, setCopiedId] = useState(null);

  const handleSearch = async () => {
    if (!searchTerm.trim()) {
      setSearchResults([]);
      setHasSearched(false);
      return;
    }

    setIsSearching(true);
    setHasSearched(true);

    try {
      const results = await searchCustomers(searchTerm, searchMode);
      setSearchResults(results);
    } catch (error) {
      console.error('Search error:', error);
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const handleClear = () => {
    setSearchTerm('');
    setSearchResults([]);
    setHasSearched(false);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Customers</h1>
          <p className="text-gray-600 mt-1">Search and view customer information</p>
        </div>
      </div>

      {/* Search Bar */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="space-y-4">
          {/* Search Mode Toggle */}
          <div className="flex flex-col sm:flex-row sm:items-center gap-3">
            <span className="text-sm font-medium text-gray-700">Search Mode:</span>
            <div className="flex items-center gap-2 bg-gray-100 p-1 rounded-lg w-full sm:w-auto">
              <button
                onClick={() => setSearchMode('name')}
                className={`flex-1 sm:flex-none px-4 py-2 text-sm font-medium rounded-md transition ${searchMode === 'name'
                  ? 'bg-primary-600 text-white shadow-sm'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
              >
                By Name
              </button>
              <button
                onClick={() => setSearchMode('id')}
                className={`flex-1 sm:flex-none px-4 py-2 text-sm font-medium rounded-md transition ${searchMode === 'id'
                  ? 'bg-primary-600 text-white shadow-sm'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
              >
                By Customer ID
              </button>
            </div>
          </div>

          {/* Search Input and Button */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <div className="flex-1 relative w-full">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder={
                  searchMode === 'name'
                    ? 'Enter customer name...'
                    : 'Enter customer ID (e.g. CU-1001)...'
                }
                className={`w-full pl-10 ${searchTerm ? 'pr-10' : 'pr-4'
                  } py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none`}
              />
              {searchTerm && (
                <button
                  onClick={handleClear}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1 hover:bg-gray-100 rounded-full transition"
                  title="Clear search"
                  type="button"
                >
                  <X className="w-4 h-4 text-gray-500" />
                </button>
              )}
            </div>
            <button
              onClick={handleSearch}
              disabled={isSearching || !searchTerm.trim()}
              className="px-6 py-3 bg-primary-600 hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium rounded-lg transition flex items-center gap-2"
            >
              <Search className="w-5 h-5" />
              {isSearching ? 'Searching...' : 'Search'}
            </button>
          </div>
        </div>
      </div>

      {/* Customers List or Empty State */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        {!hasSearched ? (
          <div className="p-12 text-center">
            <div className="flex flex-col items-center justify-center">
              <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <Users className="w-12 h-12 text-gray-400" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Search to find customers
              </h3>
              <p className="text-gray-500 max-w-md">
                Use the search bar above to find customers by name or customer ID.
                Select your preferred search mode and enter your query.
              </p>
            </div>
          </div>
        ) : searchResults.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-gray-500 text-lg">No customers found</p>
            <p className="text-gray-400 text-sm mt-2">
              Try a different search term or switch search mode
            </p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {searchResults.map((customer) => (
              <div
                key={customer.id}
                className="p-6 hover:bg-gray-50 transition cursor-pointer"
                onClick={() => setSelectedUserId(customer.id)}
              >
                <div className="flex items-center gap-4">
                  <UserAvatar
                    userId={customer.id}
                    userName={customer.name}
                    profilePicture={customer.profile_picture}
                    size="md"
                    onClick={() => setSelectedUserId(customer.id)}
                  />
                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg font-semibold text-gray-900">{customer.name}</h3>
                    <div className="flex flex-wrap items-center gap-2 text-sm text-gray-500 mt-1">
                      <span className="truncate">{customer.email}</span>
                      <span className="hidden sm:inline">•</span>
                      <span className="truncate">{customer.phone}</span>
                      <span className="hidden sm:inline">•</span>
                      <span className="truncate">{customer.location}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <p className="text-xs text-gray-400 font-mono">{customer.readableId || customer.id}</p>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          navigator.clipboard.writeText(customer.readableId || customer.id);
                          setCopiedId(customer.id);
                          setTimeout(() => setCopiedId(null), 1000);
                        }}
                        className="p-1 hover:bg-gray-200 rounded transition"
                        title="Copy ID"
                      >
                        {copiedId === customer.id ? (
                          <Check className="w-3 h-3 text-green-600" />
                        ) : (
                          <Copy className="w-3 h-3 text-gray-400" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* User Profile Modal */}
      {selectedUserId && (
        <UserProfileModal
          userId={selectedUserId}
          onClose={() => setSelectedUserId(null)}
        />
      )}
    </div>
  );
}
