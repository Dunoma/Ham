import { useState } from 'react';
import { createPortal } from 'react-dom';
import { useAdmin } from '../context/AdminContext';
import { ChevronDown, ChevronUp, Shield, Bell, ArrowDownLeft, ArrowUpRight, Megaphone, AlertTriangle, X, User, Users, MapPin, Globe, Wrench, CheckCircle, Send } from 'lucide-react';
import { formatDateTime } from '../utils/dateFormat';

export default function AdminNotifications() {
    const { user, notifications, sendBroadcast, fetchDashboardData } = useAdmin();
    const [showSendModal, setShowSendModal] = useState(false);
    const [showNotificationModal, setShowNotificationModal] = useState(false);
    const [expandedNotifications, setExpandedNotifications] = useState(new Set());
    const [urgencyFilter, setUrgencyFilter] = useState('all');
    const [typeFilter, setTypeFilter] = useState('all'); // 'all', 'sent' (broadcasts), 'received' (system)

    // Filter logic
    const filteredNotifications = notifications.filter((notification) => {
        if (!user) return false;

        // 1. Filter by Direction
        let isSent = notification.senderId === user.id; // STRICT check as per instructions

        if (typeFilter === 'others' && isSent) return false;
        if (typeFilter === 'sent' && !isSent) return false;

        // 2. Filter by Urgency
        if (urgencyFilter !== 'all' && notification.urgency !== urgencyFilter) return false;

        return true;
    });

    const toggleNotification = (id) => {
        const newExpanded = new Set(expandedNotifications);
        if (newExpanded.has(id)) newExpanded.delete(id);
        else newExpanded.add(id);
        setExpandedNotifications(newExpanded);
    };

    const getUrgencyColor = (urgency) => {
        switch (urgency) {
            case 'low': return 'bg-blue-500';
            case 'medium': return 'bg-yellow-500';
            case 'high': return 'bg-orange-500';
            case 'critical': return 'bg-red-500';
            default: return 'bg-gray-500';
        }
    };
    const getUrgencyBorderColor = (urgency) => {
        switch (urgency) {
            case 'low': return 'border-l-blue-500';
            case 'medium': return 'border-l-yellow-500';
            case 'high': return 'border-l-orange-500';
            case 'critical': return 'border-l-red-500';
            default: return 'border-l-gray-500';
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Notifications Center</h1>
                    <p className="text-gray-600">Manage broadcasts and view system alerts.</p>
                </div>
                <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                    <button
                        onClick={() => setShowNotificationModal(true)}
                        className="flex items-center gap-2 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-4 py-2 rounded-lg transition shadow-sm"
                    >
                        <Bell className="w-5 h-5" />
                        Send Notification
                    </button>
                    <button
                        onClick={() => setShowSendModal(true)}
                        className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg transition shadow-sm"
                    >
                        <Megaphone className="w-5 h-5" />
                        Send Broadcast
                    </button>
                </div>
            </div>

            {/* Filters */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 space-y-4 md:space-y-0 md:flex md:items-center md:justify-between">
                {/* Type Filter Tabs */}
                <div className="flex bg-gray-100 p-1 rounded-lg">
                    {['all', 'sent', 'others'].map(filter => (
                        <button
                            key={filter}
                            onClick={() => setTypeFilter(filter)}
                            className={`px-4 py-2 rounded-md text-sm font-medium capitalize transition ${typeFilter === filter
                                ? 'bg-primary-600 text-white shadow-sm'
                                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
                        >
                            {filter}
                        </button>
                    ))}
                </div>

                {/* Urgency Filter */}
                <div className="flex bg-gray-100 p-1 rounded-lg overflow-x-auto">
                    {[
                        { value: 'all', label: 'All' },
                        { value: 'low', label: 'Low' },
                        { value: 'medium', label: 'Med' },
                        { value: 'high', label: 'High' },
                        { value: 'critical', label: 'Crit' },
                    ].map((option) => (
                        <button
                            key={option.value}
                            onClick={() => setUrgencyFilter(option.value)}
                            className={`px-3 py-2 rounded-md text-sm font-medium transition whitespace-nowrap ${urgencyFilter === option.value
                                ? 'bg-primary-600 text-white shadow-sm'
                                : 'text-gray-700 hover:bg-gray-200'
                                }`}
                        >
                            {option.label}
                        </button>
                    ))}
                </div>
            </div>

            {/* List */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                {filteredNotifications.length === 0 ? (
                    <div className="p-12 text-center text-gray-500">
                        <Bell className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                        <p className="text-lg font-medium">No notifications found</p>
                        <p className="text-sm">Adjust filters or send a new broadcast.</p>
                    </div>
                ) : (
                    <div className="divide-y divide-gray-200">
                        {filteredNotifications.map(notif => {
                            const isExpanded = expandedNotifications.has(notif.id);
                            const borderColor = getUrgencyBorderColor(notif.urgency);
                            const urgencyColor = getUrgencyColor(notif.urgency);
                            const isSent = notif.senderId === user?.id || notif.senderType === 'admin';

                            return (
                                <div key={notif.id} className={`border-l-4 ${borderColor} hover:bg-gray-50 transition cursor-pointer`} onClick={() => toggleNotification(notif.id)}>
                                    <div className="p-5">
                                        <div className="flex items-start justify-between gap-4">
                                            <div className="mt-1 flex-shrink-0">
                                                {isSent ? (
                                                    <div className="p-2 bg-blue-50 rounded-full"><Megaphone className="w-5 h-5 text-blue-600" /></div>
                                                ) : (
                                                    <div className="p-2 bg-gray-100 rounded-full"><AlertTriangle className="w-5 h-5 text-gray-600" /></div>
                                                )}
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <div className="flex items-center justify-between mb-1">
                                                    <span className="text-xs text-gray-500 font-medium">
                                                        {isSent ? `To: ${notif.target ? notif.target.toUpperCase() : 'ALL USERS'}` : 'From: System'}
                                                    </span>
                                                    <span className="text-xs text-gray-400">{formatDateTime(notif.timestamp)}</span>
                                                </div>
                                                <div className="flex items-center gap-3 mb-2">
                                                    <h3 className="text-lg font-semibold text-gray-900 flex-1">{notif.title}</h3>
                                                    <span className={`px-2 py-0.5 text-xs font-semibold rounded text-white ${urgencyColor} capitalize`}>
                                                        {notif.urgency}
                                                    </span>
                                                </div>
                                                {isExpanded && (
                                                    <div className="mt-2 text-gray-700 whitespace-pre-wrap text-sm leading-relaxed border-t border-gray-100 pt-2">
                                                        {notif.message}
                                                    </div>
                                                )}
                                            </div>
                                            <div className="flex-shrink-0 self-center">
                                                {isExpanded ? <ChevronUp className="w-5 h-5 text-gray-400" /> : <ChevronDown className="w-5 h-5 text-gray-400" />}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>

            {showSendModal && (
                <BroadcastModal
                    onClose={() => setShowSendModal(false)}
                    onSend={async (data) => {
                        await sendBroadcast(data);
                        fetchDashboardData();
                    }}
                />
            )}

            {showNotificationModal && (
                <AdminSendNotificationModal
                    onClose={() => setShowNotificationModal(false)}
                    onSend={async (data) => {
                        // For now we map this to sendBroadcast with specific target info
                        // In a real app, this would use a dedicated API
                        await sendBroadcast({
                            ...data,
                            isDirectNotification: true
                        });
                        fetchDashboardData();
                    }}
                />
            )}
        </div>
    );
}

function AdminSendNotificationModal({ onClose, onSend }) {
    const [title, setTitle] = useState('');
    const [message, setMessage] = useState('');
    const [urgency, setUrgency] = useState('medium');
    const [recipientType, setRecipientType] = useState('engineer'); // 'engineer', 'agent', 'customer'
    const [sendMode, setSendMode] = useState('single'); // 'single', 'multiple'
    const [recipientIds, setRecipientIds] = useState('');

    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        if (!title.trim() || !message.trim() || !recipientIds.trim()) {
            setError('Please fill in all required fields');
            return;
        }

        setIsSubmitting(true);
        try {
            await onSend({
                title,
                message,
                urgency,
                recipientType,
                recipientIds: sendMode === 'single' ? recipientIds.trim() : recipientIds.split(',').map(id => id.trim()),
                target: 'direct' // distinguishing marker
            });
            setIsSuccess(true);
            setTimeout(() => { onClose(); }, 1500);
        } catch (e) {
            setError("Failed to send notification");
        } finally {
            setIsSubmitting(false);
        }
    };

    if (isSuccess) {
        return createPortal(
            <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-4">
                <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-8 flex flex-col items-center animate-fade-in-up">
                    <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-4 animate-bounce-short">
                        <CheckCircle className="w-10 h-10 text-green-600" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Notification Sent!</h3>
                    <p className="text-gray-500 text-center">Message delivered successfully.</p>
                </div>
            </div>,
            document.body
        );
    }

    return createPortal(
        <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto animate-fade-in-up">
                <div className="flex items-center justify-between p-6 border-b border-gray-200">
                    <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                        Send Notification
                    </h2>
                    <button onClick={onClose}><X className="w-5 h-5 text-gray-400" /></button>
                </div>

                <form onSubmit={handleSubmit} className="p-6 space-y-6">
                    {error && <div className="p-3 bg-red-50 text-red-700 rounded-lg text-sm">{error}</div>}

                    {/* Recipient Type */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Recipient Type</label>
                        <div className="flex gap-3">
                            {['engineer', 'agent', 'customer'].map(type => (
                                <button
                                    key={type}
                                    type="button"
                                    onClick={() => setRecipientType(type)}
                                    className={`flex-1 py-2 px-3 rounded-lg border capitalize text-sm font-medium transition ${recipientType === type
                                        ? 'bg-primary-50 border-primary-500 text-primary-700'
                                        : 'hover:bg-gray-50 border-gray-200 text-gray-600'
                                        }`}
                                >
                                    {type}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Send Mode (Single/Multiple) */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Mode</label>
                        <div className="flex bg-gray-100 p-1 rounded-lg w-fit">
                            <button
                                type="button"
                                onClick={() => setSendMode('single')}
                                className={`px-4 py-1.5 rounded-md text-sm font-medium transition ${sendMode === 'single' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500'}`}
                            >
                                Single
                            </button>
                            <button
                                type="button"
                                onClick={() => setSendMode('multiple')}
                                className={`px-4 py-1.5 rounded-md text-sm font-medium transition ${sendMode === 'multiple' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500'}`}
                            >
                                Multiple
                            </button>
                        </div>
                    </div>

                    {/* IDs Input */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            {sendMode === 'single' ? `${recipientType === 'engineer' ? 'Engineer' : recipientType === 'agent' ? 'Agent' : 'Customer'} ID` : 'Recipient IDs (Comma Separated)'} <span className="text-red-500">*</span>
                        </label>
                        <input
                            required
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none font-mono"
                            value={recipientIds}
                            onChange={(e) => setRecipientIds(e.target.value)}
                            placeholder={
                                sendMode === 'single'
                                    ? (recipientType === 'engineer' ? "e.g. EN-304" : recipientType === 'agent' ? "e.g. AG-102" : "e.g. CU-501")
                                    : (recipientType === 'engineer' ? "e.g. EN-304, EN-305" : recipientType === 'agent' ? "e.g. AG-102, AG-103" : "e.g. CU-501, CU-502")
                            }
                        />
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Title <span className="text-red-500">*</span></label>
                            <input
                                required
                                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none"
                                value={title}
                                onChange={(e) => setTitle(e.target.value)}
                                placeholder="Notification title..."
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Urgency <span className="text-red-500">*</span></label>
                            <div className="relative">
                                <select
                                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none appearance-none bg-white capitalize"
                                    value={urgency}
                                    onChange={(e) => setUrgency(e.target.value)}
                                >
                                    {['low', 'medium', 'high', 'critical'].map(l => <option key={l} value={l}>{l}</option>)}
                                </select>
                                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
                            </div>
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Message <span className="text-red-500">*</span></label>
                        <textarea
                            required
                            rows="4"
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none resize-none"
                            value={message}
                            onChange={(e) => setMessage(e.target.value)}
                            placeholder="Message content..."
                        />
                    </div>

                    <div className="flex justify-end gap-3 pt-6 border-t border-gray-100">
                        <button type="button" onClick={onClose} className="px-6 py-2.5 text-gray-700 hover:bg-gray-50 border border-gray-300 rounded-lg transition font-medium">Cancel</button>
                        <button type="submit" disabled={isSubmitting} className="px-6 py-2.5 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50 font-medium flex items-center gap-2">
                            <Send className="w-4 h-4" />
                            {isSubmitting ? 'Sending...' : 'Send Notification'}
                        </button>
                    </div>
                </form>
            </div>
        </div>,
        document.body
    );
}

function BroadcastModal({ onClose, onSend }) {
    const [formData, setFormData] = useState({
        title: '',
        message: '',
        urgency: 'low',
        target: 'all_users'
    });
    const [selectedUserType, setSelectedUserType] = useState('all_users');
    const [selectedLocation, setSelectedLocation] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    // Update formData.target whenever userType or location changes
    // Logic: If location is selected, it takes precedence (or acts as the target key if we stick to the existing keys).
    // Existing keys: all_users, all_agents, all_engineers, wuse_ii, gwarimpa.
    // If location is 'wuse_ii', target = 'wuse_ii'.
    // Else target = selectedUserType.
    const updateTarget = (userType, location) => {
        if (location) {
            setFormData(prev => ({ ...prev, target: location }));
        } else {
            setFormData(prev => ({ ...prev, target: userType }));
        }
    };

    const handleUserTypeChange = (type) => {
        setSelectedUserType(type);
        updateTarget(type, selectedLocation);
    };

    const handleLocationChange = (loc) => {
        setSelectedLocation(loc);
        updateTarget(selectedUserType, loc);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        try {
            await onSend(formData);
            onClose();
        } catch (e) {
            alert("Failed to send broadcast");
        } finally {
            setIsSubmitting(false);
        }
    };

    const userTypeOptions = [
        { value: 'all_users', label: 'All Users', icon: Globe },
        { value: 'all_agents', label: 'Agents', icon: Users },
        { value: 'all_engineers', label: 'Engineers', icon: Wrench },
    ];

    const locationOptions = [
        { value: '', label: 'All Locations' },
        { value: 'wuse_ii', label: 'Wuse II' },
        { value: 'gwarimpa', label: 'Gwarimpa' },
    ];

    return createPortal(
        <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl animate-fade-in-up max-h-[90vh] overflow-y-auto">
                <div className="flex items-center justify-between p-6 border-b border-gray-200 sticky top-0 bg-white z-10">
                    <h2 className="text-xl font-bold text-gray-900">
                        Send Broadcast
                    </h2>
                    <button onClick={onClose}><X className="w-5 h-5 text-gray-400" /></button>
                </div>

                <form onSubmit={handleSubmit} className="p-6 space-y-6">
                    {/* Target Audience: User Type */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-3">
                            Target Audience <span className="text-red-500">*</span>
                        </label>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                            {userTypeOptions.map((option) => {
                                const Icon = option.icon;
                                const isSelected = selectedUserType === option.value;
                                return (
                                    <button
                                        key={option.value}
                                        type="button"
                                        onClick={() => handleUserTypeChange(option.value)}
                                        className={`flex flex-col items-center justify-center p-4 rounded-xl border transition-all ${isSelected
                                            ? 'border-primary-600 bg-primary-50 text-primary-700 ring-1 ring-primary-600'
                                            : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50 text-gray-600'
                                            }`}
                                    >
                                        <Icon className={`w-6 h-6 mb-2 ${isSelected ? 'text-primary-600' : 'text-gray-400'}`} />
                                        <span className="text-sm font-medium">{option.label}</span>
                                    </button>
                                );
                            })}
                        </div>
                    </div>

                    {/* Target Audience: Location (Optional) */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Location (Optional)
                        </label>
                        <div className="relative">
                            <select
                                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none transition appearance-none bg-white"
                                value={selectedLocation}
                                onChange={(e) => handleLocationChange(e.target.value)}
                            >
                                {locationOptions.map((option) => (
                                    <option key={option.value} value={option.value}>
                                        {option.label}
                                    </option>
                                ))}
                            </select>
                            <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Title <span className="text-red-500">*</span>
                        </label>
                        <input
                            required
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none transition"
                            value={formData.title}
                            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                            placeholder="Enter notification title..."
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Message <span className="text-red-500">*</span>
                        </label>
                        <textarea
                            required
                            rows="5"
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none resize-none transition"
                            value={formData.message}
                            onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                            placeholder="Enter notification message..."
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                            Urgency Level <span className="text-red-500">*</span>
                        </label>
                        <div className="relative">
                            <select
                                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none transition appearance-none bg-white capitalize"
                                value={formData.urgency}
                                onChange={(e) => setFormData({ ...formData, urgency: e.target.value })}
                            >
                                {['low', 'medium', 'high', 'critical'].map(level => (
                                    <option key={level} value={level}>
                                        {level}
                                    </option>
                                ))}
                            </select>
                            <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
                        </div>
                    </div>

                    <div className="flex justify-end gap-3 pt-6 border-t border-gray-100">
                        <button
                            type="button"
                            onClick={onClose}
                            className="px-6 py-2.5 text-gray-700 hover:bg-gray-50 border border-gray-300 rounded-lg transition font-medium"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            disabled={isSubmitting}
                            className="px-6 py-2.5 bg-gray-900 text-white rounded-lg hover:bg-gray-800 disabled:opacity-50 font-medium flex items-center gap-2"
                        >
                            <Megaphone className="w-4 h-4" />
                            {isSubmitting ? 'Sending...' : 'Send Broadcast'}
                        </button>
                    </div>
                </form>
            </div>
        </div>,
        document.body
    );
}
