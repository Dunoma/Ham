import { useState } from 'react';
import { createPortal } from 'react-dom';
import { useAdmin } from '../context/AdminContext';
import {
    Search,
    MapPin,
    Mail,
    Phone,
    User,
    Ban,
    MoreVertical,
    ShieldAlert
} from 'lucide-react';
import UserProfileModal from '../components/UserProfileModal';

export default function AdminCustomers() {
    const { customers, updateCustomerStatus } = useAdmin();
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedUserId, setSelectedUserId] = useState(null);
    const [togglingId, setTogglingId] = useState(null);
    const [deactivatingCustomer, setDeactivatingCustomer] = useState(null);

    const normalizedCustomers = customers.map((customer) => {
        const profile = customer.profile || {};

        return {
            ...customer,
            name: customer.name || profile.full_name || '',
            readableId: customer.readableId || profile.display_id || '',
            email: customer.email || '',
            phone: customer.phone || profile.phone_number || '',
            location: customer.location || profile.location || '',
            profile_picture: customer.profile_picture || profile.profile_picture_url || null,
            isActive: customer.isActive ?? customer.is_active,
            isVerified: customer.isVerified ?? customer.is_verified,
        };
    });

    const lowerSearchTerm = searchTerm.toLowerCase();
    const filteredCustomers = normalizedCustomers.filter((customer) =>
        customer.name.toLowerCase().includes(lowerSearchTerm) ||
        (customer.readableId && customer.readableId.toLowerCase().includes(lowerSearchTerm))
    );

    const handleConfirmToggle = async (customer) => {
        const newStatus = customer.isActive === false ? true : false;
        
        setTogglingId(customer.id);
        setDeactivatingCustomer(null);
        try {
            await updateCustomerStatus(customer.id, newStatus);
        } catch (error) {
            alert('Failed to update status');
        } finally {
            setTogglingId(null);
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Customer Directory</h1>
                    <p className="text-gray-600">View and manage registered customers.</p>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="border-b border-gray-200 bg-gray-50 flex flex-col sm:flex-row sm:items-center justify-between gap-4 px-6 py-3">
                    <div className="relative w-full max-w-md">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input
                            type="text"
                            placeholder="Search customer by name or ID..."
                            className="w-full pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <div className="text-sm text-gray-500">
                        Total: {normalizedCustomers.length}
                    </div>
                </div>

                <div className="overflow-x-auto min-h-[400px] pb-32">
                    <table className="w-full text-left">
                        <thead className="bg-gray-50 border-b border-gray-200">
                            <tr>
                                <th className="px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Customer</th>
                                <th className="px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Contact</th>
                                <th className="px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Location</th>
                                <th className="px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</th>
                                <th className="px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {filteredCustomers.length === 0 ? (
                                <tr>
                                    <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                                        No customers found matching your search.
                                    </td>
                                </tr>
                            ) : (
                                filteredCustomers.map((customer) => (
                                    <tr key={customer.id} className="hover:bg-gray-50 transition">
                                        <td className="px-6 py-4 whitespace-nowrap cursor-pointer" onClick={() => setSelectedUserId(customer.id)}>
                                            <div className="flex items-center gap-3">
                                                <div className="w-10 h-10 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center font-bold">
                                                    {customer.name.charAt(0)}
                                                </div>
                                                <div>
                                                    <p className="text-sm font-medium text-gray-900">{customer.name}</p>
                                                    <p className="text-xs text-gray-500 font-mono">{customer.readableId || customer.id}</p>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="flex flex-col gap-1">
                                                <div className="flex items-center gap-2 text-sm text-gray-600">
                                                    <Mail className="w-3.5 h-3.5" />
                                                    {customer.email}
                                                </div>
                                                <div className="flex items-center gap-2 text-sm text-gray-600">
                                                    <Phone className="w-3.5 h-3.5" />
                                                    {customer.phone}
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="flex items-center gap-2 text-sm text-gray-700">
                                                <MapPin className="w-4 h-4 text-gray-400" />
                                                {customer.location}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            {customer.isActive !== false ? (
                                                <span className="inline-flex items-center gap-1 px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">Active
                                                </span>
                                            ) : (
                                                <span className="inline-flex items-center gap-1 px-2 py-1 bg-red-100 text-red-700 rounded-full text-xs font-medium">Inactive
                                                </span>
                                            )}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm">
                                            <TableActionMenu
                                                onView={() => setSelectedUserId(customer.id)}
                                                onToggleStatus={() => setDeactivatingCustomer(customer)}
                                                isToggling={togglingId === customer.id}
                                                isActive={customer.isActive !== false}
                                            />
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {selectedUserId && (
                <UserProfileModal
                    userId={selectedUserId}
                    userData={normalizedCustomers.find(c => c.id === selectedUserId)}
                    onClose={() => setSelectedUserId(null)}
                />
            )}

            {deactivatingCustomer && (
                <DeactivateConfirmModal
                    customer={deactivatingCustomer}
                    onClose={() => setDeactivatingCustomer(null)}
                    onConfirm={handleConfirmToggle}
                />
            )}
        </div>
    );
}

function TableActionMenu({ onView, onToggleStatus, isToggling, isActive }) {
    const [isOpen, setIsOpen] = useState(false);
    return (
        <div className="relative inline-block text-left">
            <button
                onClick={(e) => { e.stopPropagation(); setIsOpen(!isOpen); }}
                onBlur={() => setTimeout(() => setIsOpen(false), 200)}
                className="p-2 hover:bg-gray-100 rounded-full transition text-gray-500"
            >
                {isToggling ? <div className="w-4 h-4 border-2 border-gray-300 border-t-red-600 rounded-full animate-spin" /> : <MoreVertical className="w-4 h-4" />}
            </button>

            {isOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-100 z-[100] py-1 animate-fade-in-up origin-top-right">
                    <button onClick={onView} className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                        <User className="w-4 h-4" /> View Profile
                    </button>
                    <button onClick={onToggleStatus} className={`w-full text-left px-4 py-2 text-sm flex items-center gap-2 ${isActive ? 'text-red-600 hover:bg-red-50' : 'text-green-600 hover:bg-green-50'}`}>
                        <Ban className="w-4 h-4" /> {isActive ? 'Deactivate' : 'Reactivate'}
                    </button>
                </div>
            )}
        </div>
    );
}

function DeactivateConfirmModal({ customer, onClose, onConfirm }) {
    const isActive = customer.isActive !== false;
    return createPortal(
        <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-xl w-full max-w-sm animate-fade-in-up p-6 text-center">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 ${isActive ? 'bg-red-100' : 'bg-green-100'}`}>
                    <ShieldAlert className={`w-6 h-6 ${isActive ? 'text-red-600' : 'text-green-600'}`} />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">
                    {isActive ? 'Deactivate Customer?' : 'Activate Customer?'}
                </h3>
                <p className="text-gray-500 text-sm mb-6">
                    Are you sure you want to {isActive ? 'deactivate' : 'activate'} <strong>{customer.name}</strong>? {isActive ? 'They will no longer be able to log in.' : 'They will regain access to their account.'}
                </p>
                <div className="flex gap-3 justify-center">
                    <button onClick={onClose} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button>
                    <button onClick={() => onConfirm(customer)} className={`px-4 py-2 text-white rounded-lg ${isActive ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'}`}>
                        {isActive ? 'Deactivate' : 'Activate'}
                    </button>
                </div>
            </div>
        </div>,
        document.body
    );
}
