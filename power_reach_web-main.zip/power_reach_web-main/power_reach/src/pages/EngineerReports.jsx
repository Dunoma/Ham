import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useEngineer } from '../context/EngineerContext';
import { Eye, Check } from 'lucide-react';
import UserAvatar from '../components/UserAvatar';
import UserProfileModal from '../components/UserProfileModal';
import { formatDateTime } from '../utils/dateFormat';

export default function EngineerReports() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { user, assignedReports, updateReportStatus, fetchAssignedReports } = useEngineer();
  const [selectedReport, setSelectedReport] = useState(null);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [sortOrder, setSortOrder] = useState('newest'); // 'newest' or 'oldest' - defaults to newest
  const [statusFilter, setStatusFilter] = useState('all'); // 'all', 'pending', 'in_progress', 'resolved'
  const [priorityFilter, setPriorityFilter] = useState('all'); // 'all', 'low', 'medium', 'high'
  const [newStatus, setNewStatus] = useState('');
  const [updateSuccess, setUpdateSuccess] = useState(false);

  // Initialize filters from URL query parameters
  useEffect(() => {
    const statusParam = searchParams.get('filter');
    const validStatusFilters = ['all', 'pending', 'in_progress', 'resolved'];
    if (statusParam && validStatusFilters.includes(statusParam)) {
      setStatusFilter(statusParam);
    }
  }, [searchParams]);

  // Update URL when status filter changes
  const handleStatusFilterChange = (newFilter) => {
    setStatusFilter(newFilter);
    setSearchParams({ filter: newFilter }, { replace: true });
  };

  // Filter reports by status and priority
  const filteredReports = assignedReports.filter((report) => {
    // Status filter
    let statusMatch = true;
    if (statusFilter === 'pending') statusMatch = report.status === 'Received';
    else if (statusFilter === 'in_progress') statusMatch = report.status === 'In Progress';
    else if (statusFilter === 'resolved') statusMatch = report.status === 'Resolved';

    // Priority filter
    let priorityMatch = true;
    if (priorityFilter !== 'all') {
      priorityMatch = report.priority?.toLowerCase() === priorityFilter.toLowerCase();
    }

    return statusMatch && priorityMatch;
  });

  // Sort reports
  const sortedReports = [...filteredReports].sort((a, b) => {
    const dateA = new Date(a.createdAt);
    const dateB = new Date(b.createdAt);
    return sortOrder === 'newest' ? dateB - dateA : dateA - dateB;
  });

  // Calculate filter counts
  const statusFilterCounts = {
    all: assignedReports.length,
    pending: assignedReports.filter((r) => r.status === 'Received').length,
    in_progress: assignedReports.filter((r) => r.status === 'In Progress').length,
    resolved: assignedReports.filter((r) => r.status === 'Resolved').length,
  };

  const priorityFilterCounts = {
    all: assignedReports.length,
    low: assignedReports.filter((r) => r.priority?.toLowerCase() === 'low').length,
    medium: assignedReports.filter((r) => r.priority?.toLowerCase() === 'medium').length,
    high: assignedReports.filter((r) => r.priority?.toLowerCase() === 'high').length,
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Received':
        return 'bg-gray-100 text-gray-700 border-gray-300';
      case 'In Progress':
        return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      case 'Resolved':
        return 'bg-green-100 text-green-700 border-green-300';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  const handleStatusChange = async (reportId, statusToUpdate) => {
    try {
      await updateReportStatus(reportId, statusToUpdate);
      await fetchAssignedReports(); // Refresh the list

      // Update the selected report in modal
      if (selectedReport && selectedReport.id === reportId) {
        setSelectedReport({ ...selectedReport, status: statusToUpdate });
      }

      // Show success animation
      setUpdateSuccess(true);
      setTimeout(() => {
        setUpdateSuccess(false);
        setNewStatus('');
      }, 2000);
    } catch (error) {
      console.error('Error updating report status:', error);
      alert('Failed to update report status. Please try again.');
    }
  };

  const handleUpdateClick = () => {
    if (newStatus && newStatus !== selectedReport.status) {
      handleStatusChange(selectedReport.id, newStatus);
    }
  };


  const getNextStatus = (currentStatus) => {
    switch (currentStatus) {
      case 'Received':
        return 'In Progress';
      case 'In Progress':
        return 'Resolved';
      default:
        return null;
    }
  };

  const getAvailableStatuses = (currentStatus) => {
    const allStatuses = ['Received', 'In Progress', 'Resolved'];
    const currentIndex = allStatuses.indexOf(currentStatus);

    // Allow moving forward in the workflow or staying at current status
    if (currentStatus === 'Received') {
      return ['Received', 'In Progress', 'Resolved'];
    } else if (currentStatus === 'In Progress') {
      return ['In Progress', 'Resolved'];
    } else {
      return ['Resolved']; // Can't go back from Resolved
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">My Reports</h1>
          <p className="text-gray-600 mt-1">Manage your assigned reports</p>
        </div>
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <select
            value={sortOrder}
            onChange={(e) => setSortOrder(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none flex-1 sm:flex-none"
          >
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
          </select>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 space-y-4 overflow-x-auto whitespace-nowrap no-scrollbar">
        {/* Status Filters */}
        <div className="flex items-center gap-2 flex-nowrap md:flex-wrap">
          <span className="text-sm font-medium text-gray-700 mr-2">Status:</span>
          {['all', 'pending', 'in_progress', 'resolved'].map((filterType) => (
            <button
              key={filterType}
              onClick={() => handleStatusFilterChange(filterType)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition ${statusFilter === filterType
                ? 'bg-primary-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
            >
              {filterType === 'all'
                ? `All (${statusFilterCounts.all})`
                : filterType === 'pending'
                  ? `Received (${statusFilterCounts.pending})`
                  : filterType === 'in_progress'
                    ? `In Progress (${statusFilterCounts.in_progress})`
                    : `Resolved (${statusFilterCounts.resolved})`}
            </button>
          ))}
        </div>

        {/* Priority Filters */}
        <div className="flex items-center gap-2 flex-nowrap md:flex-wrap">
          <span className="text-sm font-medium text-gray-700 mr-2">Priority:</span>
          {['all', 'low', 'medium', 'high'].map((priorityType) => (
            <button
              key={priorityType}
              onClick={() => setPriorityFilter(priorityType)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition ${priorityFilter === priorityType
                ? 'bg-primary-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
            >
              {priorityType === 'all'
                ? `All (${priorityFilterCounts.all})`
                : `${priorityType.charAt(0).toUpperCase() + priorityType.slice(1)} (${priorityFilterCounts[priorityType]})`}
            </button>
          ))}
        </div>
      </div>

      {/* Reports List */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        {sortedReports.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-gray-500 text-lg">No reports found</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {sortedReports.map((report) => {
              return (
                <div key={report.id} className="p-6 hover:bg-gray-50 transition">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0">
                      <UserAvatar
                        userId={report.userId}
                        userName={report.userName}
                        profilePicture={null}
                        size="md"
                        onClick={() => setSelectedUserId(report.userId)}
                      />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1 flex-wrap">
                            <h3 className="text-lg font-semibold text-gray-900 truncate">
                              {report.title}
                            </h3>
                            <span
                              className={`px-3 py-1 text-xs font-medium rounded-full border ${getStatusColor(
                                report.status
                              )} whitespace-nowrap`}
                            >
                              {report.status}
                            </span>
                          </div>
                          <p className="text-gray-600 mb-2">{report.description}</p>
                          <div className="flex flex-wrap items-center gap-2 text-sm text-gray-500">
                            <span className="truncate">{report.userName}</span>
                            <span className="hidden sm:inline">•</span>
                            <span className="truncate">{report.userLocation}</span>
                            <span className="hidden sm:inline">•</span>
                            <span className="truncate">{report.faultType}</span>
                            <span className="hidden sm:inline">•</span>
                            <span className="truncate">{formatDateTime(report.createdAt)}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0 w-full sm:w-auto justify-end">
                          {report.priority && (
                            <span
                              className={`px-3 py-1 text-xs font-medium rounded-full ${report.priority === 'high'
                                ? 'bg-red-100 text-red-700'
                                : report.priority === 'medium'
                                  ? 'bg-yellow-100 text-yellow-700'
                                  : 'bg-green-100 text-green-700'
                                }`}
                            >
                              {report.priority}
                            </span>
                          )}
                          <button
                            onClick={() => {
                              setSelectedReport(report);
                              setNewStatus(report.status);
                              setUpdateSuccess(false);
                            }}
                            className="p-2 hover:bg-gray-100 rounded-lg transition"
                            title="View Details"
                          >
                            <Eye className="w-5 h-5 text-gray-600" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Report Details Modal */}
      {selectedReport && createPortal(
        <div className="fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]" style={{ margin: 0, padding: 0 }}>
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto m-4">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h2 className="text-2xl font-bold text-gray-900">Report Details</h2>
              <button
                onClick={() => setSelectedReport(null)}
                className="p-2 hover:bg-gray-100 rounded-lg transition"
              >
                <span className="text-2xl">&times;</span>
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-500">Title</label>
                <p className="text-gray-900 mt-1">{selectedReport.title}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Description</label>
                <p className="text-gray-900 mt-1">{selectedReport.description}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Fault Type</label>
                <p className="text-gray-900 mt-1">{selectedReport.faultType}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Current Status</label>
                <div className="mt-2">
                  <span
                    className={`px-3 py-1 text-xs font-medium rounded-full border ${getStatusColor(
                      selectedReport.status
                    )}`}
                  >
                    {selectedReport.status}
                  </span>
                </div>
              </div>

              {/* Update Status Section */}
              <div className="pt-4 border-t border-gray-200">
                <label className="text-sm font-medium text-gray-700 mb-3 block">
                  Update Status
                </label>
                <div className="flex items-center gap-3">
                  <select
                    value={newStatus || selectedReport.status}
                    onChange={(e) => setNewStatus(e.target.value)}
                    className="px-4 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none bg-white font-medium flex-1"
                  >
                    {getAvailableStatuses(selectedReport.status).map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={handleUpdateClick}
                    disabled={!newStatus || newStatus === selectedReport.status || updateSuccess}
                    className={`px-6 py-2 text-sm font-medium rounded-lg transition flex items-center gap-2 ${updateSuccess
                      ? 'bg-green-500 text-white'
                      : 'bg-primary-600 hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed text-white'
                      }`}
                  >
                    {updateSuccess ? (
                      <>
                        <Check className="w-4 h-4" />
                        Updated!
                      </>
                    ) : (
                      'Update'
                    )}
                  </button>
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Customer</label>
                <div className="flex items-center gap-2 mt-1">
                  <UserAvatar
                    userId={selectedReport.userId}
                    userName={selectedReport.userName}
                    profilePicture={null}
                    size="sm"
                    onClick={() => {
                      setSelectedUserId(selectedReport.userId);
                      setSelectedReport(null);
                    }}
                  />
                  <p className="text-gray-900">{selectedReport.userName}</p>
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Location</label>
                <p className="text-gray-900 mt-1">{selectedReport.userLocation}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Priority</label>
                <p className="text-gray-900 mt-1">{selectedReport.priority || 'Not set'}</p>
              </div>
            </div>
          </div>
        </div>,
        document.body
      )}

      {/* User Profile Modal */}
      {selectedUserId && (
        <UserProfileModal
          userId={selectedUserId}
          onClose={() => setSelectedUserId(null)}
        />
      )}
    </div>
  );
}

