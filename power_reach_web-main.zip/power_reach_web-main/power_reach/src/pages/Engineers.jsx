import { useState } from 'react';
import { useAgent } from '../context/AgentContext';
import { Wrench, X, User, Mail, Phone, MapPin } from 'lucide-react';
import { Copy, Check } from 'lucide-react';

const abujaLocations = ['Wuse II', 'Gwarimpa', 'Jabi', 'Maitama', 'Asokoro'];

function EngineerProfileModal({ engineer, onClose }) {
  const [copied, setCopied] = useState(false);

  const handleCopyId = async () => {
    try {
      await navigator.clipboard.writeText(engineer.readableId || engineer.id);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  return (
    <div className="fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]" style={{ margin: 0, padding: 0 }}>
      <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 m-4">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Engineer Profile</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="flex items-center gap-4">
            {engineer.profile_picture ? (
              <img
                src={engineer.profile_picture}
                alt={engineer.name}
                className="w-20 h-20 rounded-full object-cover"
                onError={(e) => {
                  e.target.style.display = 'none';
                  const fallback = e.target.nextElementSibling;
                  if (fallback) fallback.style.display = 'flex';
                }}
              />
            ) : null}
            <div
              className={`w-20 h-20 bg-primary-600 rounded-full flex items-center justify-center text-white font-bold text-xl ${engineer.profile_picture ? 'hidden' : ''
                }`}
            >
              {engineer.name
                .split(' ')
                .map((n) => n[0])
                .join('')
                .toUpperCase()
                .slice(0, 2)}
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">{engineer.name}</h3>
              <p className="text-gray-600">{engineer.specialization}</p>
            </div>
          </div>

          <div className="space-y-3 pt-4 border-t border-gray-200">
            <div className="flex items-center gap-3">
              <User className="w-5 h-5 text-gray-400" />
              <div className="flex-1">
                <p className="text-sm text-gray-500">Name</p>
                <p className="font-medium text-gray-900">{engineer.name}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-5 h-5 flex items-center justify-center">
                <span className="text-xs font-mono text-gray-400">ID</span>
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-500">Engineer ID</p>
                <div className="flex items-center gap-2">
                  <p className="font-mono text-sm text-gray-900">{engineer.readableId || engineer.id}</p>
                  <button
                    onClick={handleCopyId}
                    className="p-1 hover:bg-gray-100 rounded transition"
                    title="Copy ID"
                  >
                    {copied ? (
                      <Check className="w-4 h-4 text-green-600" />
                    ) : (
                      <Copy className="w-4 h-4 text-gray-400" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Phone className="w-5 h-5 text-gray-400" />
              <div className="flex-1">
                <p className="text-sm text-gray-500">Phone</p>
                <p className="font-medium text-gray-900">{engineer.phone}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Mail className="w-5 h-5 text-gray-400" />
              <div className="flex-1">
                <p className="text-sm text-gray-500">Email</p>
                <p className="font-medium text-gray-900">{engineer.email}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <MapPin className="w-5 h-5 text-gray-400" />
              <div className="flex-1">
                <p className="text-sm text-gray-500">Branch</p>
                <p className="font-medium text-gray-900">{engineer.branch || 'Unassigned'}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Engineers() {
  const { engineers } = useAgent();
  const [selectedBranch, setSelectedBranch] = useState('all');
  const [selectedEngineer, setSelectedEngineer] = useState(null);
  const [copiedEngineerId, setCopiedEngineerId] = useState(null);

  const filteredEngineers =
    selectedBranch === 'all'
      ? engineers
      : engineers.filter((eng) => eng.branch === selectedBranch);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Engineers Directory</h1>
          <p className="text-gray-600 mt-1">View and manage engineering team</p>
        </div>
      </div>

      {/* Filter */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
        <div className="flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-0 justify-between">
          <div className="flex items-center gap-4 w-full sm:w-auto">
            <label className="text-sm font-medium text-gray-700 whitespace-nowrap">Filter by Branch:</label>
            <select
              value={selectedBranch}
              onChange={(e) => setSelectedBranch(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none flex-1 sm:flex-none"
            >
              <option value="all">All Branches</option>
              {abujaLocations.map((branch) => (
                <option key={branch} value={branch}>
                  {branch}
                </option>
              ))}
            </select>
          </div>
          <div className="text-sm text-gray-600">
            Showing {filteredEngineers.length} Engineer{filteredEngineers.length !== 1 ? 's' : ''}
          </div>
        </div>
      </div>

      {/* Engineers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredEngineers.length === 0 ? (
          <div className="col-span-full text-center py-12">
            <Wrench className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">No engineers found</p>
          </div>
        ) : (
          filteredEngineers.map((engineer) => (
            <div
              key={engineer.id}
              className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition cursor-pointer"
              onClick={() => setSelectedEngineer(engineer)}
            >
              <div className="flex items-center gap-4 mb-4">
                {engineer.profile_picture ? (
                  <img
                    src={engineer.profile_picture}
                    alt={engineer.name}
                    className="w-16 h-16 rounded-full object-cover"
                    onError={(e) => {
                      e.target.style.display = 'none';
                      const fallback = e.target.nextElementSibling;
                      if (fallback) fallback.style.display = 'flex';
                    }}
                  />
                ) : null}
                <div
                  className={`w-16 h-16 bg-primary-600 rounded-full flex items-center justify-center text-white font-bold text-lg ${engineer.profile_picture ? 'hidden' : ''
                    }`}
                >
                  {engineer.name
                    .split(' ')
                    .map((n) => n[0])
                    .join('')
                    .toUpperCase()
                    .slice(0, 2)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-gray-900 truncate">{engineer.name}</h3>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        navigator.clipboard.writeText(engineer.readableId || engineer.id);
                        setCopiedEngineerId(engineer.id);
                        setTimeout(() => setCopiedEngineerId(null), 2000);
                      }}
                      className="p-1 hover:bg-gray-200 rounded transition flex-shrink-0"
                      title="Copy Engineer ID"
                    >
                      {copiedEngineerId === engineer.id ? (
                        <Check className="w-3 h-3 text-green-600" />
                      ) : (
                        <Copy className="w-3 h-3 text-gray-400" />
                      )}
                    </button>
                  </div>
                  <p className="text-sm text-gray-600 truncate">{engineer.specialization}</p>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <MapPin className="w-4 h-4" />
                  <span>{engineer.branch || 'Unassigned'}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Phone className="w-4 h-4" />
                  <span>{engineer.phone}</span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Profile Modal */}
      {selectedEngineer && (
        <EngineerProfileModal
          engineer={selectedEngineer}
          onClose={() => setSelectedEngineer(null)}
        />
      )}
    </div>
  );
}

