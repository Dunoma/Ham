import { useNavigate } from 'react-router-dom';
import { useAgent } from '../context/AgentContext';
import {
  FileText,
  MessageSquare,
  Zap,
  Bell,
  TrendingUp,
  Copy,
  Check,
  Eye,
  X,
  CheckCircle,
} from 'lucide-react';
import { useState } from 'react';
import AgentSendNotificationModal from '../components/AgentSendNotificationModal';
import ReportFormModal from '../components/ReportFormModal';
import UserAvatar from '../components/UserAvatar';
import UserProfileModal from '../components/UserProfileModal';
import { formatDateTime } from '../utils/dateFormat';

export default function Dashboard() {
  const navigate = useNavigate();
  const {
    user,
    users,
    reports,
    chats,
    messages,
    engineers,
    updateReport,
    pendingReportsCount,
    unreadMessagesCount,
    unclaimedSparkyCount,
  } = useAgent();
  const [showNotificationModal, setShowNotificationModal] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [copiedUserId, setCopiedUserId] = useState(null);
  const [selectedReport, setSelectedReport] = useState(null);
  const [forwardEngineerId, setForwardEngineerId] = useState('');
  const [selectedPriority, setSelectedPriority] = useState('');
  const [showSuccessToast, setShowSuccessToast] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  const stats = [
    {
      title: 'Pending Reports',
      value: pendingReportsCount,
      icon: FileText,
      color: 'bg-orange-500',
      onClick: () => navigate('/agent/reports?filter=unassigned'),
    },
    {
      title: 'Unread Messages',
      value: unreadMessagesCount,
      icon: MessageSquare,
      color: 'bg-blue-500',
      onClick: () => navigate('/agent/messages?filter=unread'),
    },
    {
      title: 'New Sparky Reports',
      value: unclaimedSparkyCount,
      icon: Zap,
      color: 'bg-yellow-500',
      onClick: () => navigate('/agent/reports?filter=sparky'),
    },
    {
      title: 'Total Reports',
      value: reports.length,
      icon: TrendingUp,
      color: 'bg-primary-600',
      onClick: () => navigate('/agent/reports'),
    },
  ];

  // Sort reports by time (most recent first) and take top 5
  const recentReports = [...reports]
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 5);

  // Group messages by chatId and get most recent message from each conversation
  const conversations = messages.reduce((acc, message) => {
    const chatId = message.chatId;
    if (!acc[chatId] || new Date(message.createdAt) > new Date(acc[chatId].createdAt)) {
      acc[chatId] = message;
    }
    return acc;
  }, {});

  // Sort conversations by most recent message time and take top 5
  // Map to include chat and user info
  const recentMessages = Object.values(conversations)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 5)
    .map((message) => {
      const chat = chats.find((c) => c.id === message.chatId);
      const customer = chat ? users.find((u) => u.id === chat.customerId) : null;
      return {
        ...message,
        chatId: message.chatId,
        customerId: chat?.customerId,
        customerName: customer?.name || 'Unknown',
        customerLocation: customer?.location || '',
      };
    });

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">Welcome back, {user?.name || 'Agent'}</p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setShowNotificationModal(true)}
            className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg transition"
          >
            <Bell className="w-5 h-5" />
            <span className="hidden md:inline">Send Notification</span>
          </button>
          <button
            onClick={() => setShowReportModal(true)}
            className="flex items-center gap-2 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-4 py-2 rounded-lg transition"
          >
            <FileText className="w-5 h-5" />
            <span className="hidden md:inline">File New Report</span>
          </button>
          <div className="p-2 hover:bg-gray-100 rounded-lg transition">
            <UserAvatar
              userId={user?.id}
              userName={user?.name || 'Agent'}
              profilePicture={user?.profile_picture}
              size="md"
              onClick={() => navigate('/agent/profile')}
            />
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <button
              key={index}
              onClick={stat.onClick}
              className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition cursor-pointer text-left"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`${stat.color} p-3 rounded-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</h3>
              <p className="text-sm text-gray-600">{stat.title}</p>
            </button>
          );
        })}
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Reports */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Recent Reports</h2>
            <button
              onClick={() => navigate('/agent/reports')}
              className="text-primary-600 hover:text-primary-700 text-sm font-medium"
            >
              View All
            </button>
          </div>
          <div className="space-y-3">
            {recentReports.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No reports yet</p>
            ) : (
              recentReports.map((report) => (
                <div
                  key={report.id}
                  className="flex items-start gap-3 p-3 hover:bg-gray-50 rounded-lg transition"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-medium text-gray-900 truncate">{report.title}</p>
                      {report.isSparkyReport && (
                        <Zap className="w-4 h-4 text-accent-500 flex-shrink-0" />
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <p className="text-sm text-gray-600 truncate">{report.userName}</p>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          navigator.clipboard.writeText(report.userId);
                          setCopiedUserId(report.userId);
                          setTimeout(() => setCopiedUserId(null), 2000);
                        }}
                        className="p-1 hover:bg-gray-200 rounded transition"
                        title="Copy User ID"
                      >
                        {copiedUserId === report.userId ? (
                          <Check className="w-3 h-3 text-green-600" />
                        ) : (
                          <Copy className="w-3 h-3 text-gray-400" />
                        )}
                      </button>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {report.userLocation} • {formatDateTime(report.createdAt)}
                    </p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedReport(report);
                    }}
                    className="p-2 hover:bg-gray-200 rounded transition flex-shrink-0"
                    title="View Details"
                  >
                    <Eye className="w-4 h-4 text-gray-600" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Recent Messages */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Recent Messages</h2>
            <button
              onClick={() => navigate('/agent/messages')}
              className="text-primary-600 hover:text-primary-700 text-sm font-medium"
            >
              View All
            </button>
          </div>
          <div className="space-y-3">
            {recentMessages.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No messages yet</p>
            ) : (
              recentMessages.map((message) => (
                <div
                  key={message.id}
                  className="flex items-start gap-3 p-3 hover:bg-gray-50 rounded-lg cursor-pointer transition"
                  onClick={() => navigate(`/agent/chat/${message.chatId}`)}
                >
                  <UserAvatar
                    userId={message.customerId}
                    userName={message.customerName}
                    profilePicture={null}
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      if (message.customerId) setSelectedUserId(message.customerId);
                    }}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-medium text-gray-900">{message.customerName}</p>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          navigator.clipboard.writeText(message.customerId);
                          setCopiedUserId(message.customerId);
                          setTimeout(() => setCopiedUserId(null), 2000);
                        }}
                        className="p-1 hover:bg-gray-200 rounded transition"
                        title="Copy User ID"
                      >
                        {copiedUserId === message.customerId ? (
                          <Check className="w-3 h-3 text-green-600" />
                        ) : (
                          <Copy className="w-3 h-3 text-gray-400" />
                        )}
                      </button>
                      {message.isSparkyReport && (
                        <Zap className="w-4 h-4 text-yellow-500" />
                      )}
                      {!message.isRead && (
                        <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                      )}
                    </div>
                    <p className="text-sm text-gray-600 truncate">{message.content}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {message.customerLocation} • {formatDateTime(message.createdAt)}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Notification Modal */}
      {showNotificationModal && (
        <AgentSendNotificationModal
          onClose={() => setShowNotificationModal(false)}
          onSuccess={() => {
            setSuccessMessage('Notification sent successfully!');
            setShowSuccessToast(true);
            setTimeout(() => setShowSuccessToast(false), 3000);
          }}
        />
      )}

      {/* Report Form Modal */}
      {showReportModal && (
        <ReportFormModal
          onClose={() => setShowReportModal(false)}
          onSuccess={() => {
            setSuccessMessage('Report filed successfully!');
            setShowSuccessToast(true);
            setTimeout(() => setShowSuccessToast(false), 3000);
          }}
        />
      )}

      {/* Report Details Modal */}
      {selectedReport && (
        <div className="fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]" style={{ margin: 0, padding: 0 }}>
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto m-4">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h2 className="text-2xl font-bold text-gray-900">Report Details</h2>
              <button
                onClick={() => {
                  setSelectedReport(null);
                  setForwardEngineerId('');
                  setSelectedPriority('');
                }}
                className="p-2 hover:bg-gray-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-500">Title</label>
                <p className="text-gray-900 mt-1">{selectedReport.title}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Description</label>
                <p className="text-gray-900 mt-1">{selectedReport.description}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Fault Type</label>
                <p className="text-gray-900 mt-1">{selectedReport.faultType}</p>
              </div>

              {/* Priority Section */}
              {selectedReport.priority ? (
                <div>
                  <label className="text-sm font-medium text-gray-500">Priority</label>
                  <p className="text-gray-900 mt-1">{selectedReport.priority}</p>
                </div>
              ) : (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Priority <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={selectedPriority}
                    onChange={(e) => setSelectedPriority(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none"
                  >
                    <option value="">Select Priority</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                </div>
              )}

              {/* Attachments Section */}
              <div>
                <label className="text-sm font-medium text-gray-500">Attachments</label>
                <div className="mt-2 p-4 bg-gray-50 rounded-lg border border-gray-200">
                  <p className="text-sm text-gray-500">No attachments available</p>
                </div>
              </div>

              {/* Assigned Engineer Section */}
              {selectedReport.assignedEngineerId ? (
                <div>
                  <label className="text-sm font-medium text-gray-500">Assigned Engineer</label>
                  <p className="text-gray-900 mt-1">
                    {engineers.find((e) => e.id === selectedReport.assignedEngineerId)?.name || 'Unknown Engineer'}
                  </p>
                </div>
              ) : null}

              <div>
                <label className="text-sm font-medium text-gray-500">Customer</label>
                <p className="text-gray-900 mt-1">{selectedReport.userName}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Location</label>
                <p className="text-gray-900 mt-1">{selectedReport.userLocation}</p>
              </div>

              {/* Assignment Section - Only show if not assigned */}
              {!selectedReport.assignedEngineerId && (
                <div className="pt-4 border-t border-gray-200">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Assign to Engineer
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={forwardEngineerId}
                      onChange={(e) => setForwardEngineerId(e.target.value)}
                      placeholder="Enter Engineer ID or UUID"
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none"
                    />
                    <button
                      onClick={async () => {
                        if (!forwardEngineerId.trim()) {
                          alert('Please enter an Engineer UUID or ID');
                          return;
                        }

                        if (!selectedPriority && !selectedReport.priority) {
                          alert('Please select a priority before assigning to an engineer.');
                          return;
                        }

                        const cleanId = forwardEngineerId.trim();
                        const engineer = engineers.find((e) => e.id === cleanId || e.readableId === cleanId);
                        if (!engineer) {
                          alert('Engineer not found. Please check the ID.');
                          return;
                        }

                        try {
                          await updateReport(selectedReport.id, {
                            assignedEngineerId: engineer.id,
                            assignedBy: user?.id,
                            assignedTo: engineer.id,
                            priority: selectedPriority || selectedReport.priority,
                            status: 'in_progress',
                          });

                          setSuccessMessage('Report assigned successfully!');
                          setShowSuccessToast(true);
                          setTimeout(() => {
                            setShowSuccessToast(false);
                            setSelectedReport(null);
                            setForwardEngineerId('');
                            setSelectedPriority('');
                          }, 2000);
                        } catch (error) {
                          alert('Failed to assign report. Please try again.');
                        }
                      }}
                      disabled={!selectedPriority && !selectedReport.priority}
                      className="px-4 py-2 bg-primary-600 hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg transition"
                    >
                      Assign
                    </button>
                  </div>
                  {!selectedPriority && !selectedReport.priority && (
                    <p className="text-xs text-red-500 mt-1">Please select a priority first</p>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Success Toast */}
      {showSuccessToast && (
        <div className="fixed bottom-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg flex items-center gap-2 z-[10000] animate-slide-up">
          <CheckCircle className="w-5 h-5" />
          <span className="font-medium">{successMessage}</span>
        </div>
      )}

      {/* User Profile Modal */}
      {selectedUserId && (
        <UserProfileModal
          userId={selectedUserId}
          onClose={() => setSelectedUserId(null)}
        />
      )}
    </div>
  );
}

