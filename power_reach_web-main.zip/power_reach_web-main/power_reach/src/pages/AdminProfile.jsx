import { useState } from 'react';
import { createPortal } from 'react-dom';
import { useAdmin } from '../context/AdminContext';
import { authApi } from '../services/api';
import { User, Mail, Phone, MapPin, Briefcase, LogOut, Copy, Check, Shield, Lock, X, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function AdminProfile() {
    const { user } = useAdmin();
    const navigate = useNavigate();
    const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
    const [showPasswordModal, setShowPasswordModal] = useState(false);
    const [copiedId, setCopiedId] = useState(false);

    const handleLogout = () => {
        navigate('/admin/login');
    };

    const getInitials = (name) => {
        return name
            ? name.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2)
            : 'AD';
    };

    if (!user) return null;

    return (
        <div className="p-6">
            <div className="max-w-3xl mx-auto">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-gray-900">Profile</h1>
                    <p className="text-gray-600 mt-1">Manage your account information</p>
                </div>

                {/* Profile Card */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
                    <div className="flex flex-col items-center sm:flex-row sm:items-center gap-6 mb-8 text-center sm:text-left">
                        <div
                            className="w-20 h-20 bg-primary-600 rounded-full flex items-center justify-center text-white font-bold text-2xl"
                        >
                            {getInitials(user.name)}
                        </div>
                        <div>
                            <h2 className="text-2xl font-bold text-gray-900">{user.name}</h2>
                            <p className="text-gray-600">System Administrator</p>
                        </div>
                    </div>

                    {/* Profile Information */}
                    <div className="space-y-6">
                        <div className="flex items-start gap-4">
                            <div className="p-3 bg-primary-50 rounded-lg">
                                <User className="w-5 h-5 text-primary-600" />
                            </div>
                            <div className="flex-1">
                                <label className="text-sm font-medium text-gray-500">Name</label>
                                <p className="text-gray-900 mt-1">{user.name}</p>
                            </div>
                        </div>

                        <div className="flex items-start gap-4">
                            <div className="p-3 bg-primary-50 rounded-lg">
                                <Mail className="w-5 h-5 text-primary-600" />
                            </div>
                            <div className="flex-1">
                                <label className="text-sm font-medium text-gray-500">Email Address</label>
                                <p className="text-gray-900 mt-1">{user.email}</p>
                            </div>
                        </div>

                        <div className="flex items-start gap-4">
                            <div className="p-3 bg-primary-50 rounded-lg">
                                <Phone className="w-5 h-5 text-primary-600" />
                            </div>
                            <div className="flex-1">
                                <label className="text-sm font-medium text-gray-500">Phone Number</label>
                                <p className="text-gray-900 mt-1">{user.phone || 'N/A'}</p>
                            </div>
                        </div>

                        <div className="flex items-start gap-4">
                            <div className="p-3 bg-primary-50 rounded-lg">
                                <MapPin className="w-5 h-5 text-primary-600" />
                            </div>
                            <div className="flex-1">
                                <label className="text-sm font-medium text-gray-500">Location</label>
                                <p className="text-gray-900 mt-1">{user.branch || 'N/A'}</p>
                            </div>
                        </div>



                        <div className="flex items-start gap-4">
                            <div className="p-3 bg-primary-50 rounded-lg">
                                <Shield className="w-5 h-5 text-primary-600" />
                            </div>
                            <div className="flex-1">
                                <label className="text-sm font-medium text-gray-500">Admin ID</label>
                                <div className="flex items-center gap-2 mt-1">
                                    <p className="text-gray-900 font-mono">{user.readableId || 'AD-XXX'}</p>
                                    {(user.readableId) && (
                                        <button
                                            onClick={async () => {
                                                try {
                                                    await navigator.clipboard.writeText(user.readableId);
                                                    setCopiedId(true);
                                                    setTimeout(() => setCopiedId(false), 2000);
                                                } catch (err) {
                                                    console.error('Failed to copy:', err);
                                                }
                                            }}
                                            className="p-1 hover:bg-gray-100 rounded transition relative"
                                            title="Copy Admin ID"
                                        >
                                            {copiedId ? (
                                                <Check className="w-4 h-4 text-green-600" />
                                            ) : (
                                                <Copy className="w-4 h-4 text-gray-400" />
                                            )}
                                            {copiedId && (
                                                <span className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white text-xs px-2 py-1 rounded whitespace-nowrap">
                                                    Copied!
                                                </span>
                                            )}
                                        </button>
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* Password Update Section */}
                        <div className="flex items-start gap-4">
                            <div className="p-3 bg-primary-50 rounded-lg">
                                <Lock className="w-5 h-5 text-primary-600" />
                            </div>
                            <div className="flex-1">
                                <label className="text-sm font-medium text-gray-500">Security</label>
                                <div className="mt-1">
                                    <button
                                        onClick={() => setShowPasswordModal(true)}
                                        className="text-primary-600 hover:text-primary-700 font-medium text-sm transition flex items-center gap-1"
                                    >
                                        Change Password
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Logout Button */}
                    <div className="mt-8 pt-8 border-t border-gray-200">
                        <button
                            onClick={() => setShowLogoutConfirm(true)}
                            className="flex items-center gap-2 text-red-600 hover:text-red-700 font-medium transition"
                        >
                            <LogOut className="w-5 h-5" />
                            Logout
                        </button>
                    </div>
                </div>
            </div>

            {/* Logout Confirmation Dialog */}
            {showLogoutConfirm && (
                <div className="fixed top-0 left-0 right-0 bottom-0 bg-black/50 flex items-center justify-center z-[9999]">
                    <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 m-4 animate-fade-in-up">
                        <h3 className="text-xl font-bold text-gray-900 mb-2">Confirm Logout</h3>
                        <p className="text-gray-600 mb-6">Are you sure you want to logout?</p>
                        <div className="flex items-center justify-end gap-3">
                            <button
                                onClick={() => setShowLogoutConfirm(false)}
                                className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={handleLogout}
                                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition"
                            >
                                Logout
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Password Change Modal */}
            {showPasswordModal && (
                <ChangePasswordModal
                    onClose={() => setShowPasswordModal(false)}
                    onSave={authApi.changePassword}
                />
            )}
        </div>
    );
}

function ChangePasswordModal({ onClose, onSave }) {
    const [formData, setFormData] = useState({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
    });
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        if (formData.newPassword !== formData.confirmPassword) {
            setError("New passwords do not match");
            return;
        }

        setIsSubmitting(true);
        try {
            await onSave(formData.currentPassword, formData.newPassword);
            setIsSuccess(true);
            setTimeout(() => {
                onClose();
            }, 2000);
        } catch (e) {
            setError(e?.message || "Failed to update password");
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

    if (isSuccess) {
        return createPortal(
            <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-4">
                <div className="bg-white rounded-xl shadow-xl w-full max-w-sm p-8 flex flex-col items-center animate-fade-in-up">
                    <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-4 animate-bounce-short">
                        <CheckCircle className="w-10 h-10 text-green-600" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Password Updated!</h3>
                    <p className="text-gray-500 text-center">Your password has been changed successfully.</p>
                </div>
            </div>,
            document.body
        );
    }

    return createPortal(
        <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-xl w-full max-w-md animate-fade-in-up">
                <div className="flex items-center justify-between p-6 border-b border-gray-200">
                    <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                        Change Password
                    </h2>
                    <button onClick={onClose}><X className="w-5 h-5 text-gray-400" /></button>
                </div>
                <form onSubmit={handleSubmit} className="p-6 space-y-4">
                    {error && <div className="p-3 bg-red-50 text-red-700 rounded-lg text-sm">{error}</div>}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Current Password</label>
                        <input name="currentPassword" type="password" required className="w-full px-3 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-primary-500" onChange={handleChange} />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                        <input name="newPassword" type="password" required className="w-full px-3 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-primary-500" onChange={handleChange} />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Confirm New Password</label>
                        <input name="confirmPassword" type="password" required className="w-full px-3 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-primary-500" onChange={handleChange} />
                    </div>
                    <div className="flex justify-end gap-3 pt-4 border-t border-gray-100">
                        <button type="button" onClick={onClose} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button>
                        <button type="submit" disabled={isSubmitting} className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50 font-medium">
                            {isSubmitting ? 'Updating...' : 'Update Password'}
                        </button>
                    </div>
                </form>
            </div>
        </div>,
        document.body
    );
}
