import { useState } from 'react';
import { useAgent } from '../context/AgentContext';
import { ChevronDown, ChevronUp, Shield, Bell, ArrowDownLeft, ArrowUpRight } from 'lucide-react';
import { formatDateTime } from '../utils/dateFormat';
import AgentSendNotificationModal from '../components/AgentSendNotificationModal';

export default function AgentNotifications() {
    const { user, notifications, fetchNotifications } = useAgent();
    const [showSendModal, setShowSendModal] = useState(false);
    const [expandedNotifications, setExpandedNotifications] = useState(new Set());
    const [urgencyFilter, setUrgencyFilter] = useState('all'); // 'all', 'low', 'medium', 'high', 'critical'
    const [typeFilter, setTypeFilter] = useState('all'); // 'all', 'received', 'sent'

    // Filter notifications (Additive Logic)
    const filteredNotifications = notifications.filter((notification) => {
        // 0. Guard Clause: Ensure user data is available for ID comparison
        if (!user) return false;

        // 1. Filter by Direction (Type)
        let matchesDirection = false;
        if (typeFilter === 'all') {
            matchesDirection = notification.recipientId === user.id || notification.senderId === user.id;
        } else if (typeFilter === 'received') {
            matchesDirection = notification.recipientId === user.id;
        } else if (typeFilter === 'sent') {
            matchesDirection = notification.senderId === user.id;
        }

        if (!matchesDirection) return false;

        // 2. Filter by Priority (Urgency)
        // Only apply if urgencyFilter is not 'all'
        if (urgencyFilter !== 'all') {
            if (notification.urgency !== urgencyFilter) return false;
        }

        return true;
    });

    // Sort by timestamp (newest first)
    const sortedNotifications = [...filteredNotifications].sort((a, b) => {
        return new Date(b.timestamp) - new Date(a.timestamp);
    });

    const toggleNotification = (notificationId) => {
        const newExpanded = new Set(expandedNotifications);
        if (newExpanded.has(notificationId)) {
            newExpanded.delete(notificationId);
        } else {
            newExpanded.add(notificationId);
        }
        setExpandedNotifications(newExpanded);
    };

    const getUrgencyColor = (urgency) => {
        switch (urgency) {
            case 'low': return 'bg-blue-500';
            case 'medium': return 'bg-yellow-500';
            case 'high': return 'bg-orange-500';
            case 'critical': return 'bg-red-500';
            default: return 'bg-gray-500';
        }
    };

    const getUrgencyBorderColor = (urgency) => {
        switch (urgency) {
            case 'low': return 'border-l-blue-500';
            case 'medium': return 'border-l-yellow-500';
            case 'high': return 'border-l-orange-500';
            case 'critical': return 'border-l-red-500';
            default: return 'border-l-gray-500';
        }
    };

    const getUrgencyLabel = (urgency) => {
        const labels = { low: 'Low', medium: 'Med', high: 'High', critical: 'Critical' };
        return labels[urgency] || urgency.charAt(0).toUpperCase() + urgency.slice(1);
    };

    return (
        <div className="p-6 space-y-6">
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">Notifications</h1>
                    <p className="text-gray-600 mt-1">Stay updated with important messages</p>
                </div>
                <button
                    onClick={() => setShowSendModal(true)}
                    className="flex items-center justify-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg transition w-full sm:w-auto"
                >
                    <Bell className="w-5 h-5" />
                    Send Notification
                </button>
            </div>

            {/* Filters */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 space-y-4 md:space-y-0 md:flex md:items-center md:justify-between">
                {/* Type Filter Tabs */}
                <div className="flex bg-gray-100 p-1 rounded-lg">
                    <button
                        onClick={() => setTypeFilter('all')}
                        className={`px-4 py-2 rounded-md text-sm font-medium transition ${typeFilter === 'all' ? 'bg-primary-600 text-white shadow-sm' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                            }`}
                    >
                        All
                    </button>
                    <button
                        onClick={() => setTypeFilter('received')}
                        className={`px-4 py-2 rounded-md text-sm font-medium transition ${typeFilter === 'received' ? 'bg-primary-600 text-white shadow-sm' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                            }`}
                    >
                        Received
                    </button>
                    <button
                        onClick={() => setTypeFilter('sent')}
                        className={`px-4 py-2 rounded-md text-sm font-medium transition ${typeFilter === 'sent' ? 'bg-primary-600 text-white shadow-sm' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                            }`}
                    >
                        Sent
                    </button>
                </div>

                {/* Urgency Filter */}
                <div className="flex bg-gray-100 p-1 rounded-lg overflow-x-auto">
                    {[
                        { value: 'all', label: 'All' },
                        { value: 'low', label: 'Low' },
                        { value: 'medium', label: 'Med' },
                        { value: 'high', label: 'High' },
                        { value: 'critical', label: 'Crit' },
                    ].map((option) => (
                        <button
                            key={option.value}
                            onClick={() => setUrgencyFilter(option.value)}
                            className={`px-3 py-2 rounded-md text-sm font-medium transition whitespace-nowrap ${urgencyFilter === option.value
                                ? 'bg-primary-600 text-white shadow-sm'
                                : 'text-gray-700 hover:bg-gray-200'
                                }`}
                        >
                            {option.label}
                        </button>
                    ))}
                </div>
            </div>

            {/* Notifications List */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                {sortedNotifications.length === 0 ? (
                    <div className="p-12 text-center">
                        <p className="text-gray-500 text-lg">No notifications found</p>
                    </div>
                ) : (
                    <div className="divide-y divide-gray-200">
                        {sortedNotifications.map((notification) => {
                            const isExpanded = expandedNotifications.has(notification.id);
                            const urgencyColor = getUrgencyColor(notification.urgency);
                            const borderColor = getUrgencyBorderColor(notification.urgency);
                            const isReceived = notification.recipientId === user?.id;

                            return (
                                <div
                                    key={notification.id}
                                    className={`border-l-4 ${borderColor} hover:bg-gray-50 transition cursor-pointer`}
                                    onClick={() => toggleNotification(notification.id)}
                                >
                                    <div className="p-5">
                                        <div className="flex items-start justify-between gap-4">
                                            {/* Icon Indicator */}
                                            <div className="mt-1 flex-shrink-0">
                                                {isReceived ? (
                                                    <div className="p-2 bg-green-50 rounded-full" title="Received">
                                                        <ArrowDownLeft className="w-5 h-5 text-green-600" />
                                                    </div>
                                                ) : (
                                                    <div className="p-2 bg-gray-100 rounded-full" title="Sent">
                                                        <ArrowUpRight className="w-5 h-5 text-gray-500" />
                                                    </div>
                                                )}
                                            </div>

                                            <div className="flex-1 min-w-0">
                                                {/* Header Row */}
                                                <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-1 gap-1 sm:gap-0">
                                                    <span className="text-xs text-gray-500 font-medium flex items-center gap-2 truncate">
                                                        {isReceived ? (
                                                            <>From: {notification.senderType === 'admin' ? 'Admin' : (notification.senderReadableId || notification.senderId || 'Unknown Sender')}</>
                                                        ) : (
                                                            <>To: Customer ({notification.recipientReadableId || notification.recipientId})</>
                                                        )}
                                                    </span>
                                                    <span className="text-xs text-gray-400">
                                                        {formatDateTime(notification.timestamp)}
                                                    </span>
                                                </div>

                                                {/* Title Row */}
                                                <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3 mb-2">
                                                    <h3 className="text-lg font-semibold text-gray-900 flex-1">
                                                        {notification.title}
                                                    </h3>
                                                    <div className="flex items-center gap-2 flex-shrink-0">
                                                        {/* Role Badge (if needed, simplified here) */}
                                                        {isReceived && notification.senderType === 'admin' && (
                                                            <Shield className="w-4 h-4 text-primary-600" />
                                                        )}
                                                        <span
                                                            className={`px-3 py-1 text-xs font-semibold rounded-full text-white ${urgencyColor}`}
                                                        >
                                                            {getUrgencyLabel(notification.urgency)}
                                                        </span>
                                                    </div>
                                                </div>

                                                {/* Expanded Content */}
                                                {isExpanded && (
                                                    <div className="mt-3 text-gray-700 whitespace-pre-wrap leading-relaxed">
                                                        {notification.message}
                                                    </div>
                                                )}
                                            </div>

                                            <div className="flex-shrink-0 self-center">
                                                {isExpanded ? (
                                                    <ChevronUp className="w-5 h-5 text-gray-400" />
                                                ) : (
                                                    <ChevronDown className="w-5 h-5 text-gray-400" />
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>

            {/* Send Notification Modal */}
            {showSendModal && (
                <AgentSendNotificationModal
                    onClose={() => setShowSendModal(false)}
                    onSuccess={() => {
                        fetchNotifications();
                    }}
                />
            )}
        </div>
    );
}
