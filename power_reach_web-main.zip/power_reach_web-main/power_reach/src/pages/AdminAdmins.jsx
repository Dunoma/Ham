import { useState } from 'react';
import { createPortal } from 'react-dom';
import { useAdmin } from '../context/AdminContext';
import { Mail, Phone, Search, Plus, MoreVertical, Edit, Ban, X, ShieldAlert, MapPin, CheckCircle } from 'lucide-react';

export default function AdminAdmins() {
    const { admins, addAdmin, deactivateUser, reactivateUser, updateAdminStaffProfile } = useAdmin();
    const [searchTerm, setSearchTerm] = useState('');
    const [showAddModal, setShowAddModal] = useState(false);

    // Edit & Deactivate State
    const [editingAdmin, setEditingAdmin] = useState(null);
    const [deactivatingAdmin, setDeactivatingAdmin] = useState(null);

    const normalizedAdmins = admins.map((admin) => {
        const profile = admin.profile || {};
        const name = profile.full_name || '';
        const readableId = admin.readableId || profile.display_id || '';
        const phone = admin.phone || profile.phone_number || '';
        const branch = admin.branch || profile.branch || '';
        const profilePicture = admin.profile_picture || profile.profile_picture_url || null;

        return {
            ...admin,
            name,
            readableId,
            phone,
            branch,
            profile_picture: profilePicture,
            isActive: admin.isActive ?? admin.is_active,
            isVerified: admin.isVerified ?? admin.is_verified,
        };
    });

    // Filter logic
    const lowerSearchTerm = searchTerm.toLowerCase();
    const filteredAdmins = normalizedAdmins.filter((admin) =>
        admin.name.toLowerCase().includes(lowerSearchTerm) ||
        admin.email.toLowerCase().includes(lowerSearchTerm) ||
        (admin.readableId && admin.readableId.toLowerCase().includes(lowerSearchTerm))
    );

    const handleUpdateAdmin = async (readableId, updatedData) => {
        await updateAdminStaffProfile(readableId, {
            full_name: updatedData.full_name,
            phone_number: updatedData.phone_number,
            branch: updatedData.branch,
            profile_picture_url: updatedData.profile_picture_url,
        });
        setEditingAdmin(null);
    };

    const handleDeactivateAdmin = async (admin) => {
        if (admin.isActive === false) {
            await reactivateUser(admin.id);
        } else {
            await deactivateUser(admin.id);
        }
        setDeactivatingAdmin(null);
    };

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Admins</h1>
                    <p className="text-gray-600">Manage system administrators.</p>
                </div>
                <button
                    onClick={() => setShowAddModal(true)}
                    className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg transition shadow-sm"
                >
                    <Plus className="w-5 h-5" />
                    Add Admin
                </button>
            </div>

            {/* Search */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
                <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                        type="text"
                        placeholder="Search admins..."
                        className="w-full pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
            </div>

            {/* Table */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="overflow-x-auto pb-32">
                    <table className="w-full text-left">
                        <thead className="bg-gray-50 border-b border-gray-200">
                            <tr>
                                <th className="px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Name & ID</th>
                                <th className="px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Contact</th>
                                <th className="px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Branch</th>
                                <th className="px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Active</th>
                                <th className="px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {filteredAdmins.length === 0 ? (
                                <tr>
                                    <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                                        No admins found.
                                    </td>
                                </tr>
                            ) : (
                                filteredAdmins.map((admin) => (
                                    <tr key={admin.id} className="hover:bg-gray-50 transition">
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="flex items-center gap-3">
                                                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold">
                                                    {admin.name?.charAt(0)}
                                                </div>
                                                <div>
                                                    <p className="text-sm font-medium text-gray-900">{admin.name}</p>
                                                    <p className="text-xs text-gray-500 font-mono">{admin.readableId}</p>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="flex flex-col gap-1">
                                                <div className="flex items-center gap-2 text-sm text-gray-600">
                                                    <Mail className="w-3.5 h-3.5" />
                                                    {admin.email}
                                                </div>
                                                {admin.phone && (
                                                    <div className="flex items-center gap-2 text-sm text-gray-600">
                                                        <Phone className="w-3.5 h-3.5" />
                                                        {admin.phone}
                                                    </div>
                                                )}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="flex items-center gap-2 text-sm text-gray-700">
                                                <MapPin className="w-4 h-4 text-gray-400" />
                                                {admin.branch || 'N/A'}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            {admin.isActive !== false ? (
                                                <span className="inline-flex items-center gap-1 px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                                                Active
                                                </span>
                                            ) : (
                                                <span className="inline-flex items-center gap-1 px-2 py-1 bg-red-100 text-red-700 rounded-full text-xs font-medium">Inactive
                                                </span>
                                            )}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-right">
                                            <TableActionMenu
                                                isActive={admin.isActive !== false}
                                                onEdit={() => setEditingAdmin(admin)}
                                                onDeactivate={() => setDeactivatingAdmin(admin)}
                                            />
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {showAddModal && <AddStaffModal onClose={() => setShowAddModal(false)} onAdd={addAdmin} />}

            {editingAdmin && (
                <EditAdminModal
                    admin={editingAdmin}
                    onClose={() => setEditingAdmin(null)}
                    onSave={handleUpdateAdmin}
                />
            )}

            {deactivatingAdmin && (
                <DeactivateConfirmModal
                    admin={deactivatingAdmin}
                    onClose={() => setDeactivatingAdmin(null)}
                    onConfirm={handleDeactivateAdmin}
                />
            )}
        </div>
    );
}

function TableActionMenu({ onEdit, onDeactivate, isActive }) {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="relative inline-block text-left">
            <button
                onClick={() => setIsOpen(!isOpen)}
                onBlur={() => setTimeout(() => setIsOpen(false), 200)}
                className="p-2 hover:bg-gray-100 rounded-full transition text-gray-500"
            >
                <MoreVertical className="w-4 h-4" />
            </button>

            {isOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-100 z-[50] py-1 animate-fade-in-up origin-top-right">
                    <button onClick={onEdit} className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                        <Edit className="w-4 h-4" /> Edit Details
                    </button>
                    <button
                        onClick={onDeactivate}
                        className={`w-full text-left px-4 py-2 text-sm flex items-center gap-2 ${isActive ? 'text-red-600 hover:bg-red-50' : 'text-green-600 hover:bg-green-50'}`}
                    >
                        <Ban className="w-4 h-4" /> {isActive ? 'Deactivate' : 'Reactivate'}
                    </button>
                </div>
            )}
        </div>
    );
}

const LOCATIONS = ['Wuse II', 'Gwarimpa', 'Jabi', 'Maitama', 'Asokoro', 'Headquarters'];

function EditAdminModal({ admin, onClose, onSave }) {
    const profile = admin.profile || {};
    const [formData, setFormData] = useState({
        full_name: admin.name || profile.full_name || '',
        phone_number: admin.phone || profile.phone_number || '',
        branch: admin.branch || profile.branch || ''
    });
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setIsSubmitting(true);
        try {
            await onSave(admin.readableId, formData);
        } catch (err) {
            setError(err.message || 'Failed to update admin.');
        } finally {
            setIsSubmitting(false);
        }
    };

    return createPortal(
        <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-xl w-full max-w-md animate-fade-in-up">
                <div className="flex items-center justify-between p-6 border-b border-gray-200">
                    <h2 className="text-xl font-bold text-gray-900">Edit Admin</h2>
                    <button onClick={onClose}><X className="w-5 h-5 text-gray-400" /></button>
                </div>
                <form onSubmit={handleSubmit} className="p-6 space-y-4">
                    {error && <div className="p-3 bg-red-50 text-red-700 rounded-lg text-sm">{error}</div>}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                        <input
                            value={formData.full_name}
                            onChange={e => setFormData({ ...formData, full_name: e.target.value })}
                            className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 outline-none"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                        <input
                            value={admin.email || ''}
                            disabled
                            className="w-full px-3 py-2 border rounded-lg bg-gray-100 text-gray-500 cursor-not-allowed outline-none"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                        <input
                            value={formData.phone_number}
                            onChange={e => setFormData({ ...formData, phone_number: e.target.value })}
                            className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 outline-none"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Branch</label>
                        <select
                            value={formData.branch}
                            onChange={e => setFormData({ ...formData, branch: e.target.value })}
                            className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 outline-none bg-white"
                        >
                            <option value="">Select Branch</option>
                            {LOCATIONS.map(loc => (
                                <option key={loc} value={loc}>{loc}</option>
                            ))}
                        </select>
                    </div>
                    <div className="flex justify-end gap-3 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button>
                        <button type="submit" disabled={isSubmitting} className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50">
                            {isSubmitting ? 'Saving...' : 'Save Changes'}
                        </button>
                    </div>
                </form>
            </div>
        </div>,
        document.body
    );
}

function DeactivateConfirmModal({ admin, onClose, onConfirm }) {
    const isActive = admin.isActive !== false;

    return createPortal(
        <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-xl w-full max-w-sm animate-fade-in-up p-6 text-center">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 ${isActive ? 'bg-red-100' : 'bg-green-100'}`}>
                    <ShieldAlert className={`w-6 h-6 ${isActive ? 'text-red-600' : 'text-green-600'}`} />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">{isActive ? 'Deactivate Admin?' : 'Activate Admin?'}</h3>
                <p className="text-gray-500 text-sm mb-6">
                    Are you sure you want to {isActive ? 'deactivate' : 'activate'} <strong>{admin.name}</strong>? {isActive ? 'They will no longer be able to log in.' : 'They will regain access to their account.'}
                </p>
                <div className="flex gap-3 justify-center">
                    <button onClick={onClose} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button>
                    <button onClick={() => onConfirm(admin)} className={`px-4 py-2 text-white rounded-lg ${isActive ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'}`}>{isActive ? 'Deactivate' : 'Activate'}</button>
                </div>
            </div>
        </div>,
        document.body
    );
}

function AddStaffModal({ onClose, onAdd }) {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        branch: '',
        password: ''
    });
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setIsSubmitting(true);

        try {
            await onAdd({
                email: formData.email,
                password: formData.password,
                full_name: formData.name,
                phone_number: formData.phone,
                branch: formData.branch,
            });

            setIsSuccess(true);
            setTimeout(() => {
                onClose();
            }, 1800);
        } catch (err) {
            setError('Failed to add admin. ' + err.message);
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

    if (isSuccess) {
        return createPortal(
            <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-4">
                <div className="bg-white rounded-xl shadow-xl w-full max-w-sm p-8 flex flex-col items-center animate-fade-in-up">
                    <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-4 animate-bounce-short">
                        <CheckCircle className="w-10 h-10 text-green-600" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Admin Registered!</h3>
                    <p className="text-gray-500 text-center">The new admin account has been created successfully.</p>
                </div>
            </div>,
            document.body
        );
    }

    return createPortal(
        <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-xl w-full max-w-md">
                <div className="flex items-center justify-between p-6 border-b border-gray-200">
                    <h2 className="text-xl font-bold text-gray-900">Add New Admin</h2>
                    <button onClick={onClose}><X className="w-5 h-5 text-gray-400" /></button>
                </div>
                <form onSubmit={handleSubmit} className="p-6 space-y-4">
                    {error && <div className="p-3 bg-red-50 text-red-700 rounded-lg text-sm">{error}</div>}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                        <input name="name" required className="w-full px-3 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-primary-500" onChange={handleChange} />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                        <input name="email" type="email" required className="w-full px-3 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-primary-500" onChange={handleChange} />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                        <input name="phone" required className="w-full px-3 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-primary-500" onChange={handleChange} />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Branch</label>
                        <select name="branch" required className="w-full px-3 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-primary-500 bg-white" onChange={handleChange} value={formData.branch}>
                            <option value="" disabled>Select Branch</option>
                            {LOCATIONS.map(loc => (
                                <option key={loc} value={loc}>{loc}</option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                        <input name="password" required className="w-full px-3 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-primary-500" onChange={handleChange} />
                    </div>
                    <div className="flex justify-end gap-3 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button>
                        <button type="submit" disabled={isSubmitting} className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50">
                            {isSubmitting ? 'Saving...' : 'Create Admin'}
                        </button>
                    </div>
                </form>
            </div>
        </div>,
        document.body
    );
}
