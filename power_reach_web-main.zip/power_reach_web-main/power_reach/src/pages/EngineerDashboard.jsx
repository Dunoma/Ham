import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useEngineer } from '../context/EngineerContext';
import { FileText, Bell, CheckCircle } from 'lucide-react';
import SendNotificationModal from '../components/SendNotificationModal';

export default function EngineerDashboard() {
  const navigate = useNavigate();
  const {
    user,
    assignedReports,
    notifications,
    fetchAssignedReports,
  } = useEngineer();
  const [showSendModal, setShowSendModal] = useState(false);

  // Calculate stats
  const pendingReportsCount = assignedReports.filter(
    (report) => report.status === 'Received' || report.status === 'In Progress'
  ).length;

  const newNotificationsCount = notifications.filter(
    (notification) => !notification.isRead || notification.isRead === false
  ).length;

  const resolvedIssuesCount = assignedReports.filter(
    (report) => report.status === 'Resolved'
  ).length;

  const stats = [
    {
      title: 'Pending Reports',
      value: pendingReportsCount,
      icon: FileText,
      color: 'bg-orange-500',
      onClick: () => navigate('/engineers/reports?filter=pending'),
    },
    {
      title: 'New Notifications',
      value: newNotificationsCount,
      icon: Bell,
      color: 'bg-blue-500',
      onClick: () => navigate('/engineers/notifications'),
    },
    {
      title: 'Resolved Issues',
      value: resolvedIssuesCount,
      icon: CheckCircle,
      color: 'bg-green-500',
      onClick: () => navigate('/engineers/reports?filter=resolved'),
    },
    {
      title: 'Total Reports',
      value: assignedReports.length,
      icon: FileText,
      color: 'bg-primary-600',
      onClick: () => navigate('/engineers/reports'),
    },
  ];

  // Get recent reports (top 5)
  const recentReports = [...assignedReports]
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 5);

  // Get recent notifications (top 5)
  const recentNotifications = [...notifications]
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
    .slice(0, 5);

  const getStatusColor = (status) => {
    switch (status) {
      case 'Received':
        return 'bg-gray-100 text-gray-700';
      case 'In Progress':
        return 'bg-yellow-100 text-yellow-700';
      case 'Resolved':
        return 'bg-green-100 text-green-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getUrgencyColor = (urgency) => {
    switch (urgency) {
      case 'low':
        return 'bg-blue-500';
      case 'medium':
        return 'bg-yellow-500';
      case 'high':
        return 'bg-orange-500';
      case 'critical':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getUrgencyLabel = (urgency) => {
    const labels = {
      low: 'Low',
      medium: 'Med',
      high: 'High',
      critical: 'Critical',
    };
    return labels[urgency] || urgency.charAt(0).toUpperCase() + urgency.slice(1);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">Welcome back, {user?.name || 'Engineer'}</p>
        </div>
        <button
          onClick={() => setShowSendModal(true)}
          className="flex items-center justify-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg transition w-full sm:w-auto"
        >
          <Bell className="w-5 h-5" />
          Send Notification
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <button
              key={index}
              onClick={stat.onClick}
              className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition cursor-pointer text-left"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`${stat.color} p-3 rounded-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</h3>
              <p className="text-sm text-gray-600">{stat.title}</p>
            </button>
          );
        })}
      </div>

      {/* Recent Reports and Notifications - Split View */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column: Recent Reports */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Recent Reports</h2>
            <button
              onClick={() => navigate('/engineers/reports')}
              className="text-primary-600 hover:text-primary-700 text-sm font-medium"
            >
              View All
            </button>
          </div>
          <div className="space-y-3">
            {recentReports.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No reports assigned yet</p>
            ) : (
              recentReports.map((report) => (
                <div
                  key={report.id}
                  className="flex items-start gap-3 p-3 hover:bg-gray-50 rounded-lg transition cursor-pointer"
                  onClick={() => navigate(`/engineers/reports`)}
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-medium text-gray-900 truncate">{report.title}</p>
                      <span
                        className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(
                          report.status
                        )}`}
                      >
                        {report.status}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 truncate">{report.userName}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {report.userLocation} • {new Date(report.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right Column: Recent Notifications */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Recent Notifications</h2>
            <button
              onClick={() => navigate('/engineers/notifications')}
              className="text-primary-600 hover:text-primary-700 text-sm font-medium"
            >
              View All
            </button>
          </div>
          <div className="space-y-3">
            {recentNotifications.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No notifications yet</p>
            ) : (
              recentNotifications.map((notification) => (
                <div
                  key={notification.id}
                  className="flex items-start gap-3 p-3 hover:bg-gray-50 rounded-lg transition cursor-pointer"
                  onClick={() => navigate('/engineers/notifications')}
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-medium text-gray-900 truncate">{notification.title}</p>
                      <span
                        className={`px-2 py-1 text-xs font-semibold rounded-full text-white ${getUrgencyColor(
                          notification.urgency
                        )}`}
                      >
                        {getUrgencyLabel(notification.urgency)}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Send Notification Modal */}
      {showSendModal && (
        <SendNotificationModal
          onClose={() => setShowSendModal(false)}
          onSuccess={() => {
            // Refresh data if needed
            fetchAssignedReports();
          }}
        />
      )}
    </div>
  );
}

