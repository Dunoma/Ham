import { useState, useMemo, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAgent } from '../context/AgentContext';
import { MessageSquare, Zap, CheckCircle, Copy, Check } from 'lucide-react';
import UserAvatar from '../components/UserAvatar';
import ReportFormModal from '../components/ReportFormModal';
import UserProfileModal from '../components/UserProfileModal';
import { formatDateTime } from '../utils/dateFormat';

export default function Messages() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { users, chats, messages, acceptSparkyThread, markMessageRead, loading } = useAgent();

  // Initialize filter from URL query parameter or default to 'all'
  const [filter, setFilter] = useState(() => {
    const filterParam = searchParams.get('filter');
    const validFilters = ['all', 'unread', 'sparky', 'unclaimed'];
    return validFilters.includes(filterParam) ? filterParam : 'all';
  });

  // Update filter when URL query parameter changes
  useEffect(() => {
    const filterParam = searchParams.get('filter');
    const validFilters = ['all', 'unread', 'sparky', 'unclaimed'];
    if (filterParam && validFilters.includes(filterParam)) {
      setFilter(filterParam);
    }
  }, [searchParams]);

  // Update URL when filter changes (but don't add to history if it's the initial load)
  const handleFilterChange = (newFilter) => {
    setFilter(newFilter);
    setSearchParams({ filter: newFilter }, { replace: true });
  };
  const [showReportForm, setShowReportForm] = useState(false);
  const [selectedMessage, setSelectedMessage] = useState(null);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [copiedUserId, setCopiedUserId] = useState(null);

  // Calculate filter counts
  const filterCounts = useMemo(() => {
    if (!messages || messages.length === 0) {
      return { all: 0, unread: 0, sparky: 0, unclaimed: 0 };
    }

    // Get unique conversations for each filter
    const allChatIds = [...new Set(messages.map(m => m.chatId))];
    const unreadChatIds = [...new Set(messages.filter(m => !m.isRead).map(m => m.chatId))];
    const sparkyChatIds = [...new Set(messages.filter(m => m.isSparkyReport).map(m => m.chatId))];
    const unclaimedChatIds = [...new Set(messages.filter(m => m.isSparkyReport && m.status === 'unclaimed').map(m => m.chatId))];

    return {
      all: allChatIds.length,
      unread: unreadChatIds.length,
      sparky: sparkyChatIds.length,
      unclaimed: unclaimedChatIds.length,
    };
  }, [messages]);

  // Group messages by chatId into conversations
  const conversations = useMemo(() => {
    // Return empty array if data is not loaded yet
    if (!messages || !chats || !users || messages.length === 0) {
      return [];
    }

    // First, filter messages based on filter
    const filteredMessages = messages.filter((message) => {
      if (filter === 'unread') return !message.isRead;
      if (filter === 'sparky') return message.isSparkyReport;
      if (filter === 'unclaimed')
        return message.isSparkyReport && message.status === 'unclaimed';
      return true;
    });

    // Group by chatId
    const grouped = filteredMessages.reduce((acc, message) => {
      const chatId = message.chatId;
      if (!chatId) return acc;
      if (!acc[chatId]) {
        acc[chatId] = [];
      }
      acc[chatId].push(message);
      return acc;
    }, {});

    // Get the most recent message for each conversation and sort by last message time
    const conversationList = Object.values(grouped).map((conversationMessages) => {
      // Find the most recent message in this conversation
      const lastMessage = conversationMessages.reduce((latest, current) => {
        return new Date(current.createdAt) > new Date(latest.createdAt)
          ? current
          : latest;
      });

      // Get chat and customer info
      const chat = chats.find((c) => c.id === lastMessage.chatId);
      const customer = chat ? users.find((u) => u.id === chat.customerId) : null;

      // Check if conversation has unread messages
      const hasUnread = conversationMessages.some((m) => !m.isRead);

      // Check if conversation has Sparky messages
      const hasSparky = conversationMessages.some((m) => m.isSparkyReport);

      // Check if conversation has unclaimed Sparky messages
      const hasUnclaimed = conversationMessages.some(
        (m) => m.isSparkyReport && m.status === 'unclaimed'
      );

      return {
        chatId: lastMessage.chatId,
        customerId: chat?.customerId,
        customerName: customer?.name || 'Unknown',
        customerReadableId: customer?.readableId,
        customerLocation: customer?.location || '',
        lastMessage: lastMessage,
        hasUnread,
        hasSparky,
        hasUnclaimed,
        messageCount: conversationMessages.length,
      };
    });

    // Sort by last message time (most recent first)
    return conversationList.sort(
      (a, b) => new Date(b.lastMessage.createdAt) - new Date(a.lastMessage.createdAt)
    );
  }, [messages, chats, users, filter]);

  const handleAccept = (e, conversation) => {
    e.stopPropagation();
    // Accept the unclaimed Sparky message
    const unclaimedMessage = messages.find(
      (m) =>
        m.chatId === conversation.chatId &&
        m.isSparkyReport &&
        m.status === 'unclaimed'
    );
    if (unclaimedMessage) {
      acceptSparkyThread(unclaimedMessage.id);
      // Immediately open the conversation view using chatId
      navigate(`/agent/chat/${conversation.chatId}`);
    }
  };

  const handleMessageClick = (conversation) => {
    // Mark all unread messages in this conversation as read
    const conversationMessages = messages.filter(
      (m) => m.chatId === conversation.chatId
    );
    conversationMessages.forEach((msg) => {
      if (!msg.isRead) {
        markMessageRead(msg.id);
      }
    });
    // Navigate using chatId
    navigate(`/agent/messages/${conversation.chatId}`);
  };

  const getReportPrefillData = (message) => {
    if (!message) return null;
    return {
      userId: message.userId,
      title: `Report from ${message.userName}`,
      description: message.content,
      faultType: 'Power Outage', // Default, can be changed
      isSparkyReport: message.isSparkyReport || false,
    };
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Messages</h1>
          <p className="text-gray-600 mt-1">Customer conversations and inquiries</p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 overflow-x-auto whitespace-nowrap no-scrollbar">
        <div className="flex flex-nowrap md:flex-wrap items-center gap-2">
          <span className="text-sm font-medium text-gray-700 mr-2">Filter:</span>
          {['all', 'unread', 'sparky', 'unclaimed'].map((filterType) => (
            <button
              key={filterType}
              onClick={() => handleFilterChange(filterType)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition ${filter === filterType
                  ? 'bg-primary-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
            >
              {filterType.charAt(0).toUpperCase() + filterType.slice(1)} ({filterCounts[filterType]})
            </button>
          ))}
        </div>
      </div>

      {/* Messages List */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        {loading ? (
          <div className="p-12 text-center">
            <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-4 animate-pulse" />
            <p className="text-gray-500 text-lg">Loading conversations...</p>
          </div>
        ) : conversations.length === 0 ? (
          <div className="p-12 text-center">
            <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500 text-lg">No conversations found</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {conversations.map((conversation) => (
              <div
                key={conversation.chatId}
                onClick={() => handleMessageClick(conversation)}
                className={`p-6 hover:bg-gray-50 transition cursor-pointer ${conversation.hasUnread ? 'bg-blue-50/50' : ''
                  }`}
              >
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0">
                    <UserAvatar
                      userId={conversation.customerId}
                      userName={conversation.customerName}
                      profilePicture={users.find((u) => u.id === conversation.customerId)?.profile_picture}
                      size="md"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedUserId(conversation.customerId);
                      }}
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-2 w-full">
                      <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                        <h3 className="text-lg font-semibold text-gray-900">
                          {conversation.customerName}
                        </h3>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            navigator.clipboard.writeText(conversation.customerReadableId || conversation.customerId);
                            setCopiedUserId(conversation.customerId);
                            setTimeout(() => setCopiedUserId(null), 2000);
                          }}
                          className="p-1 hover:bg-gray-200 rounded transition"
                          title="Copy User ID"
                        >
                          {copiedUserId === conversation.customerId ? (
                            <Check className="w-3 h-3 text-green-600" />
                          ) : (
                            <Copy className="w-3 h-3 text-gray-400" />
                          )}
                        </button>
                        {conversation.hasSparky && (
                          <Zap className="w-4 h-4 text-accent-500" />
                        )}
                        {conversation.lastMessage.status === 'claimed' && (
                          <CheckCircle className="w-5 h-5 text-green-500" />
                        )}
                        {conversation.hasUnread && (
                          <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        {conversation.hasUnclaimed && (
                          <button
                            onClick={(e) => handleAccept(e, conversation)}
                            className="flex-shrink-0 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition"
                          >
                            Accept
                          </button>
                        )}
                      </div>
                    </div>

                    <p className="text-gray-700 mb-3">{conversation.lastMessage.content}</p>

                    <div className="flex flex-wrap items-center gap-2 sm:gap-4 text-sm text-gray-500">
                      <span className="truncate">{conversation.customerLocation}</span>
                      <span className="hidden sm:inline">•</span>
                      <span className="truncate">{formatDateTime(conversation.lastMessage.createdAt)}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Report Form Modal */}
      {showReportForm && (
        <ReportFormModal
          onClose={() => {
            setShowReportForm(false);
            setSelectedMessage(null);
          }}
          prefillData={getReportPrefillData(selectedMessage)}
        />
      )}

      {/* User Profile Modal */}
      {selectedUserId && (
        <UserProfileModal
          userId={selectedUserId}
          onClose={() => setSelectedUserId(null)}
        />
      )}
    </div>
  );
}
