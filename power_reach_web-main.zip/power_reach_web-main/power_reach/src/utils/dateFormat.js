/**
 * Format date to show Date and Time (HH:MM) only, without seconds
 * @param {string|Date} date - Date string or Date object
 * @returns {string} Formatted date string (e.g., "12/30/2024, 09:00")
 */
export function formatDateTime(date) {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  
  if (isNaN(dateObj.getTime())) {
    return '';
  }

  // Format: Date and Time (HH:MM) - no seconds
  return dateObj.toLocaleString('en-US', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
}

