import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AgentProvider } from './context/AgentContext';
import { EngineerProvider } from './context/EngineerContext';
import AgentLayout from './components/AgentLayout';
import EngineerLayout from './components/EngineerLayout';
import ProtectedRoute from './components/ProtectedRoute';
import EngineerProtectedRoute from './components/EngineerProtectedRoute';
import ScrollRestoration from './components/ScrollRestoration';
import Login from './pages/Login';
import EngineerLogin from './pages/EngineerLogin';
import Dashboard from './pages/Dashboard';
import EngineerDashboard from './pages/EngineerDashboard';
import Reports from './pages/Reports';
import EngineerReports from './pages/EngineerReports';
import EngineerNotifications from './pages/EngineerNotifications';
import EngineerEngineers from './pages/EngineerEngineers';
import EngineerCustomers from './pages/EngineerCustomers';
import EngineerProfile from './pages/EngineerProfile';
import Messages from './pages/Messages';
import ChatView from './pages/ChatView';
import Engineers from './pages/Engineers';
import Profile from './pages/Profile';
import AgentNotifications from './pages/AgentNotifications';
import { AdminProvider } from './context/AdminContext';
import AdminLayout from './components/AdminLayout';
import AdminDashboard from './pages/AdminDashboard';
import AdminNotifications from './pages/AdminNotifications';
import AdminStaff from './pages/AdminStaff';
import AdminAgents from './pages/AdminAgents';
import AdminAdmins from './pages/AdminAdmins';
import AdminEngineers from './pages/AdminEngineers';
import AdminCustomers from './pages/AdminCustomers';
import AdminReports from './pages/AdminReports';
import AdminLogin from './pages/AdminLogin';
import AdminSettings from './pages/AdminSettings';
import AdminProfile from './pages/AdminProfile';
import SessionPresenceHost from './components/SessionPresenceHost';

function AppRoutes() {
  return (
    <>
      <ScrollRestoration />
      <Routes>
        {/* Agent Routes */}
        <Route path="/agent/login" element={<Login />} />
        <Route
          path="/agent/dashboard"
          element={
            <ProtectedRoute>
              <AgentLayout>
                <Dashboard />
              </AgentLayout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/agent/reports"
          element={
            <ProtectedRoute>
              <AgentLayout>
                <Reports />
              </AgentLayout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/agent/messages"
          element={
            <ProtectedRoute>
              <AgentLayout>
                <Messages />
              </AgentLayout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/agent/messages/:messageId"
          element={
            <ProtectedRoute>
              <AgentLayout>
                <ChatView />
              </AgentLayout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/agent/chat/:chatId"
          element={
            <ProtectedRoute>
              <AgentLayout>
                <ChatView />
              </AgentLayout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/agent/engineers"
          element={
            <ProtectedRoute>
              <AgentLayout>
                <Engineers />
              </AgentLayout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/agent/notifications"
          element={
            <ProtectedRoute>
              <AgentLayout>
                <AgentNotifications />
              </AgentLayout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/agent/profile"
          element={
            <ProtectedRoute>
              <AgentLayout>
                <Profile />
              </AgentLayout>
            </ProtectedRoute>
          }
        />
        {/* Engineer Routes */}
        <Route path="/engineers/login" element={<EngineerLogin />} />
        <Route
          path="/engineers/dashboard"
          element={
            <EngineerProtectedRoute>
              <EngineerLayout>
                <EngineerDashboard />
              </EngineerLayout>
            </EngineerProtectedRoute>
          }
        />
        <Route
          path="/engineers/reports"
          element={
            <EngineerProtectedRoute>
              <EngineerLayout>
                <EngineerReports />
              </EngineerLayout>
            </EngineerProtectedRoute>
          }
        />
        <Route
          path="/engineers/notifications"
          element={
            <EngineerProtectedRoute>
              <EngineerLayout>
                <EngineerNotifications />
              </EngineerLayout>
            </EngineerProtectedRoute>
          }
        />
        <Route
          path="/engineer/engineers"
          element={
            <EngineerProtectedRoute>
              <EngineerLayout>
                <EngineerEngineers />
              </EngineerLayout>
            </EngineerProtectedRoute>
          }
        />
        <Route
          path="/engineers/customers"
          element={
            <EngineerProtectedRoute>
              <EngineerLayout>
                <EngineerCustomers />
              </EngineerLayout>
            </EngineerProtectedRoute>
          }
        />
        <Route
          path="/engineers/profile"
          element={
            <EngineerProtectedRoute>
              <EngineerLayout>
                <EngineerProfile />
              </EngineerLayout>
            </EngineerProtectedRoute>
          }
        />

        {/* Admin Routes */}
        <Route path="/admin/login" element={<AdminLogin />} />
        <Route
          path="/admin/*"
          element={
            <AdminLayout>
              <Routes>
                <Route path="dashboard" element={<AdminDashboard />} />
                <Route path="admins" element={<AdminAdmins />} />
                <Route path="agents" element={<AdminAgents />} />
                <Route path="engineers" element={<AdminEngineers />} />
                <Route path="customers" element={<AdminCustomers />} />
                <Route path="notifications" element={<AdminNotifications />} />
                <Route path="reports" element={<AdminReports />} />
                <Route path="settings" element={<AdminSettings />} />
                <Route path="profile" element={<AdminProfile />} />
                <Route path="/" element={<Navigate to="dashboard" replace />} />
              </Routes>
            </AdminLayout>
          }
        />

        {/* Default Routes */}
        <Route path="/" element={<Navigate to="/agent/login" replace />} />
        <Route path="/login" element={<Navigate to="/agent/login" replace />} />
      </Routes >
    </>
  );
}

function App() {
  return (
    <AgentProvider>
      <EngineerProvider>
        <AdminProvider>
          <BrowserRouter>
            <SessionPresenceHost />
            <AppRoutes />
          </BrowserRouter>
        </AdminProvider>
      </EngineerProvider>
    </AgentProvider>
  );
}

export default App;
