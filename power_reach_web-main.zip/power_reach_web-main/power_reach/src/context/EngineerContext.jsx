import { createContext, useContext, useReducer, useEffect, useState } from 'react';
import { api, authApi, AUTH_SESSION_INACTIVE_EVENT } from '../services/api';

export const EngineerContext = createContext();

const isEngineer = (userType) => userType === 'engineer';

const mapProfileToEngineerUser = (profileData) => {
  const profile = profileData?.profile || {};

  return {
    id: profileData?.id,
    readableId: profile.display_id,
    name: profile.full_name,
    email: profileData?.email,
    phone: profile.phone_number,
    branch: profile.branch,
    role: profileData?.user_type,
    specialisation: profile.specialisation,
    user_type: profileData?.user_type,
    profile_picture: profile.profile_picture_url,
    isActive: profileData?.is_active,
    isVerified: profileData?.is_verified,
    rawProfile: profileData,
  };
};

// Initial state
const initialState = {
  user: null,
  assignedReports: [],
  notifications: [],
  customers: [],
  engineers: [],
  isAuthenticated: false,
  loading: true,
};

// Action types
const ActionTypes = {
  SET_LOADING: 'SET_LOADING',
  SET_USER: 'SET_USER',
  SET_ASSIGNED_REPORTS: 'SET_ASSIGNED_REPORTS',
  SET_NOTIFICATIONS: 'SET_NOTIFICATIONS',
  SET_CUSTOMERS: 'SET_CUSTOMERS',
  SET_ENGINEERS: 'SET_ENGINEERS',
  LOGIN: 'LOGIN',
  LOGOUT: 'LOGOUT',
  UPDATE_REPORT: 'UPDATE_REPORT',
  ADD_NOTIFICATION: 'ADD_NOTIFICATION',
  REMOVE_NOTIFICATION: 'REMOVE_NOTIFICATION',
};

// Reducer
function engineerReducer(state, action) {
  switch (action.type) {
    case ActionTypes.SET_LOADING:
      return { ...state, loading: action.payload };

    case ActionTypes.SET_USER:
      return { ...state, user: action.payload };

    case ActionTypes.SET_ASSIGNED_REPORTS:
      return { ...state, assignedReports: action.payload };

    case ActionTypes.SET_NOTIFICATIONS:
      return { ...state, notifications: action.payload };

    case ActionTypes.SET_CUSTOMERS:
      return { ...state, customers: action.payload };

    case ActionTypes.SET_ENGINEERS:
      return { ...state, engineers: action.payload };

    case ActionTypes.LOGIN:
      return {
        ...state,
        user: action.payload,
        isAuthenticated: true,
      };

    case ActionTypes.LOGOUT:
      return {
        ...state,
        user: null,
        isAuthenticated: false,
        assignedReports: [],
        notifications: [],
        customers: [],
        engineers: [],
      };

    case ActionTypes.UPDATE_REPORT:
      return {
        ...state,
        assignedReports: state.assignedReports.map((report) =>
          report.id === action.payload.id ? { ...report, ...action.payload } : report
        ),
      };

    case ActionTypes.ADD_NOTIFICATION:
      return {
        ...state,
        notifications: [action.payload, ...state.notifications],
      };

    case ActionTypes.REMOVE_NOTIFICATION:
      return {
        ...state,
        notifications: state.notifications.filter((n) => n.id !== action.payload),
      };

    default:
      return state;
  }
}

// Provider component
export function EngineerProvider({ children }) {
  const [state, dispatch] = useReducer(engineerReducer, initialState);

  useEffect(() => {
    const restoreSession = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        dispatch({ type: ActionTypes.SET_LOADING, payload: false });
        return;
      }

      try {
        const profileData = await authApi.getProfile();
        if (!isEngineer(profileData?.user_type)) {
          return;
        }

        const mappedUser = mapProfileToEngineerUser(profileData);
        dispatch({ type: ActionTypes.LOGIN, payload: mappedUser });
        authApi.initializeAuth();
      } catch (error) {
        console.error('Engineer session restore failed:', error);
      } finally {
        dispatch({ type: ActionTypes.SET_LOADING, payload: false });
      }
    };

    restoreSession();
  }, []);

  useEffect(() => {
    const onSessionInactive = () => {
      dispatch({ type: ActionTypes.LOGOUT });
    };
    window.addEventListener(AUTH_SESSION_INACTIVE_EVENT, onSessionInactive);
    return () => window.removeEventListener(AUTH_SESSION_INACTIVE_EVENT, onSessionInactive);
  }, []);

  // Fetch initial data from API
  const fetchNotifications = async () => {
    if (!state.user) return;
    try {
      const [received, sent] = await Promise.all([
        api.getEngineerNotifications(state.user.id),
        api.getEngineerSentNotifications(state.user.id),
      ]);

      const allNotifications = [...received, ...sent]
        .map((notification) => ({
          ...notification,
          isRead: notification.isRead !== undefined ? notification.isRead : false,
        }))
        // Sort by timestamp desc to avoid jitter
        .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

      dispatch({ type: ActionTypes.SET_NOTIFICATIONS, payload: allNotifications });
    } catch (error) {
      console.error('Error fetching notifications:', error);
    }
  };

  useEffect(() => {
    if (state.user && state.isAuthenticated) {
      const fetchData = async () => {
        try {
          dispatch({ type: ActionTypes.SET_LOADING, payload: true });

          // Fetch assigned reports, notifications, customers, and engineers
          const [reports, receivedNotifs, sentNotifs, customers, engineers] = await Promise.all([
            api.getReports(),
            api.getEngineerNotifications(state.user.id),
            api.getEngineerSentNotifications(state.user.id),
            api.getUsers(),
            api.getEngineers(),
          ]);

          // Filter reports assigned to this engineer
          const assignedReports = reports.filter(
            (report) => report.assignedTo === state.user.id || report.assignedEngineerId === state.user.id
          );

          // Create lookups for readable IDs
          const userMap = new Map(customers.map(u => [u.id, u]));
          const engineerMap = new Map(engineers.map(e => [e.id, e]));

          // Combine and process notifications
          const allNotifications = [...receivedNotifs, ...sentNotifs]
            .map((notification) => {
              const sender = userMap.get(notification.senderId) || engineerMap.get(notification.senderId);
              const recipient = userMap.get(notification.recipientId) || engineerMap.get(notification.recipientId);

              return {
                ...notification,
                isRead: notification.isRead !== undefined ? notification.isRead : false,
                senderReadableId: sender?.readableId,
                recipientReadableId: recipient?.readableId,
              };
            })
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

          dispatch({ type: ActionTypes.SET_ASSIGNED_REPORTS, payload: assignedReports });
          dispatch({ type: ActionTypes.SET_NOTIFICATIONS, payload: allNotifications });
          dispatch({ type: ActionTypes.SET_CUSTOMERS, payload: customers });
          dispatch({ type: ActionTypes.SET_ENGINEERS, payload: engineers });
        } catch (error) {
          console.error('Error fetching engineer data:', error);
        } finally {
          dispatch({ type: ActionTypes.SET_LOADING, payload: false });
        }
      };

      fetchData();
    }
  }, [state.user, state.isAuthenticated]);

  // Helper functions
  const login = async (email, password) => {
    try {
      const loginData = await authApi.login(email, password);
      if (loginData) {
        const profileData = await authApi.getProfile();
        if (!isEngineer(profileData?.user_type)) {
          authApi.logout();
          return false;
        }

        const localEngineer = await api.loginEngineer(email, password).catch(() => null);
        const engineer = localEngineer
          ? { ...localEngineer, role: profileData?.user_type, user_type: profileData?.user_type, rawProfile: profileData }
          : mapProfileToEngineerUser(profileData);

        dispatch({ type: ActionTypes.LOGIN, payload: engineer });
        return true;
      }
      return false;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  };

  const logout = () => {
    authApi.logout();
    dispatch({ type: ActionTypes.LOGOUT });
  };

  const fetchAssignedReports = async () => {
    try {
      const reports = await api.getReports();
      const assignedReports = reports.filter(
        (report) => report.assignedTo === state.user.id || report.assignedEngineerId === state.user.id
      );
      dispatch({ type: ActionTypes.SET_ASSIGNED_REPORTS, payload: assignedReports });
      return assignedReports;
    } catch (error) {
      console.error('Error fetching assigned reports:', error);
      throw error;
    }
  };

  const updateReportStatus = async (reportId, status) => {
    try {
      const updatedReport = await api.updateReport(reportId, { status });
      dispatch({ type: ActionTypes.UPDATE_REPORT, payload: { id: reportId, status } });
      return updatedReport;
    } catch (error) {
      console.error('Error updating report status:', error);
      throw error;
    }
  };

  const searchCustomers = async (searchTerm, searchMode = 'name') => {
    try {
      const customers = await api.getUsers();
      const searchLower = searchTerm.toLowerCase();
      const filteredCustomers = customers.filter((customer) => {
        if (searchMode === 'id') {
          return customer.readableId?.toLowerCase().includes(searchLower);
        } else {
          // Search by name (default)
          return customer.name?.toLowerCase().includes(searchLower);
        }
      });
      dispatch({ type: ActionTypes.SET_CUSTOMERS, payload: filteredCustomers });
      return filteredCustomers;
    } catch (error) {
      console.error('Error searching customers:', error);
      throw error;
    }
  };

  const addNotification = (notification) => {
    const newNotification = {
      ...notification,
      id: `notif_${Date.now()}`,
      timestamp: new Date().toISOString(),
    };
    dispatch({ type: ActionTypes.ADD_NOTIFICATION, payload: newNotification });
    return newNotification;
  };

  const removeNotification = (id) => {
    dispatch({ type: ActionTypes.REMOVE_NOTIFICATION, payload: id });
  };

  const sendNotification = async (notificationData) => {
    try {
      // Generate UUID for the notification
      const notificationId = `550e8400-${Date.now().toString(36)}-${Math.random().toString(36).substr(2, 9)}`;

      const newNotification = {
        id: notificationId,
        title: notificationData.title,
        message: notificationData.message,
        urgency: notificationData.urgency,
        senderType: 'engineer',
        senderId: state.user.id, // Added senderId
        recipientId: notificationData.recipientId,
        timestamp: new Date().toISOString(),
      };

      let createdNotification;

      if (notificationData.recipientType === 'customer') {
        createdNotification = await api.createUserNotification(newNotification);
      } else {
        // Default to engineer
        createdNotification = await api.createEngineerNotification(newNotification);

        // Refresh notifications if sent to current user (only applicable for engineer-to-engineer)
        if (createdNotification.recipientId === state.user?.id) {
          await fetchNotifications();
        }
      }

      return createdNotification;
    } catch (error) {
      console.error('Error sending notification:', error);
      throw error;
    }
  };

  const value = {
    ...state,
    login,
    logout,
    fetchAssignedReports,
    updateReportStatus,
    searchCustomers,
    addNotification,
    removeNotification,
    updateEngineerSettings: async (settings) => { await new Promise(r => setTimeout(r, 1000)); console.log("Updated engineer settings:", settings); return true; },
    sendNotification,
    fetchNotifications,
  };

  return <EngineerContext.Provider value={value}>{children}</EngineerContext.Provider>;
}

// Custom hook
export function useEngineer() {
  const context = useContext(EngineerContext);
  if (!context) {
    throw new Error('useEngineer must be used within an EngineerProvider');
  }
  return context;
}

