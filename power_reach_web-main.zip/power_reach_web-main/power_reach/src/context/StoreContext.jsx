import { createContext, useContext, useReducer } from 'react';
import { mockUsers, mockReports, mockMessages, mockAgent } from '../data/mockData';

const StoreContext = createContext();

// Initial state
const initialState = {
  user: null, // Current logged-in agent
  users: mockUsers,
  reports: mockReports,
  messages: mockMessages,
  notifications: [],
  isAuthenticated: false,
};

// Action types
const ActionTypes = {
  LOGIN: 'LOGIN',
  LOGOUT: 'LOGOUT',
  ADD_REPORT: 'ADD_REPORT',
  UPDATE_REPORT: 'UPDATE_REPORT',
  ADD_MESSAGE: 'ADD_MESSAGE',
  UPDATE_MESSAGE: 'UPDATE_MESSAGE',
  MARK_MESSAGE_READ: 'MARK_MESSAGE_READ',
  ACCEPT_SPARKY_THREAD: 'ACCEPT_SPARKY_THREAD',
  ADD_NOTIFICATION: 'ADD_NOTIFICATION',
  REMOVE_NOTIFICATION: 'REMOVE_NOTIFICATION',
};

// Reducer
function storeReducer(state, action) {
  switch (action.type) {
    case ActionTypes.LOGIN:
      return {
        ...state,
        user: action.payload,
        isAuthenticated: true,
      };

    case ActionTypes.LOGOUT:
      return {
        ...state,
        user: null,
        isAuthenticated: false,
      };

    case ActionTypes.ADD_REPORT:
      return {
        ...state,
        reports: [action.payload, ...state.reports],
      };

    case ActionTypes.UPDATE_REPORT:
      return {
        ...state,
        reports: state.reports.map((report) =>
          report.id === action.payload.id ? { ...report, ...action.payload } : report
        ),
      };

    case ActionTypes.ADD_MESSAGE:
      return {
        ...state,
        messages: [action.payload, ...state.messages],
      };

    case ActionTypes.UPDATE_MESSAGE:
      return {
        ...state,
        messages: state.messages.map((message) =>
          message.id === action.payload.id ? { ...message, ...action.payload } : message
        ),
      };

    case ActionTypes.MARK_MESSAGE_READ:
      return {
        ...state,
        messages: state.messages.map((message) =>
          message.id === action.payload ? { ...message, isRead: true } : message
        ),
      };

    case ActionTypes.ACCEPT_SPARKY_THREAD:
      return {
        ...state,
        messages: state.messages.map((message) =>
          message.id === action.payload
            ? { ...message, status: 'claimed', isRead: true }
            : message
        ),
      };

    case ActionTypes.ADD_NOTIFICATION:
      return {
        ...state,
        notifications: [...state.notifications, action.payload],
      };

    case ActionTypes.REMOVE_NOTIFICATION:
      return {
        ...state,
        notifications: state.notifications.filter((n) => n.id !== action.payload),
      };

    default:
      return state;
  }
}

// Provider component
export function StoreProvider({ children }) {
  const [state, dispatch] = useReducer(storeReducer, initialState);

  // Helper functions
  const login = (email, password) => {
    // Mock authentication
    if (email && password) {
      dispatch({ type: ActionTypes.LOGIN, payload: mockAgent });
      return true;
    }
    return false;
  };

  const logout = () => {
    dispatch({ type: ActionTypes.LOGOUT });
  };

  const addReport = (report) => {
    const newReport = {
      ...report,
      id: `rpt_${Date.now()}`,
      createdAt: new Date().toISOString(),
      status: 'pending',
    };
    dispatch({ type: ActionTypes.ADD_REPORT, payload: newReport });
    return newReport;
  };

  const updateReport = (id, updates) => {
    dispatch({ type: ActionTypes.UPDATE_REPORT, payload: { id, ...updates } });
  };

  const addMessage = (message) => {
    const newMessage = {
      ...message,
      id: `msg_${Date.now()}`,
      createdAt: new Date().toISOString(),
      isRead: false,
    };
    dispatch({ type: ActionTypes.ADD_MESSAGE, payload: newMessage });
    return newMessage;
  };

  const markMessageRead = (id) => {
    dispatch({ type: ActionTypes.MARK_MESSAGE_READ, payload: id });
  };

  const acceptSparkyThread = (id) => {
    dispatch({ type: ActionTypes.ACCEPT_SPARKY_THREAD, payload: id });
  };

  const addNotification = (notification) => {
    const newNotification = {
      ...notification,
      id: `notif_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    dispatch({ type: ActionTypes.ADD_NOTIFICATION, payload: newNotification });
    return newNotification;
  };

  const removeNotification = (id) => {
    dispatch({ type: ActionTypes.REMOVE_NOTIFICATION, payload: id });
  };

  // Computed values
  const unreadMessagesCount = state.messages.filter((m) => !m.isRead).length;
  const pendingReportsCount = state.reports.filter((r) => r.status === 'pending').length;
  const unclaimedSparkyCount = state.messages.filter(
    (m) => m.isSparkyReport && m.status === 'unclaimed'
  ).length;

  const value = {
    ...state,
    login,
    logout,
    addReport,
    updateReport,
    addMessage,
    markMessageRead,
    acceptSparkyThread,
    addNotification,
    removeNotification,
    unreadMessagesCount,
    pendingReportsCount,
    unclaimedSparkyCount,
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

// Custom hook
export function useStore() {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
}

