import { createContext, useContext, useState, useEffect } from 'react';
import { api, authApi, reportingApi, AUTH_SESSION_INACTIVE_EVENT } from '../services/api';

const AdminContext = createContext();

const isAdmin = (userType) => userType === 'admin';

const mapProfileToAdminUser = (profileData) => {
    const profile = profileData?.profile || {};

    return {
        id: profileData?.id,
        readableId: profile.display_id,
        name: profile.full_name,
        email: profileData?.email,
        phone: profile.phone_number,
        branch: profile.branch,
        role: profileData?.user_type,
        user_type: profileData?.user_type,
        profile_picture: profile.profile_picture_url,
        isActive: profileData?.is_active,
        isVerified: profileData?.is_verified,
        rawProfile: profileData,
    };
};

const normalizeEngineerRecord = (engineer) => {
    const profile = engineer?.profile || {};

    return {
        ...engineer,
        name: engineer?.name || profile.full_name || '',
        readableId: engineer?.readableId || profile.display_id || '',
        email: engineer?.email || '',
        phone: engineer?.phone || profile.phone_number || '',
        branch: engineer?.branch || profile.branch || '',
        specialization: engineer?.specialization || profile.specialisation || profile.specialization || '',
        profile_picture: engineer?.profile_picture || profile.profile_picture_url || null,
        role: engineer?.role || engineer?.user_type,
        user_type: engineer?.user_type || 'engineer',
        isActive: engineer?.isActive ?? engineer?.is_active,
        isVerified: engineer?.isVerified ?? engineer?.is_verified,
        rawProfile: engineer?.rawProfile || engineer,
    };
};

const normalizeAgentRecord = (agent) => {
    const profile = agent?.profile || {};

    return {
        ...agent,
        name: agent?.name || profile.full_name || '',
        readableId: agent?.readableId || profile.display_id || '',
        email: agent?.email || '',
        phone: agent?.phone || profile.phone_number || '',
        branch: agent?.branch || profile.branch || '',
        profile_picture: agent?.profile_picture || profile.profile_picture_url || null,
        role: agent?.role || agent?.user_type,
        user_type: agent?.user_type || 'service_agent',
        isActive: agent?.isActive ?? agent?.is_active,
        isVerified: agent?.isVerified ?? agent?.is_verified,
        rawProfile: agent?.rawProfile || agent,
    };
};

const normalizeCustomerRecord = (customer) => {
    const profile = customer?.profile || {};

    return {
        ...customer,
        name: customer?.name || profile.full_name || '',
        readableId: customer?.readableId || profile.display_id || '',
        email: customer?.email || '',
        phone: customer?.phone || profile.phone_number || '',
        location: customer?.location || profile.branch || '',
        profile_picture: customer?.profile_picture || profile.profile_picture_url || null,
        role: customer?.role || customer?.user_type,
        user_type: customer?.user_type || 'customer',
        isActive: customer?.isActive ?? customer?.is_active,
        isVerified: customer?.isVerified ?? customer?.is_verified,
        rawProfile: customer?.rawProfile || customer,
    };
};

const REPORTING_STATUS_TO_UI = {
    pending: 'Received',
    in_progress: 'In Progress',
    resolved: 'Resolved',
};

const UI_STATUS_TO_REPORTING = {
    Received: 'pending',
    'In Progress': 'in_progress',
    Resolved: 'resolved',
};

function formatFaultTypeLabel(faultType) {
    if (!faultType) return '';
    return String(faultType)
        .replace(/_/g, ' ')
        .replace(/\b\w/g, (c) => c.toUpperCase());
}

/** Map reporting API report rows to the shape used by AdminReports and dashboard stats. */
function normalizeReportingReport(raw, engineersNormalized) {
    const key = String(raw?.status ?? '')
        .trim()
        .toLowerCase()
        .replace(/\s+/g, '_');
    const status = REPORTING_STATUS_TO_UI[key] || raw?.status || 'Received';

    const assignedToReadable = raw?.assigned_to ?? null;
    let assignedEngineerId = null;
    if (assignedToReadable) {
        const match = engineersNormalized.find(
            (e) => e.readableId === assignedToReadable
        );
        assignedEngineerId = match?.id ?? null;
    }

    const pr = raw?.priority;
    const priority =
        pr == null || pr === ''
            ? null
            : String(pr).trim().toLowerCase();

    return {
        id: raw.id,
        title: raw.title ?? '',
        description: raw.description ?? '',
        address: raw.address ?? '',
        customerId: raw.customer_id ?? null,
        createdByReadableId: raw.created_by ?? null,
        assignedByReadableId: raw.assigned_by ?? null,
        assignedToReadableId: assignedToReadable,
        userLocation: raw.location ?? '',
        userName: raw.customer_id ?? 'Unknown',
        readableId: raw.customer_id ?? raw.id,
        status,
        faultType: formatFaultTypeLabel(raw.fault_type),
        fault_type: raw.fault_type,
        priority,
        createdAt: raw.created_at,
        updatedAt: raw.updated_at,
        isSparkyReport: Boolean(raw.sparky_report),
        sparky_report: raw.sparky_report,
        assignedEngineerId,
        mediaUrls: Array.isArray(raw.media_urls) ? raw.media_urls : [],
        source: 'reporting_api',
    };
}

export function AdminProvider({ children }) {
    const [user, setUser] = useState(null);
    const [authLoading, setAuthLoading] = useState(true);
    const [stats, setStats] = useState({
        totalUsers: 0,
        activeStaff: 0,
        openFaults: 0,
        systemHealth: '100%'
    });
    const [recentActivity, setRecentActivity] = useState([]);
    const [admins, setAdmins] = useState([]);
    const [agents, setAgents] = useState([]);
    const [engineers, setEngineers] = useState([]);
    const [customers, setCustomers] = useState([]);
    const [reports, setReports] = useState([]);
    const [notifications, setNotifications] = useState([]);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const restoreSession = async () => {
            const token = localStorage.getItem('token');
            if (!token) {
                setAuthLoading(false);
                return;
            }

            try {
                const profileData = await authApi.getProfile();
                if (!isAdmin(profileData?.user_type)) {
                    return;
                }

                const mappedUser = mapProfileToAdminUser(profileData);
                setUser(mappedUser);
                authApi.initializeAuth();
            } catch (error) {
                console.error('Admin session restore failed:', error);
            } finally {
                setAuthLoading(false);
            }
        };

        restoreSession();
    }, []);

    // Login function for admin
    const login = async (email, password) => {
        try {
            const loginData = await authApi.login(email, password);
            if (!loginData) {
                return false;
            }

            const profileData = await authApi.getProfile();
            if (!isAdmin(profileData?.user_type)) {
                authApi.logout();
                return false;
            }

            const localAdmin = await api.loginAdmin(email, password).catch(() => null);
            const admin = localAdmin
                ? { ...localAdmin, role: profileData?.user_type, user_type: profileData?.user_type, rawProfile: profileData }
                : mapProfileToAdminUser(profileData);

            if (admin) {
                setUser(admin);
                return true;
            }
            return false;
        } catch (error) {
            console.error("Admin login failed", error);
            return false;
        }
    };

    const fetchDashboardData = async () => {
        setLoading(true);
        try {
            // Attempt to fetch all data
            const [users, agentsList, engineersList, reportsRaw, logs, adminNotifs, adminsList] = await Promise.all([
                authApi.getCustomers().catch(() => []),
                authApi.getAgents().catch(() => []),
                authApi.getEngineers().catch(() => []),
                reportingApi.getAllReports().catch(() => []),
                api.get('/audit_logs').catch(() => []),
                api.get('/admin_notifications').catch(() => []),
                authApi.getAdmins().catch(() => [])
            ]);

            const normalizedAdmins = Array.isArray(adminsList)
                ? adminsList
                : adminsList?.data || adminsList?.results || [];
            const normalizedCustomers = Array.isArray(users)
                ? users.map(normalizeCustomerRecord)
                : [];
            const normalizedAgents = Array.isArray(agentsList)
                ? agentsList.map(normalizeAgentRecord)
                : [];
            const normalizedEngineers = Array.isArray(engineersList)
                ? engineersList.map(normalizeEngineerRecord)
                : [];

            const reportingReports = Array.isArray(reportsRaw) ? reportsRaw : [];
            const normalizedReports = reportingReports.map((row) =>
                normalizeReportingReport(row, normalizedEngineers)
            );

            setAdmins(normalizedAdmins);
            setCustomers(normalizedCustomers);
            setAgents(normalizedAgents);
            setEngineers(normalizedEngineers);
            setReports(normalizedReports);

            setNotifications([...adminNotifs].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)));

            // Calculate stats
            const totalUsers = normalizedCustomers.length;
            const activeStaff = normalizedAgents.length + normalizedEngineers.length;
            const openFaults = normalizedReports.filter(
                (r) => r.status === 'Received' || r.status === 'In Progress'
            ).length;

            setStats({
                totalUsers,
                activeStaff,
                openFaults,
                systemHealth: '98% Uptime'
            });

            // Sort logs by timestamp desc
            const sortedLogs = logs.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)).slice(0, 5);
            setRecentActivity(sortedLogs);

        } catch (error) {
            console.error('Error fetching admin dashboard data:', error);
            // Even on catastrophic failure, provide some empty state or mock to prevent infinite loading
            setStats({
                totalUsers: 0,
                activeStaff: 0,
                openFaults: 0,
                systemHealth: 'Unknown'
            });
            setRecentActivity([]);
        } finally {
            setLoading(false);
        }
    };

    const sendBroadcast = async (data) => {
        // Mock Broadcast
        // In a real app, this would iterate over recipients or hit a broadcast endpoint
        try {
            const newNotification = {
                id: `notif_${Date.now()}`,
                title: data.title,
                message: data.message,
                urgency: data.urgency,
                senderType: 'admin',
                senderId: user.id || 'admin',
                recipientId: 'broadcast', // generic
                timestamp: new Date().toISOString(),
                target: data.target || 'all'
            };

            // We can't easily save a "broadcast" to json-server without expanding it to N users.
            // For this demo, we'll just save it to "notifications" assuming we have a way to view sent items.
            // We will simulate it by adding to local state and maybe creating one dummy record

            await api.createUserNotification(newNotification);

            setNotifications(prev => [newNotification, ...prev]);
            return true;
        } catch (e) {
            console.error("Broadcast failed", e);
            throw e;
        }
    };

    const updateAdminSettings = async (settings) => {
        // Mock API call
        await new Promise(resolve => setTimeout(resolve, 2000));
        console.log("Updated settings:", settings);

        // In a real app, we would update the user object in DB
        // api.updateUser(user.id, settings) ...
        return true;
    };

    const addStaff = async (type, data) => {
        try {
            if (type === 'agent') {
                const createdAgent = await authApi.registerServiceAgent({
                    email: data.email,
                    password: data.password,
                    full_name: data.name,
                    phone_number: data.phone,
                    branch: data.branch,
                });

                const agentsList = await authApi.getAgents().catch(() => []);
                const normalizedAgents = Array.isArray(agentsList)
                    ? agentsList.map(normalizeAgentRecord)
                    : [];

                if (normalizedAgents.length) {
                    setAgents(normalizedAgents);
                } else if (createdAgent) {
                    setAgents(prev => [normalizeAgentRecord(createdAgent), ...prev]);
                }

                return createdAgent;
            }

            if (type === 'engineer') {
                const createdEngineer = await authApi.registerEngineer({
                    email: data.email,
                    password: data.password,
                    full_name: data.name,
                    phone_number: data.phone,
                    branch: data.branch,
                    specialisation: data.specialization,
                });

                const engineersList = await authApi.getEngineers().catch(() => []);
                const normalizedEngineers = Array.isArray(engineersList)
                    ? engineersList.map(normalizeEngineerRecord)
                    : [];

                if (normalizedEngineers.length) {
                    setEngineers(normalizedEngineers);
                } else if (createdEngineer) {
                    setEngineers(prev => [normalizeEngineerRecord(createdEngineer), ...prev]);
                }

                return createdEngineer;
            }

            throw new Error(`Unsupported staff type: ${type}`);
        } catch (error) {
            console.error(`Error adding ${type}:`, error);
            throw error;
        }
    };

    const addAdmin = async (data) => {
        try {
            const createdAdmin = await authApi.registerAdmin(data);

            const adminsList = await authApi.getAdmins().catch(() => []);
            const normalizedAdmins = Array.isArray(adminsList)
                ? adminsList
                : adminsList?.data || adminsList?.results || [];

            if (normalizedAdmins.length) {
                setAdmins(normalizedAdmins);
            } else if (createdAdmin) {
                setAdmins(prev => [createdAdmin, ...prev]);
            }

            return createdAdmin;
        } catch (error) {
            console.error(`Error adding admin:`, error);
            throw error;
        }
    };

    const setUserActiveStatus = (userId, isActive) => {
        setAdmins(prev => prev.map(u => u.id === userId ? { ...u, isActive } : u));
        setAgents(prev => prev.map(u => u.id === userId ? { ...u, isActive } : u));
        setEngineers(prev => prev.map(u => u.id === userId ? { ...u, isActive } : u));
        setCustomers(prev => prev.map(u => u.id === userId ? { ...u, isActive } : u));
    };

    const deactivateUser = async (userId) => {
        await authApi.deactivateUser(userId);
        setUserActiveStatus(userId, false);
    };

    const reactivateUser = async (userId) => {
        await authApi.reactivateUser(userId);
        setUserActiveStatus(userId, true);
    };

    const updateAdminStaffProfile = async (readableId, payload) => {
        await authApi.updateAdminProfile(readableId, payload);
        const adminsList = await authApi.getAdmins().catch(() => []);
        const normalizedAdmins = Array.isArray(adminsList)
            ? adminsList
            : adminsList?.data || adminsList?.results || [];
        setAdmins(normalizedAdmins);
    };

    const updateEngineerStaffProfile = async (readableId, payload) => {
        await authApi.updateEngineerProfile(readableId, payload);
        const engineersList = await authApi.getEngineers().catch(() => []);
        const normalizedEngineers = Array.isArray(engineersList)
            ? engineersList.map(normalizeEngineerRecord)
            : [];
        setEngineers(normalizedEngineers);
    };

    const updateAgentStaffProfile = async (readableId, payload) => {
        await authApi.updateServiceAgentProfile(readableId, payload);
        const agentsList = await authApi.getAgents().catch(() => []);
        const normalizedAgents = Array.isArray(agentsList)
            ? agentsList.map(normalizeAgentRecord)
            : [];
        setAgents(normalizedAgents);
    };

    const updateCustomerStatus = async (id, isActive) => {
        try {
            if (isActive) {
                await reactivateUser(id);
            } else {
                await deactivateUser(id);
            }
        } catch (error) {
            console.error("Error updating customer status:", error);
            throw error;
        }
    };

    const mergeReportFromApiResponse = (responseBody) => {
        if (!responseBody || typeof responseBody !== 'object' || !responseBody.id) {
            return null;
        }
        return normalizeReportingReport(responseBody, engineers);
    };

    const updateReportAssignment = async (reportId, engineerId) => {
        try {
            const engineer = engineers.find((e) => e.id === engineerId);
            const assigned_to = engineer?.readableId?.trim() || null;
            if (!assigned_to) {
                throw new Error('Selected engineer has no readable ID; cannot assign via reporting API.');
            }
            const data = await reportingApi.adminUpdateReport(reportId, { assigned_to });
            const merged = mergeReportFromApiResponse(data);
            setReports((prev) =>
                prev.map((r) => {
                    if (r.id !== reportId) return r;
                    if (merged) return merged;
                    return {
                        ...r,
                        assignedEngineerId: engineerId,
                        assignedToReadableId: assigned_to,
                    };
                })
            );
        } catch (error) {
            console.error('Error reassigning report:', error);
            throw error;
        }
    };

    const updateReportStatus = async (reportId, newStatus) => {
        try {
            const status = UI_STATUS_TO_REPORTING[newStatus];
            if (!status) {
                throw new Error(`Unsupported status for reporting API: ${newStatus}`);
            }
            const data = await reportingApi.adminUpdateReport(reportId, { status });
            const merged = mergeReportFromApiResponse(data);
            setReports((prev) => {
                const next = prev.map((r) => {
                    if (r.id !== reportId) return r;
                    if (merged) return merged;
                    return { ...r, status: newStatus };
                });
                setStats((s) => ({
                    ...s,
                    openFaults: next.filter(
                        (rep) => rep.status === 'Received' || rep.status === 'In Progress'
                    ).length,
                }));
                return next;
            });
        } catch (error) {
            console.error('Error updating report status:', error);
            throw error;
        }
    };

    const forceCloseReport = async (reportId) => updateReportStatus(reportId, 'Resolved');

    useEffect(() => {
        if (user) {
            fetchDashboardData();
        }
    }, [user]);

    useEffect(() => {
        const onSessionInactive = () => {
            setUser(null);
        };
        window.addEventListener(AUTH_SESSION_INACTIVE_EVENT, onSessionInactive);
        return () => window.removeEventListener(AUTH_SESSION_INACTIVE_EVENT, onSessionInactive);
    }, []);

    const logout = () => {
        authApi.logout();
        setUser(null);
    };

    const value = {
        user,
        authLoading,
        stats,
        recentActivity,
        loading,
        notifications,
        admins,
        agents,
        engineers,
        customers,
        reports,
        fetchDashboardData,
        addStaff,
        addAdmin,
        deactivateUser,
        reactivateUser,
        updateAdminStaffProfile,
        updateEngineerStaffProfile,
        updateAgentStaffProfile,
        updateCustomerStatus,
        updateReportAssignment,
        forceCloseReport,
        updateReportStatus,
        updateAdminSettings,
        sendBroadcast,
        login,
        logout
    };

    return (
        <AdminContext.Provider value={value}>
            {children}
        </AdminContext.Provider>
    );
}

export function useAdmin() {
    const context = useContext(AdminContext);
    if (!context) {
        throw new Error('useAdmin must be used within an AdminProvider');
    }
    return context;
}
