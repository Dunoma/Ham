import { createContext, useContext, useReducer, useEffect } from 'react';
import { api, authApi, reportingApi, AUTH_SESSION_INACTIVE_EVENT } from '../services/api';

export const AgentContext = createContext();

// Initial state
const initialState = {
  user: null,
  users: [],
  engineers: [],
  reports: [],
  chats: [],
  messages: [],
  notifications: [],
  isAuthenticated: false,
  loading: true,
};

// Action types
const ActionTypes = {
  SET_LOADING: 'SET_LOADING',
  SET_USERS: 'SET_USERS',
  SET_ENGINEERS: 'SET_ENGINEERS',
  SET_REPORTS: 'SET_REPORTS',
  SET_CHATS: 'SET_CHATS',
  SET_MESSAGES: 'SET_MESSAGES',
  LOGIN: 'LOGIN',
  LOGOUT: 'LOGOUT',
  ADD_REPORT: 'ADD_REPORT',
  UPDATE_REPORT: 'UPDATE_REPORT',
  ADD_MESSAGE: 'ADD_MESSAGE',
  UPDATE_MESSAGE: 'UPDATE_MESSAGE',
  MARK_MESSAGE_READ: 'MARK_MESSAGE_READ',
  ACCEPT_SPARKY_THREAD: 'ACCEPT_SPARKY_THREAD',
  ADD_NOTIFICATION: 'ADD_NOTIFICATION',
  REMOVE_NOTIFICATION: 'REMOVE_NOTIFICATION',
  SET_NOTIFICATIONS: 'SET_NOTIFICATIONS',
};

// Reducer
function agentReducer(state, action) {
  switch (action.type) {
    case ActionTypes.SET_LOADING:
      return { ...state, loading: action.payload };

    case ActionTypes.SET_USERS:
      return { ...state, users: action.payload };

    case ActionTypes.SET_ENGINEERS:
      return { ...state, engineers: action.payload };

    case ActionTypes.SET_REPORTS:
      return { ...state, reports: action.payload };

    case ActionTypes.SET_CHATS:
      return { ...state, chats: action.payload };

    case ActionTypes.SET_MESSAGES:
      return { ...state, messages: action.payload };

    case ActionTypes.LOGIN:
      return {
        ...state,
        user: action.payload,
        isAuthenticated: true,
      };

    case ActionTypes.LOGOUT:
      return {
        ...state,
        user: null,
        isAuthenticated: false,
      };

    case ActionTypes.ADD_REPORT:
      return {
        ...state,
        reports: [action.payload, ...state.reports],
      };

    case ActionTypes.UPDATE_REPORT:
      return {
        ...state,
        reports: state.reports.map((report) =>
          report.id === action.payload.id ? { ...report, ...action.payload } : report
        ),
      };

    case ActionTypes.ADD_MESSAGE:
      return {
        ...state,
        messages: [action.payload, ...state.messages],
      };

    case ActionTypes.UPDATE_MESSAGE:
      return {
        ...state,
        messages: state.messages.map((message) =>
          message.id === action.payload.id ? { ...message, ...action.payload } : message
        ),
      };

    case ActionTypes.MARK_MESSAGE_READ:
      return {
        ...state,
        messages: state.messages.map((message) =>
          message.id === action.payload ? { ...message, isRead: true } : message
        ),
      };

    case ActionTypes.ACCEPT_SPARKY_THREAD:
      return {
        ...state,
        messages: state.messages.map((message) =>
          message.id === action.payload
            ? { ...message, status: 'claimed', isRead: true }
            : message
        ),
      };

    case ActionTypes.ADD_NOTIFICATION:
      return {
        ...state,
        notifications: [...state.notifications, action.payload],
      };

    case ActionTypes.REMOVE_NOTIFICATION:
      return {
        ...state,
        notifications: state.notifications.filter((n) => n.id !== action.payload),
      };

    case ActionTypes.SET_NOTIFICATIONS:
      return { ...state, notifications: action.payload };

    default:
      return state;
  }
}

const mapProfileToAgentUser = (profileData) => {
  const profile = profileData?.profile || {};

  return {
    id: profileData?.id,
    readableId: profile.display_id,
    name: profile.full_name,
    email: profileData?.email,
    phone: profile.phone_number,
    branch: profile.branch,
    role: profileData?.user_type,
    user_type: profileData?.user_type,
    profile_picture: profile.profile_picture_url,
    isActive: profileData?.is_active,
    isVerified: profileData?.is_verified,
    rawProfile: profileData,
  };
};

const isServiceAgent = (userType) => userType === 'service_agent';

function formatFaultTypeLabel(faultType) {
  if (!faultType) return '';
  return String(faultType)
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

/** Map reporting API rows to the report shape used by agent Reports / Dashboard. */
function normalizeReportingReportForAgent(raw, engineersList, usersList) {
  const engineersArr = Array.isArray(engineersList) ? engineersList : [];
  const usersArr = Array.isArray(usersList) ? usersList : [];

  const assignedToReadable = raw?.assigned_to ?? null;
  let assignedEngineerId = null;
  if (assignedToReadable) {
    const eng = engineersArr.find(
      (e) =>
        e.readableId === assignedToReadable || e.id === assignedToReadable
    );
    assignedEngineerId = eng?.id ?? null;
  }

  const customerReadable = raw?.customer_id ?? '';
  const cust = usersArr.find(
    (u) =>
      u.readableId === customerReadable || u.id === customerReadable
  );
  const userId = cust?.id ?? customerReadable;
  const userName = cust?.name || customerReadable || 'Customer';

  const pr = raw?.priority;
  const priority =
    pr == null || pr === ''
      ? null
      : String(pr).trim().toLowerCase();

  return {
    id: raw.id,
    title: raw.title ?? '',
    description: raw.description ?? '',
    userLocation: raw.location ?? '',
    faultType: formatFaultTypeLabel(raw.fault_type),
    createdAt: raw.created_at,
    isSparkyReport: Boolean(raw.sparky_report),
    assignedEngineerId,
    priority,
    userId,
    userName,
    customerId: customerReadable,
    source: 'reporting_api',
    mediaUrls: Array.isArray(raw.media_urls) ? raw.media_urls : [],
    address: raw.address ?? '',
  };
}

// Provider component
export function AgentProvider({ children }) {
  const [state, dispatch] = useReducer(agentReducer, initialState);

  useEffect(() => {
    const restoreSession = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        dispatch({ type: ActionTypes.SET_LOADING, payload: false });
        return;
      }

      try {
        const profileData = await authApi.getProfile();
        if (!isServiceAgent(profileData?.user_type)) {
          return;
        }
        const mappedUser = mapProfileToAgentUser(profileData);
        dispatch({ type: ActionTypes.LOGIN, payload: mappedUser });
        authApi.initializeAuth();
      } catch (error) {
        console.error('Session restore failed:', error);
      } finally {
        dispatch({ type: ActionTypes.SET_LOADING, payload: false });
      }
    };

    restoreSession();
  }, []);

  useEffect(() => {
    const onSessionInactive = () => {
      dispatch({ type: ActionTypes.LOGOUT });
    };
    window.addEventListener(AUTH_SESSION_INACTIVE_EVENT, onSessionInactive);
    return () => window.removeEventListener(AUTH_SESSION_INACTIVE_EVENT, onSessionInactive);
  }, []);

  // Fetch initial data from API
  // Fetch initial data from API
  const fetchNotifications = async () => {
    if (!state.user) return;
    try {
      const [received, sent] = await Promise.all([
        api.getAgentNotifications(state.user.id),
        api.getAgentSentNotifications(state.user.id),
      ]);

      // Create lookups for readable IDs
      const userMap = new Map(state.users.map(u => [u.id, u]));
      const engineerMap = new Map(state.engineers.map(e => [e.id, e]));

      const allNotifications = [...received, ...sent]
        .map((notification) => {
          const sender = userMap.get(notification.senderId) || engineerMap.get(notification.senderId);
          const recipient = userMap.get(notification.recipientId) || engineerMap.get(notification.recipientId);

          return {
            ...notification,
            isRead: notification.isRead !== undefined ? notification.isRead : false,
            senderReadableId: sender?.readableId,
            recipientReadableId: recipient?.readableId,
          };
        })
        // Sort by timestamp desc to avoid jitter
        .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

      dispatch({ type: ActionTypes.SET_NOTIFICATIONS, payload: allNotifications });
    } catch (error) {
      console.error('Error fetching notifications:', error);
    }
  };

  useEffect(() => {
    if (state.user && state.isAuthenticated) {
      const fetchData = async () => {
        try {
          dispatch({ type: ActionTypes.SET_LOADING, payload: true });
          const [users, engineers, reportsRaw, chats, messages, receivedNotifs, sentNotifs] =
            await Promise.all([
              api.getUsers(),
              api.getEngineers(),
              reportingApi.getAllReports().catch(() => []),
              api.getChats(),
              api.getMessages(),
              api.getAgentNotifications(state.user.id),
              api.getAgentSentNotifications(state.user.id),
            ]);

          const reports = Array.isArray(reportsRaw)
            ? reportsRaw.map((row) =>
                normalizeReportingReportForAgent(row, engineers, users)
              )
            : [];

          // Create lookups for readable IDs
          const userMap = new Map(users.map(u => [u.id, u]));
          const engineerMap = new Map(engineers.map(e => [e.id, e]));

          const allNotifications = [...receivedNotifs, ...sentNotifs]
            .map((notification) => {
              const sender = userMap.get(notification.senderId) || engineerMap.get(notification.senderId);
              const recipient = userMap.get(notification.recipientId) || engineerMap.get(notification.recipientId);

              return {
                ...notification,
                isRead: notification.isRead !== undefined ? notification.isRead : false,
                senderReadableId: sender?.readableId,
                recipientReadableId: recipient?.readableId,
              };
            })
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

          dispatch({ type: ActionTypes.SET_USERS, payload: users });
          dispatch({ type: ActionTypes.SET_ENGINEERS, payload: engineers });
          dispatch({ type: ActionTypes.SET_REPORTS, payload: reports });
          dispatch({ type: ActionTypes.SET_CHATS, payload: chats });
          dispatch({ type: ActionTypes.SET_MESSAGES, payload: messages });
          dispatch({ type: ActionTypes.SET_NOTIFICATIONS, payload: allNotifications });
        } catch (error) {
          console.error('Error fetching data:', error);
        } finally {
          dispatch({ type: ActionTypes.SET_LOADING, payload: false });
        }
      };

      fetchData();
    }
  }, [state.user, state.isAuthenticated]);

  // Helper functions
  const login = async (email, password) => {
    try {
      const loginData = await authApi.login(email, password);
      
      if (loginData) {
        const profileData = await authApi.getProfile();
        if (!isServiceAgent(profileData?.user_type)) {
          authApi.logout();
          return false;
        }
        const mappedUser = mapProfileToAgentUser(profileData);
        dispatch({ type: ActionTypes.LOGIN, payload: mappedUser });
        return true;
      }
      // If API returns null/undefined, try fallback
      const trimmedEmail = email?.trim().toLowerCase();
      const trimmedPassword = password?.trim();
      if (trimmedEmail === 'adebayo.ogunleye@powerreach.ng' && trimmedPassword === 'password123') {
        const fallbackAgent = {
          id: '550e8400-e29b-41d4-a716-446655440100',
          readableId: 'AG-201',
          name: 'Adebayo Ogunleye',
          email: 'adebayo.ogunleye@powerreach.ng',
          phone: '+234 810 111 2222',
          role: 'Customer Service Agent',
          profile_picture: '/profile_picture.jpg',
        };
        dispatch({ type: ActionTypes.LOGIN, payload: fallbackAgent });
        return true;
      }
      return false;
    } catch (error) {
      console.error('Login error:', error);
      // Fallback authentication if API is unavailable
      const trimmedEmail = email?.trim().toLowerCase();
      const trimmedPassword = password?.trim();
      if (trimmedEmail === 'agent@powerreach.ng' && trimmedPassword === 'password123') {
        const fallbackAgent = {
          id: '550e8400-e29b-41d4-a716-446655440100',
          readableId: 'AG-201',
          name: 'Adebayo Ogunleye',
          email: 'agent@powerreach.ng',
          phone: '+234 810 111 2222',
          role: 'Customer Service Agent',
          profile_picture: '/profile_picture.jpg',
        };
        dispatch({ type: ActionTypes.LOGIN, payload: fallbackAgent });
        return true;
      }
      return false;
    }
  };

  const logout = () => {
    authApi.logout();
    dispatch({ type: ActionTypes.LOGOUT });
  };

  const addReport = async (report) => {
    try {
      const newReport = await api.createReport({
        ...report,
        createdAt: new Date().toISOString(),
        status: 'pending',
      });
      dispatch({ type: ActionTypes.ADD_REPORT, payload: newReport });
      return newReport;
    } catch (error) {
      console.error('Error creating report:', error);
      throw error;
    }
  };

  const updateReport = async (id, updates) => {
    try {
      const updatedReport = await api.updateReport(id, updates);
      dispatch({ type: ActionTypes.UPDATE_REPORT, payload: { id, ...updatedReport } });
      return updatedReport;
    } catch (error) {
      console.error('Error updating report:', error);
      throw error;
    }
  };

  const addMessage = async (message) => {
    try {
      const newMessage = await api.createMessage({
        ...message,
        createdAt: new Date().toISOString(),
        isRead: true,
      });
      dispatch({ type: ActionTypes.ADD_MESSAGE, payload: newMessage });
      return newMessage;
    } catch (error) {
      console.error('Error creating message:', error);
      throw error;
    }
  };

  const markMessageRead = async (id) => {
    try {
      await api.updateMessage(id, { isRead: true });
      dispatch({ type: ActionTypes.MARK_MESSAGE_READ, payload: id });
    } catch (error) {
      console.error('Error marking message read:', error);
    }
  };

  const acceptSparkyThread = async (id) => {
    try {
      await api.updateMessage(id, { status: 'claimed', isRead: true });
      dispatch({ type: ActionTypes.ACCEPT_SPARKY_THREAD, payload: id });
    } catch (error) {
      console.error('Error accepting Sparky thread:', error);
    }
  };

  const addNotification = (notification) => {
    const newNotification = {
      ...notification,
      id: `notif_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    dispatch({ type: ActionTypes.ADD_NOTIFICATION, payload: newNotification });
    return newNotification;
  };

  const removeNotification = (id) => {
    dispatch({ type: ActionTypes.REMOVE_NOTIFICATION, payload: id });
  };

  const sendNotification = async (notificationData) => {
    try {
      // Generate UUID for the notification
      const notificationId = `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

      const newNotification = {
        id: notificationId,
        title: notificationData.title,
        message: notificationData.message,
        urgency: notificationData.urgency,
        senderType: 'agent',
        senderId: state.user.id,
        recipientId: notificationData.recipientId,
        timestamp: new Date().toISOString(),
      };

      const createdNotification = await api.createUserNotification(newNotification);

      // Refresh notifications if sent to current user (though typically agent sends to customer)
      if (createdNotification.senderId === state.user?.id) {
        await fetchNotifications();
      }

      return createdNotification;
    } catch (error) {
      console.error('Error sending notification:', error);
      throw error;
    }
  };

  // Computed values
  const unreadMessagesCount = state.messages.filter((m) => !m.isRead).length;
  const pendingReportsCount = state.reports.filter((r) => !r.assignedEngineerId).length;
  const unclaimedSparkyCount = state.messages.filter(
    (m) => m.isSparkyReport && m.status === 'unclaimed'
  ).length;

  const value = {
    ...state,
    login,
    logout,
    addReport,
    updateReport,
    addMessage,
    markMessageRead,
    acceptSparkyThread,
    addNotification,
    removeNotification,
    unreadMessagesCount,
    pendingReportsCount,
    unclaimedSparkyCount,
    sendNotification,
    updateAgentSettings: async (settings) => { await new Promise(r => setTimeout(r, 1000)); console.log("Updated agent settings:", settings); return true; },
    fetchNotifications,
  };

  return <AgentContext.Provider value={value}>{children}</AgentContext.Provider>;
}

// Custom hook
export function useAgent() {
  const context = useContext(AgentContext);
  if (!context) {
    throw new Error('useAgent must be used within an AgentProvider');
  }
  return context;
}

