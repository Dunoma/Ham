const AUTH_API_BASE_URL = import.meta.env.VITE_APP_AUTH_API_BASE_URL;
const REPORTING_API_BASE_URL = import.meta.env.VITE_APP_REPORTING_API_BASE_URL;
const API_BASE_URL = "http://localhost:3001" // testing

// Generic fetch function
async function fetchAPI(endpoint, options = {}) {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error(`API Error (${endpoint}):`, error);
    throw error;
  }
}

async function fetchAuthAPI(endpoint, options = {}) {
  try {
    const response = await fetch(`${AUTH_API_BASE_URL}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error(`API Error (${endpoint}):`, error);
    throw error;
  }
}

function buildPatchBody(fields) {
  return JSON.stringify(
    Object.fromEntries(
      Object.entries(fields).filter(([, value]) => value !== undefined)
    )
  );
}

async function fetchReportingAPI(endpoint, options = {}) {
  try {
    const response = await fetch(`${REPORTING_API_BASE_URL}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const text = await response.text();
    if (!text?.trim()) {
      return null;
    }
    return JSON.parse(text);
  } catch (error) {
    console.error(`API Error (${endpoint}):`, error);
    throw error;
  }
}

let refreshInterval = null;

/** @type {null | (() => Promise<boolean>)} */
let sessionPresenceRequest = null;

/** Dispatched when the user does not confirm presence before refresh; contexts should clear local user state. */
export const AUTH_SESSION_INACTIVE_EVENT = 'auth:session-inactive';

/** Fired from `logout` so any in-flight presence prompt can resolve and release the refresh callback. */
export const AUTH_TOKENS_CLEARED_EVENT = 'auth:tokens-cleared';

const REFRESH_INTERVAL_MS = 25 * 60 * 1000;

const stopTokenRefresh = () => {
  if (refreshInterval) {
    clearInterval(refreshInterval);
    refreshInterval = null;
  }
};

async function persistRefreshResponse(data) {
  const newToken = data.access_token || data.accessToken || data.token;
  const newRefreshToken = data.refresh_token || data.refreshToken;

  if (newToken) {
    localStorage.setItem('token', newToken);
  }
  if (newRefreshToken) {
    localStorage.setItem('refresh_token', newRefreshToken);
  }
}

async function refreshTokensFromServer({ throwIfMissingRefresh = false } = {}) {
  const refreshToken = localStorage.getItem('refresh_token');
  if (!refreshToken) {
    if (throwIfMissingRefresh) {
      throw new Error('No refresh token available');
    }
    return null;
  }

  const data = await fetchAuthAPI('/auth/refresh', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${localStorage.getItem('token')}`,
    },
    body: JSON.stringify({ refresh_token: refreshToken }),
  });

  await persistRefreshResponse(data);
  return data;
}

function endSessionDueToInactivity() {
  stopTokenRefresh();
  authApi.logout();
  window.dispatchEvent(new CustomEvent(AUTH_SESSION_INACTIVE_EVENT));
}

const startTokenRefresh = () => {
  const token = localStorage.getItem('token');
  const refreshToken = localStorage.getItem('refresh_token');
  if (!token || !refreshToken) return;

  stopTokenRefresh();

  refreshInterval = setInterval(async () => {
    try {
      const rt = localStorage.getItem('refresh_token');
      if (!rt) return;

      if (sessionPresenceRequest) {
        const stillHere = await sessionPresenceRequest();
        if (!stillHere) {
          endSessionDueToInactivity();
          return;
        }
      }

      await refreshTokensFromServer();
    } catch (error) {
      console.error('Token refresh failed:', error);
    }
  }, REFRESH_INTERVAL_MS);
};

export const authApi = {
  login: async (email, password) => {
    const data = await fetchAuthAPI('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    
    const token = data.access_token || data.accessToken || data.token;
    const refreshToken = data.refresh_token || data.refreshToken;

    if (token) {
      localStorage.setItem('token', token);
      if (refreshToken) {
        localStorage.setItem('refresh_token', refreshToken);
      }
      startTokenRefresh();
    }
    
    return data;
  },

  initializeAuth: () => {
    startTokenRefresh();
  },

  registerSessionPresence: (requestConfirmation) => {
    sessionPresenceRequest = requestConfirmation;
  },

  clearSessionPresence: () => {
    sessionPresenceRequest = null;
  },

  logout: () => {
    stopTokenRefresh();
    localStorage.removeItem('token');
    localStorage.removeItem('refresh_token');
    window.dispatchEvent(new CustomEvent(AUTH_TOKENS_CLEARED_EVENT));
  },

  getProfile: () => fetchAuthAPI('/users/me', {
    headers: {
      Authorization: `Bearer ${localStorage.getItem('token')}`,
    }
  }),

  refreshToken: () => refreshTokensFromServer({ throwIfMissingRefresh: true }),

  deactivateUser: (userId) => {
    const request = fetchAuthAPI(`/auth/deactivate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
      },
      body: JSON.stringify({ user_id: userId }),
    });

    const message = request.message
    return message;
  },

  reactivateUser: (userId) => {
    const request = fetchAuthAPI(`/auth/re-activate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
      },
      body: JSON.stringify({ user_id: userId }),
    });

    const message = request.message
    return message;
  },

  changePassword: async (currentPassword, newPassword) => {
    const data = await fetchAuthAPI('/auth/change-password', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
      },
      body: JSON.stringify({
        current_password: currentPassword,
        new_password: newPassword,
      }),
    });

    const message = data.message || 'Password changed successfully';
    return message;
  },

  registerAdmin: async ({ email, password, full_name, phone_number, branch }) => {
    const data = await fetchAuthAPI('/auth/register/admin', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
      },
      body: JSON.stringify({
        email,
        password,
        full_name,
        phone_number,
        branch,
      }),
    });

    return data;
  },

  registerEngineer: async ({ email, password, full_name, phone_number, branch, specialisation }) => {
    const data = await fetchAuthAPI('/auth/register/engineer', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
      },
      body: JSON.stringify({
        email,
        password,
        full_name,
        phone_number,
        branch,
        specialisation,
      }),
    });

    return data;
  },

  registerServiceAgent: async ({ email, password, full_name, phone_number, branch }) => {
    const data = await fetchAuthAPI('/auth/register/service-agent', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
      },
      body: JSON.stringify({
        email,
        password,
        full_name,
        phone_number,
        branch,
      }),
    });

    return data;
  },

  getAdmins: () => fetchAuthAPI('/users/admins/all', {
    headers: {
      Authorization: `Bearer ${localStorage.getItem('token')}`,
    }
  }),

  getEngineers: () => fetchAuthAPI('/users/engineers/all', {
    headers: {
      Authorization: `Bearer ${localStorage.getItem('token')}`,
    }
  }),

  getAgents: () => fetchAuthAPI('/users/service-agents/all', {
    headers: {  
      Authorization: `Bearer ${localStorage.getItem('token')}`,
    }
  }),

  getCustomers: () => fetchAuthAPI('/users/customers/all', {
    headers: {
      Authorization: `Bearer ${localStorage.getItem('token')}`,
    }
  }),

  updateAdminProfile: async (readableId, { full_name, phone_number, branch, profile_picture_url }) => {
    const body = buildPatchBody({
      full_name,
      phone_number,
      branch,
      profile_picture_url,
    });
    return fetchAuthAPI(`/users/admins/${encodeURIComponent(readableId)}/profile`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
      },
      body,
    });
  },

  updateEngineerProfile: async (readableId, { full_name, phone_number, branch, specialisation, profile_picture_url }) => {
    const body = buildPatchBody({
      full_name,
      phone_number,
      branch,
      specialisation,
      profile_picture_url,
    });
    return fetchAuthAPI(`/users/engineers/${encodeURIComponent(readableId)}/profile`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
      },
      body,
    });
  },

  updateServiceAgentProfile: async (readableId, { full_name, phone_number, branch, profile_picture_url }) => {
    const body = buildPatchBody({
      full_name,
      phone_number,
      branch,
      profile_picture_url,
    });
    return fetchAuthAPI(`/users/service-agents/${encodeURIComponent(readableId)}/profile`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json', 
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
      },
      body,
    });
  },
};

export const reportingApi = {
  /**
   * All fault reports from the reporting service (admin).
   * @returns {Promise<Array<Record<string, unknown>>>}
   */
  getAllReports: async () => {
    const data = await fetchReportingAPI('/reports/all', {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`,
      },
    });
    if (Array.isArray(data)) return data;
    if (Array.isArray(data?.data)) return data.data;
    if (Array.isArray(data?.results)) return data.results;
    return [];
  },

  

  /**
   * Admin PATCH: optional `assigned_to` (engineer readable id, e.g. EN-00002) and/or `status` (reporting API enum).
   */
  adminUpdateReport: async (reportId, { assigned_to, status } = {}) => {
    const body = buildPatchBody({ assigned_to, status });
    return fetchReportingAPI(`/reports/${encodeURIComponent(reportId)}/admin`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
      },
      body,
    });
  },
};

// GET requests
export const api = {
  // Generic
  get: (endpoint) => fetchAPI(endpoint),

  // Users
  getUsers: () => fetchAPI('/users'),
  getUser: (id) => fetchAPI(`/users/${id}`),
  updateUser: (id, updates) =>
    fetchAuthAPI(`/users/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(updates),
    }), // TODO - add to backend as well

  // Agents
  getAgents: () => fetchAPI('/agents'),
  getAgent: (id) => fetchAPI(`/agents/${id}`),
  createAgent: (agent) =>
    fetchAPI('/agents', {
      method: 'POST',
      body: JSON.stringify(agent),
    }),
  loginAgent: async (email, password) => {
    try {
      const agents = await fetchAPI('/agents');
      const trimmedEmail = email?.trim().toLowerCase();
      const trimmedPassword = password?.trim();
      return agents.find(
        (agent) =>
          agent.email?.trim().toLowerCase() === trimmedEmail &&
          agent.password?.trim() === trimmedPassword
      );
    } catch (error) {
      console.error('Login API error:', error);
      // Fallback: if API fails, check against hardcoded credentials
      if (email?.trim().toLowerCase() === 'agent@powerreach.ng' && password?.trim() === 'password123') {
        return {
          id: '550e8400-e29b-41d4-a716-446655440100',
          name: 'Adebayo Ogunleye',
          email: 'agent@powerreach.ng',
          phone: '+234 810 111 2222',
          role: 'Customer Service Agent',
          profile_picture: '/profile_picture.jpg',
        };
      }
      throw error;
    }
  },
  getAgentNotifications: async (agentId) => {
    try {
      const filtered = await fetchAPI(`/agent_notifications?recipientId=${agentId}`);
      return filtered;
    } catch (error) {
      const all = await fetchAPI('/agent_notifications');
      return all.filter((n) => n.recipientId === agentId);
    }
  },
  getAgentSentNotifications: async (agentId) => {
    try {
      const filtered = await fetchAPI(`/user_notifications?senderId=${agentId}`);
      return filtered;
    } catch (error) {
      const all = await fetchAPI('/user_notifications');
      return all.filter((n) => n.senderId === agentId);
    }
  },
  createAgentNotification: (notification) =>
    fetchAPI('/agent_notifications', {
      method: 'POST',
      body: JSON.stringify(notification),
    }),
  // Engineers
  getEngineers: () => fetchAPI('/engineers'),
  getEngineer: (id) => fetchAPI(`/engineers/${id}`),
  createEngineer: (engineer) =>
    fetchAPI('/engineers', {
      method: 'POST',
      body: JSON.stringify(engineer),
    }),
  loginEngineer: async (email, password) => {
    try {
      const engineers = await fetchAPI('/engineers');
      const trimmedEmail = email?.trim().toLowerCase();
      const trimmedPassword = password?.trim();
      return engineers.find(
        (engineer) =>
          engineer.email?.trim().toLowerCase() === trimmedEmail &&
          engineer.password?.trim() === trimmedPassword
      );
    } catch (error) {
      console.error('Engineer login API error:', error);
      // Fallback: if API fails, check against hardcoded credentials
      const trimmedEmail = email?.trim().toLowerCase();
      const trimmedPassword = password?.trim();
      if (trimmedEmail === 'emeka.nwankwo@powerreach.ng' && trimmedPassword === 'password123') {
        return {
          id: '550e8400-e29b-41d4-a716-446655440200',
          name: 'Emeka Nwankwo',
          email: 'emeka.nwankwo@powerreach.ng',
          phone: '+234 811 222 3333',
          branch: 'Wuse II',
          specialization: 'Transformer Maintenance',
          profile_picture: 'profile_picture.jpg',
        };
      }
      throw error;
    }
  },
  getEngineerNotifications: async (engineerId) => {
    try {
      // Try to get filtered notifications first
      const filtered = await fetchAPI(`/engineer_notifications?recipientId=${engineerId}`);
      return filtered;
    } catch (error) {
      // Fallback: get all and filter client-side
      const all = await fetchAPI('/engineer_notifications');
      return all.filter((n) => n.recipientId === engineerId);
    }
  },
  getEngineerSentNotifications: async (engineerId) => {
    try {
      const filtered = await fetchAPI(`/engineer_notifications?senderId=${engineerId}`);
      return filtered;
    } catch (error) {
      const all = await fetchAPI('/engineer_notifications');
      return all.filter((n) => n.senderId === engineerId);
    }
  },
  createEngineerNotification: (notification) =>
    fetchAPI('/engineer_notifications', {
      method: 'POST',
      body: JSON.stringify(notification),
    }),

  // Reports
  getReports: () => fetchAPI('/reports'),
  getReport: (id) => fetchAPI(`/reports/${id}`),
  createReport: (report) =>
    fetchAPI('/reports', {
      method: 'POST',
      body: JSON.stringify(report),
    }),
  updateReport: (id, updates) =>
    fetchAPI(`/reports/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(updates),
    }),

  // Chats
  getChats: () => fetchAPI('/chats'),
  getChat: (id) => fetchAPI(`/chats/${id}`),
  createChat: (chat) =>
    fetchAPI('/chats', {
      method: 'POST',
      body: JSON.stringify(chat),
    }),

  // Messages
  getMessages: () => fetchAPI('/messages'),
  getMessage: (id) => fetchAPI(`/messages/${id}`),
  getMessagesByChatId: (chatId) => fetchAPI(`/messages?chatId=${chatId}`),
  createMessage: (message) =>
    fetchAPI('/messages', {
      method: 'POST',
      body: JSON.stringify(message),
    }),
  updateMessage: (id, updates) =>
    fetchAPI(`/messages/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(updates),
    }),

  // User Notifications
  getUserNotifications: (userId) => fetchAPI(`/user_notifications?recipientId=${userId}`),
  createUserNotification: (notification) =>
    fetchAPI('/user_notifications', {
      method: 'POST',
      body: JSON.stringify(notification),
    }),

  // Admins
  getAdmins: () => fetchAPI('/admins'),
  createAdmin: (admin) =>
    fetchAPI('/admins', {
      method: 'POST',
      body: JSON.stringify(admin),
    }),
  loginAdmin: async (email, password) => {
    try {
      const admins = await fetchAPI('/admins');
      const trimmedEmail = email?.trim().toLowerCase();
      const trimmedPassword = password?.trim();
      return admins.find(
        (admin) =>
          admin.email?.trim().toLowerCase() === trimmedEmail &&
          admin.password?.trim() === trimmedPassword
      );
    } catch (error) {
      console.error('Admin login API error:', error);
      // Fallback: if API fails, check against hardcoded credentials
      if (email?.trim().toLowerCase() === 'admin@powerreach.ng' && password?.trim() === 'password123') {
        return {
          id: '550e8400-e29b-41d4-a716-446655449999',
          readableId: 'AD-001',
          name: 'Super Admin',
          role: 'admin',
          email: 'admin@powerreach.ng',
        };
      }
      throw error;
    }
  },
};

