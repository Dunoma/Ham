import { Navigate } from 'react-router-dom';
import { useAgent } from '../context/AgentContext';

export default function ProtectedRoute({ children }) {
  const { isAuthenticated, user, loading } = useAgent();

  const userType = user?.role || user?.user_type;
  const isServiceAgent = userType === 'service_agent';

  if (loading) {
    return null;
  }

  if (!isAuthenticated || !isServiceAgent) {
    return <Navigate to="/agent/login" replace />;
  }

  return children;
}

