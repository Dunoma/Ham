import { useState } from 'react';
import { createPortal } from 'react-dom';
import { X, Send, User, Users, CheckCircle } from 'lucide-react';
import { useEngineer } from '../context/EngineerContext';

export default function SendNotificationModal({ onClose, onSuccess }) {
  const { sendNotification } = useEngineer();
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [urgency, setUrgency] = useState('medium');
  const [recipientId, setRecipientId] = useState('');
  const [recipientType, setRecipientType] = useState('engineer'); // 'engineer' or 'customer'
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!title.trim()) {
      setError('Title is required');
      return;
    }

    if (!message.trim()) {
      setError('Message is required');
      return;
    }

    if (!recipientId.trim()) {
      setError('Recipient ID is required');
      return;
    }

    setIsSubmitting(true);

    try {
      await sendNotification({
        title: title.trim(),
        message: message.trim(),
        urgency,
        recipientId: recipientId.trim(),
        recipientType,
      });

      if (onSuccess) {
        onSuccess();
      }

      setIsSuccess(true);

      // Auto close after 1.5 seconds
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (error) {
      console.error('Error sending notification:', error);
      setError('Failed to send notification. Please try again.');
      setIsSubmitting(false);
    }
  };

  if (isSuccess) {
    return createPortal(
      <div className="fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]" style={{ margin: 0, padding: 0 }}>
        <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-8 flex flex-col items-center animate-fade-in-up">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-4 animate-bounce-short">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h3 className="text-xl font-bold text-gray-900 mb-2">Notification Sent!</h3>
          <p className="text-gray-500 text-center">Your message has been delivered successfully.</p>
        </div>
      </div>,
      document.body
    );
  }

  return createPortal(
    <div className="fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]" style={{ margin: 0, padding: 0 }}>
      <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto m-4">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">Send Notification</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
              {error}
            </div>
          )}

          {/* Recipient Type Selector */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Recipient Type
            </label>
            <div className="flex gap-4">
              <label className={`flex-1 flex items-center justify-center gap-2 p-3 rounded-lg border cursor-pointer transition ${recipientType === 'engineer'
                ? 'bg-primary-50 border-primary-500 text-primary-700'
                : 'bg-white border-gray-200 hover:bg-gray-50'
                }`}>
                <input
                  type="radio"
                  name="recipientType"
                  value="engineer"
                  checked={recipientType === 'engineer'}
                  onChange={(e) => setRecipientType(e.target.value)}
                  className="hidden"
                />
                <Users className="w-5 h-5" />
                <span className="font-medium">Engineer</span>
              </label>

              <label className={`flex-1 flex items-center justify-center gap-2 p-3 rounded-lg border cursor-pointer transition ${recipientType === 'customer'
                ? 'bg-primary-50 border-primary-500 text-primary-700'
                : 'bg-white border-gray-200 hover:bg-gray-50'
                }`}>
                <input
                  type="radio"
                  name="recipientType"
                  value="customer"
                  checked={recipientType === 'customer'}
                  onChange={(e) => setRecipientType(e.target.value)}
                  className="hidden"
                />
                <User className="w-5 h-5" />
                <span className="font-medium">Customer</span>
              </label>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Recipient ID <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={recipientId}
              onChange={(e) => setRecipientId(e.target.value)}
              placeholder={`Enter ${recipientType === 'engineer' ? 'engineer' : 'customer'} ID...`}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none font-mono text-sm"
              required
            />
            <p className="mt-1 text-xs text-gray-500">
              Enter the unique UUID of the {recipientType} you wish to notify.
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Title <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter notification title..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Message <span className="text-red-500">*</span>
            </label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Enter notification message..."
              rows={5}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none resize-none"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Urgency Level <span className="text-red-500">*</span>
            </label>
            <select
              value={urgency}
              onChange={(e) => setUrgency(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none"
              required
            >
              <option value="low">Low</option>
              <option value="medium">Med</option>
              <option value="high">High</option>
              <option value="critical">Critical</option>
            </select>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition"
              disabled={isSubmitting}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2 bg-primary-600 hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium rounded-lg transition flex items-center gap-2"
            >
              <Send className="w-4 h-4" />
              {isSubmitting ? 'Sending...' : 'Send Notification'}
            </button>
          </div>
        </form>
      </div>
    </div>,
    document.body
  );
}
