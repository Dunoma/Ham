import Layout from './Layout';
import { useEngineer } from '../context/EngineerContext';
import {
  LayoutDashboard,
  FileText,
  Bell,
  Users,
  User,
  Wrench,
} from 'lucide-react';

export default function EngineerLayout({ children }) {
  const { user, notifications } = useEngineer();

  const unreadNotificationsCount = notifications.filter((n) => !n.isRead).length;

  const menuItems = [
    { path: '/engineers/dashboard', icon: LayoutDashboard, label: 'Dashboard', badge: null },
    {
      path: '/engineers/reports',
      icon: FileText,
      label: 'Reports',
      badge: null,
    },
    {
      path: '/engineers/notifications',
      icon: Bell,
      label: 'Notifications',
      badge: unreadNotificationsCount > 0 ? unreadNotificationsCount : null,
    },
    {
      path: '/engineers/customers',
      icon: Users,
      label: 'Customers',
      badge: null,
    },
    {
      path: '/engineer/engineers',
      icon: Wrench,
      label: 'Engineers',
      badge: null,
    },
    { path: '/engineers/profile', icon: User, label: 'Profile', badge: null },
  ];

  return (
    <Layout menuItems={menuItems} user={user} profilePath="/engineers/profile">
      {children}
    </Layout>
  );
}

