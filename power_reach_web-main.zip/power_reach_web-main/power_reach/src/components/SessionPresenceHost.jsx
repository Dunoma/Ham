import { useEffect, useRef, useState, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { Clock, LogOut } from 'lucide-react';
import { authApi, AUTH_TOKENS_CLEARED_EVENT } from '../services/api';

/** Time to answer before we treat the session as abandoned (access token typically expires ~5 min after this prompt at T+25m). */
const RESPONSE_DEADLINE_MS = 3 * 60 * 1000;

export default function SessionPresenceHost() {
  const [open, setOpen] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(Math.ceil(RESPONSE_DEADLINE_MS / 1000));
  const resolveRef = useRef(null);
  const timeoutRef = useRef(null);
  const countdownRef = useRef(null);
  const settledRef = useRef(false);

  const clearTimers = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    if (countdownRef.current) {
      clearInterval(countdownRef.current);
      countdownRef.current = null;
    }
  }, []);

  const settle = useCallback(
    (value) => {
      if (settledRef.current) return;
      settledRef.current = true;
      clearTimers();
      const resolve = resolveRef.current;
      resolveRef.current = null;
      setOpen(false);
      resolve?.(value);
    },
    [clearTimers]
  );

  useEffect(() => {
    const requestConfirmation = () =>
      new Promise((resolve) => {
        settledRef.current = false;
        resolveRef.current = resolve;
        setSecondsLeft(Math.ceil(RESPONSE_DEADLINE_MS / 1000));
        setOpen(true);

        timeoutRef.current = setTimeout(() => {
          settle(false);
        }, RESPONSE_DEADLINE_MS);

        const started = Date.now();
        countdownRef.current = setInterval(() => {
          const elapsed = Date.now() - started;
          const left = Math.max(0, Math.ceil((RESPONSE_DEADLINE_MS - elapsed) / 1000));
          setSecondsLeft(left);
        }, 1000);
      });

    authApi.registerSessionPresence(requestConfirmation);

    const onTokensCleared = () => {
      if (resolveRef.current) settle(false);
    };
    window.addEventListener(AUTH_TOKENS_CLEARED_EVENT, onTokensCleared);

    return () => {
      clearTimers();
      window.removeEventListener(AUTH_TOKENS_CLEARED_EVENT, onTokensCleared);
      authApi.clearSessionPresence();
    };
  }, [clearTimers, settle]);

  const handleContinue = () => settle(true);
  const handleSignOut = () => settle(false);

  if (!open) return null;

  return createPortal(
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/50 p-4">
      <div
        className="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden animate-fade-in-up"
        role="dialog"
        aria-modal="true"
        aria-labelledby="session-presence-title"
        aria-describedby="session-presence-desc"
      >
        <div className="p-6 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-amber-100 flex items-center justify-center text-amber-700">
              <Clock className="w-6 h-6" aria-hidden />
            </div>
            <div>
              <h2 id="session-presence-title" className="text-lg font-bold text-gray-900">
                Are you still there?
              </h2>
              <p id="session-presence-desc" className="text-sm text-gray-600 mt-0.5">
                For your security, confirm you are still using this session. Otherwise you will be signed out.
              </p>
            </div>
          </div>
        </div>
        <div className="px-6 py-3 bg-amber-50 border-b border-amber-100">
          <p className="text-sm text-amber-900 text-center font-medium">
            Time remaining: {secondsLeft}s
          </p>
        </div>
        <div className="p-6 flex flex-col sm:flex-row gap-3 sm:justify-end">
          <button
            type="button"
            onClick={handleSignOut}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 font-medium"
          >
            <LogOut className="w-4 h-4" />
            Sign out
          </button>
          <button
            type="button"
            onClick={handleContinue}
            className="px-4 py-2.5 rounded-lg bg-primary-600 text-white hover:bg-primary-700 font-medium shadow-sm"
          >
            Yes, continue session
          </button>
        </div>
      </div>
    </div>,
    document.body
  );
}
