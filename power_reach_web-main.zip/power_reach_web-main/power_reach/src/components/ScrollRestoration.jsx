import { useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';

// Store scroll positions in sessionStorage
const SCROLL_POSITIONS_KEY = 'power_reach_scroll_positions';
const VISITED_PAGES_KEY = 'power_reach_visited_pages';

function getScrollPositions() {
  try {
    const stored = sessionStorage.getItem(SCROLL_POSITIONS_KEY);
    return stored ? JSON.parse(stored) : {};
  } catch {
    return {};
  }
}

function getVisitedPages() {
  try {
    const stored = sessionStorage.getItem(VISITED_PAGES_KEY);
    return stored ? new Set(JSON.parse(stored)) : new Set();
  } catch {
    return new Set();
  }
}

function saveScrollPosition(pathname, position) {
  try {
    const positions = getScrollPositions();
    positions[pathname] = position;
    sessionStorage.setItem(SCROLL_POSITIONS_KEY, JSON.stringify(positions));
  } catch (error) {
    console.error('Failed to save scroll position:', error);
  }
}

function markPageAsVisited(pathname) {
  try {
    const visited = getVisitedPages();
    visited.add(pathname);
    sessionStorage.setItem(VISITED_PAGES_KEY, JSON.stringify(Array.from(visited)));
  } catch (error) {
    console.error('Failed to mark page as visited:', error);
  }
}

function getScrollPosition(pathname) {
  const positions = getScrollPositions();
  return positions[pathname] ?? null;
}

function hasVisitedPage(pathname) {
  const visited = getVisitedPages();
  return visited.has(pathname);
}

export default function ScrollRestoration() {
  const { pathname } = useLocation();
  const scrollTimeoutRef = useRef(null);
  const isRestoringRef = useRef(false);

  useEffect(() => {
    // Find the main content element (the scrollable container in Layout)
    const findScrollContainer = () => {
      return document.querySelector('main') || window;
    };

    const hasVisited = hasVisitedPage(pathname);
    const savedPosition = getScrollPosition(pathname);

    // Small delay to ensure content is rendered
    const restoreScroll = () => {
      const scrollContainer = findScrollContainer();
      if (!scrollContainer) return;

      isRestoringRef.current = true;

      if (hasVisited && savedPosition !== null && savedPosition > 0) {
        // Restore saved position for previously visited pages
        if (scrollContainer === window) {
          window.scrollTo({ top: savedPosition, behavior: 'auto' });
        } else {
          scrollContainer.scrollTop = savedPosition;
        }
      } else {
        // New page - scroll to top
        if (scrollContainer === window) {
          window.scrollTo({ top: 0, behavior: 'auto' });
        } else {
          scrollContainer.scrollTop = 0;
        }
        // Mark as visited
        markPageAsVisited(pathname);
      }

      // Reset flag after a short delay
      setTimeout(() => {
        isRestoringRef.current = false;
      }, 300);
    };

    // Use multiple attempts to ensure DOM is ready
    requestAnimationFrame(() => {
      restoreScroll();
      // Try again after a short delay in case content loads asynchronously
      setTimeout(restoreScroll, 100);
    });

    // Set up scroll listener
    const scrollContainer = findScrollContainer();
    if (!scrollContainer) return;

    // Save scroll position when scrolling (but not during restoration)
    const handleScroll = () => {
      if (isRestoringRef.current) return;

      // Debounce scroll saving
      if (scrollTimeoutRef.current) {
        clearTimeout(scrollTimeoutRef.current);
      }
      scrollTimeoutRef.current = setTimeout(() => {
        const currentContainer = findScrollContainer();
        if (currentContainer) {
          const scrollTop =
            currentContainer === window
              ? window.pageYOffset || document.documentElement.scrollTop
              : currentContainer.scrollTop;
          saveScrollPosition(pathname, scrollTop);
        }
      }, 150);
    };

    scrollContainer.addEventListener('scroll', handleScroll, { passive: true });

    // Save scroll position when leaving the page
    return () => {
      scrollContainer.removeEventListener('scroll', handleScroll);
      if (scrollTimeoutRef.current) {
        clearTimeout(scrollTimeoutRef.current);
      }
      // Save final scroll position
      const finalContainer = findScrollContainer();
      if (finalContainer) {
        const scrollTop =
          finalContainer === window
            ? window.pageYOffset || document.documentElement.scrollTop
            : finalContainer.scrollTop;
        saveScrollPosition(pathname, scrollTop);
      }
    };
  }, [pathname]);

  return null;
}

