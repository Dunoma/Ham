import Layout from './Layout';
import { useAgent } from '../context/AgentContext';
import {
  LayoutDashboard,
  FileText,
  MessageSquare,
  User,
  Wrench,
  Bell,
} from 'lucide-react';

export default function AgentLayout({ children }) {
  const { user, unreadMessagesCount, pendingReportsCount } = useAgent();

  const menuItems = [
    { path: '/agent/dashboard', icon: LayoutDashboard, label: 'Dashboard', badge: null, exact: true },
    {
      path: '/agent/reports',
      icon: FileText,
      label: 'Reports',
      badge: pendingReportsCount > 0 ? pendingReportsCount : null,
    },
    {
      path: '/agent/messages',
      icon: MessageSquare,
      label: 'Messages',
      badge: unreadMessagesCount > 0 ? unreadMessagesCount : null,
    },
    {
      path: '/agent/engineers',
      icon: Wrench,
      label: 'Engineers',
      badge: null,
    },
    { path: '/agent/notifications', icon: Bell, label: 'Notifications', badge: null },
    { path: '/agent/profile', icon: User, label: 'Profile', badge: null },
  ];

  return (
    <Layout menuItems={menuItems} user={user} profilePath="/agent/profile">
      {children}
    </Layout>
  );
}

