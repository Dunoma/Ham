import { useNavigate } from 'react-router-dom';

export default function UserAvatar({ userId, userName, profilePicture, size = 'md', onClick }) {
  const navigate = useNavigate();

  const getInitials = (name) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const sizeClasses = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-12 h-12 text-base',
  };

  const handleClick = (e) => {
    e.stopPropagation();
    if (onClick) {
      onClick();
    } else if (userId) {
      // Navigate to user profile - you can implement a user profile page or modal
      // For now, we'll just prevent default and let parent handle it
    }
  };

  return (
    <div
      onClick={handleClick}
      className={`${sizeClasses[size]} rounded-full flex items-center justify-center text-white font-semibold cursor-pointer hover:opacity-90 transition ${
        profilePicture ? '' : 'bg-primary-600 hover:bg-primary-700'
      }`}
      title={userName}
    >
      {profilePicture ? (
        <img
          src={profilePicture}
          alt={userName}
          className={`${sizeClasses[size]} rounded-full object-cover`}
          onError={(e) => {
            e.target.style.display = 'none';
            const fallback = e.target.nextElementSibling;
            if (fallback) fallback.style.display = 'flex';
          }}
        />
      ) : null}
      <div
        className={`${sizeClasses[size]} bg-primary-600 rounded-full flex items-center justify-center ${profilePicture ? 'hidden' : ''}`}
      >
        {getInitials(userName)}
      </div>
    </div>
  );
}
