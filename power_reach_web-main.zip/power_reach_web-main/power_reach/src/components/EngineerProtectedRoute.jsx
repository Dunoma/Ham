import { Navigate } from 'react-router-dom';
import { useEngineer } from '../context/EngineerContext';

export default function EngineerProtectedRoute({ children }) {
  const { isAuthenticated, user, loading } = useEngineer();

  const userType = user?.role || user?.user_type;
  const isEngineer = userType === 'engineer';

  if (loading) {
    return null;
  }

  if (!isAuthenticated || !isEngineer) {
    return <Navigate to="/engineers/login" replace />;
  }

  return children;
}

