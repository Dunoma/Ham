import { useState } from 'react';
import { X, User, Mail, Phone, MapPin, Copy, Check } from 'lucide-react';

export default function EngineerProfileModal({ engineer, onClose }) {
  const [copied, setCopied] = useState(false);

  const handleCopyId = async () => {
    try {
      await navigator.clipboard.writeText(engineer.id);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  if (!engineer) {
    return null;
  }

  return (
    <div className="fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]" style={{ margin: 0, padding: 0 }}>
      <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 m-4">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Engineer Profile</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="flex items-center gap-4">
            {engineer.profile_picture ? (
              <img
                src={engineer.profile_picture}
                alt={engineer.name}
                className="w-20 h-20 rounded-full object-cover"
                onError={(e) => {
                  e.target.style.display = 'none';
                  const fallback = e.target.nextElementSibling;
                  if (fallback) fallback.style.display = 'flex';
                }}
              />
            ) : null}
            <div
              className={`w-20 h-20 bg-primary-600 rounded-full flex items-center justify-center text-white font-bold text-xl ${engineer.profile_picture ? 'hidden' : ''
                }`}
            >
              {engineer.name
                .split(' ')
                .map((n) => n[0])
                .join('')
                .toUpperCase()
                .slice(0, 2)}
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">{engineer.name}</h3>
              <p className="text-gray-600">{engineer.specialization}</p>
            </div>
          </div>

          <div className="space-y-3 pt-4 border-t border-gray-200">
            <div className="flex items-center gap-3">
              <User className="w-5 h-5 text-gray-400" />
              <div className="flex-1">
                <p className="text-sm text-gray-500">Name</p>
                <div className="flex items-center gap-2">
                  <p className="font-medium text-gray-900">{engineer.name}</p>
                  <button
                    onClick={handleCopyId}
                    className="p-1 hover:bg-gray-100 rounded transition"
                    title="Copy Engineer ID"
                  >
                    {copied ? (
                      <Check className="w-4 h-4 text-green-600" />
                    ) : (
                      <Copy className="w-4 h-4 text-gray-400" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-5 h-5 flex items-center justify-center">
                <span className="text-xs font-mono text-gray-400">ID</span>
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-500">UUID</p>
                <p className="font-mono text-sm text-gray-900">{engineer.id}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Phone className="w-5 h-5 text-gray-400" />
              <div className="flex-1">
                <p className="text-sm text-gray-500">Phone</p>
                <p className="font-medium text-gray-900">{engineer.phone}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Mail className="w-5 h-5 text-gray-400" />
              <div className="flex-1">
                <p className="text-sm text-gray-500">Email</p>
                <p className="font-medium text-gray-900">{engineer.email}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <MapPin className="w-5 h-5 text-gray-400" />
              <div className="flex-1">
                <p className="text-sm text-gray-500">Location</p>
                <p className="font-medium text-gray-900">{engineer.location}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

