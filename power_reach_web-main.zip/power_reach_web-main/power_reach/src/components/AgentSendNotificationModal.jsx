import { useState } from 'react';
import { createPortal } from 'react-dom';
import { X, Send, User, Users, MapPin, Globe, CheckCircle } from 'lucide-react';
import { useAgent } from '../context/AgentContext';

const abujaLocations = ['Wuse II', 'Gwarimpa', 'Jabi', 'Maitama', 'Asokoro'];

export default function AgentSendNotificationModal({ onClose, onSuccess }) {
    const { sendNotification, users } = useAgent();
    const [title, setTitle] = useState('');
    const [message, setMessage] = useState('');
    const [urgency, setUrgency] = useState('medium');
    const [targetAudience, setTargetAudience] = useState('single'); // single, multiple, location, all

    // Dynamic inputs
    const [recipientId, setRecipientId] = useState('');
    const [recipientIds, setRecipientIds] = useState('');
    const [location, setLocation] = useState('');

    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        if (!title.trim()) {
            setError('Title is required');
            return;
        }

        if (!message.trim()) {
            setError('Message is required');
            return;
        }

        let recipients = [];

        // Determine recipients based on target audience
        if (targetAudience === 'single') {
            if (!recipientId.trim()) {
                setError('Customer ID is required');
                return;
            }
            recipients = [recipientId.trim()];
        } else if (targetAudience === 'multiple') {
            if (!recipientIds.trim()) {
                setError('Customer IDs are required');
                return;
            }
            // Split by comma, trim, and remove empty strings
            recipients = recipientIds.split(',').map(id => id.trim()).filter(id => id);
        } else if (targetAudience === 'location') {
            if (!location) {
                setError('Location is required');
                return;
            }
            // Filter users by location
            recipients = users
                .filter(user => user.location === location)
                .map(user => user.readableId || user.id);

            if (recipients.length === 0) {
                setError(`No customers found in ${location}`);
                return;
            }
        } else if (targetAudience === 'all') {
            recipients = users.map(user => user.readableId || user.id);
            if (recipients.length === 0) {
                setError('No customers found');
                return;
            }
        }

        setIsSubmitting(true);

        try {
            // Send notifications sequentially (in a real app, this would be a single batch API call)
            const promises = recipients.map(id =>
                sendNotification({
                    title: title.trim(),
                    message: message.trim(),
                    urgency,
                    recipientId: id,
                    recipientType: 'customer',
                })
            );

            await Promise.all(promises);

            if (onSuccess) {
                onSuccess(recipients.length);
            }

            setIsSuccess(true);

            // Auto close after 1.5 seconds
            setTimeout(() => {
                onClose();
            }, 1500);
        } catch (error) {
            console.error('Error sending notification:', error);
            setError('Failed to send notification. Please try again.');
            setIsSubmitting(false);
        }
    };

    if (isSuccess) {
        return createPortal(
            <div className="fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]" style={{ margin: 0, padding: 0 }}>
                <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-8 flex flex-col items-center animate-fade-in-up">
                    <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-4 animate-bounce-short">
                        <CheckCircle className="w-10 h-10 text-green-600" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Notification Sent!</h3>
                    <p className="text-gray-500 text-center">Your message has been delivered successfully.</p>
                </div>
            </div>,
            document.body
        );
    }

    return createPortal(
        <div className="fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]" style={{ margin: 0, padding: 0 }}>
            {/* Increased z-index to ensure it sits above everything including sticky headers */}
            <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto m-4 relative z-[10000]">
                <div className="flex items-center justify-between p-6 border-b border-gray-200">
                    <h2 className="text-2xl font-bold text-gray-900">Send Notification</h2>
                    <button
                        onClick={onClose}
                        className="p-2 hover:bg-gray-100 rounded-lg transition"
                    >
                        <X className="w-5 h-5" />
                    </button>
                </div>

                <form onSubmit={handleSubmit} className="p-6 space-y-6">
                    {error && (
                        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                            {error}
                        </div>
                    )}

                    {/* Target Audience Selector */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-3">
                            Target Audience
                        </label>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <button
                                type="button"
                                onClick={() => setTargetAudience('single')}
                                className={`flex flex-col items-center justify-center gap-2 p-3 rounded-lg border transition ${targetAudience === 'single'
                                        ? 'bg-primary-50 border-primary-500 text-primary-700 ring-1 ring-primary-500'
                                        : 'bg-white border-gray-200 hover:bg-gray-50 text-gray-600'
                                    }`}
                            >
                                <User className="w-5 h-5" />
                                <span className="text-sm font-medium">Single</span>
                            </button>

                            <button
                                type="button"
                                onClick={() => setTargetAudience('multiple')}
                                className={`flex flex-col items-center justify-center gap-2 p-3 rounded-lg border transition ${targetAudience === 'multiple'
                                        ? 'bg-primary-50 border-primary-500 text-primary-700 ring-1 ring-primary-500'
                                        : 'bg-white border-gray-200 hover:bg-gray-50 text-gray-600'
                                    }`}
                            >
                                <Users className="w-5 h-5" />
                                <span className="text-sm font-medium">Multiple</span>
                            </button>

                            <button
                                type="button"
                                onClick={() => setTargetAudience('location')}
                                className={`flex flex-col items-center justify-center gap-2 p-3 rounded-lg border transition ${targetAudience === 'location'
                                        ? 'bg-primary-50 border-primary-500 text-primary-700 ring-1 ring-primary-500'
                                        : 'bg-white border-gray-200 hover:bg-gray-50 text-gray-600'
                                    }`}
                            >
                                <MapPin className="w-5 h-5" />
                                <span className="text-sm font-medium">Location</span>
                            </button>

                            <button
                                type="button"
                                onClick={() => setTargetAudience('all')}
                                className={`flex flex-col items-center justify-center gap-2 p-3 rounded-lg border transition ${targetAudience === 'all'
                                        ? 'bg-primary-50 border-primary-500 text-primary-700 ring-1 ring-primary-500'
                                        : 'bg-white border-gray-200 hover:bg-gray-50 text-gray-600'
                                    }`}
                            >
                                <Globe className="w-5 h-5" />
                                <span className="text-sm font-medium">All</span>
                            </button>
                        </div>
                    </div>

                    {/* Dynamic Inputs based on Audience */}
                    {targetAudience === 'single' && (
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                Customer ID <span className="text-red-500">*</span>
                            </label>
                            <input
                                type="text"
                                value={recipientId}
                                onChange={(e) => setRecipientId(e.target.value)}
                                placeholder="Enter Customer ID (e.g. CU-1001)..."
                                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none font-mono text-sm"
                                required
                            />
                        </div>
                    )}

                    {targetAudience === 'multiple' && (
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                Customer IDs <span className="text-red-500">*</span>
                            </label>
                            <textarea
                                value={recipientIds}
                                onChange={(e) => setRecipientIds(e.target.value)}
                                placeholder="Enter Customer IDs separated by commas (e.g. CU-1001, CU-1002)..."
                                rows={2}
                                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none font-mono text-sm resize-none"
                                required
                            />
                            <p className="mt-1 text-xs text-gray-500">Separate multiple IDs with commas.</p>
                        </div>
                    )}

                    {targetAudience === 'location' && (
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                Select Location <span className="text-red-500">*</span>
                            </label>
                            <select
                                value={location}
                                onChange={(e) => setLocation(e.target.value)}
                                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none"
                                required
                            >
                                <option value="">Select a location...</option>
                                {abujaLocations.map(loc => (
                                    <option key={loc} value={loc}>{loc}</option>
                                ))}
                            </select>
                        </div>
                    )}

                    {targetAudience === 'all' && (
                        <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 flex items-start gap-3">
                            <Globe className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                            <div>
                                <p className="text-sm font-medium text-blue-900">Broadcast Message</p>
                                <p className="text-sm text-blue-700 mt-1">
                                    This notification will be sent to <strong>all registered customers</strong>. Please use this feature responsibly for important announcements.
                                </p>
                            </div>
                        </div>
                    )}

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                            Title <span className="text-red-500">*</span>
                        </label>
                        <input
                            type="text"
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                            placeholder="Enter notification title..."
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none"
                            required
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                            Message <span className="text-red-500">*</span>
                        </label>
                        <textarea
                            value={message}
                            onChange={(e) => setMessage(e.target.value)}
                            placeholder="Enter notification message..."
                            rows={5}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none resize-none"
                            required
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                            Urgency Level <span className="text-red-500">*</span>
                        </label>
                        <select
                            value={urgency}
                            onChange={(e) => setUrgency(e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none"
                            required
                        >
                            <option value="low">Low</option>
                            <option value="medium">Med</option>
                            <option value="high">High</option>
                            <option value="critical">Critical</option>
                        </select>
                    </div>

                    <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200">
                        <button
                            type="button"
                            onClick={onClose}
                            className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition"
                            disabled={isSubmitting}
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            disabled={isSubmitting}
                            className="px-6 py-2 bg-primary-600 hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium rounded-lg transition flex items-center gap-2"
                        >
                            <Send className="w-4 h-4" />
                            {isSubmitting ? 'Sending...' : 'Send Notification'}
                        </button>
                    </div>
                </form>
            </div>
        </div>,
        document.body
    );
}
