import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  FileText,
  MessageSquare,
  User,
  ChevronLeft,
  ChevronRight,
  Wrench,
  ArrowLeft,
  Bell,
  Users,
  Menu,
  X as CloseIcon,
} from 'lucide-react';

// Logo will be handled with onError fallback

export default function Layout({ children, menuItems, user, profilePath }) {
  const [sidebarOpen, setSidebarOpen] = useState(window.innerWidth >= 768);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setSidebarOpen(true);
      } else {
        setSidebarOpen(false);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (window.innerWidth < 768) {
      setSidebarOpen(false);
    }
  }, [location.pathname]);

  const getInitials = (name) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden relative">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-20 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed md:relative inset-y-0 left-0 z-30 bg-white border-r border-gray-200 transition-all duration-300 flex flex-col ${
          sidebarOpen ? 'translate-x-0 w-64' : '-translate-x-full md:translate-x-0 md:w-20'
        }`}
      >
        {/* Logo */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-gray-200">
          {sidebarOpen ? (
            <div className="flex items-center flex-1">
              <img
                src="/Power Reach Logo.png"
                alt="Power Reach"
                className="h-8 w-auto object-contain"
                onError={(e) => {
                  e.target.style.display = 'none';
                  e.target.nextSibling.style.display = 'flex';
                }}
              />
              <div className="h-8 w-8 bg-primary-600 rounded-lg flex items-center justify-center hidden">
                <span className="text-white font-bold text-sm">PR</span>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center">
              <div className="w-8 h-8 bg-white border-2 border-primary-900 rounded-lg flex items-center justify-center">
                <span className="text-primary-900 font-bold text-xs">P</span>
                <span className="text-yellow-600 font-bold text-xs">R</span>
              </div>
            </div>
          )}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:bg-gray-100 rounded-lg transition hidden md:block"
          >
            {sidebarOpen ? (
              <ChevronLeft className="w-5 h-5" />
            ) : (
              <ChevronRight className="w-5 h-5" />
            )}
          </button>
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:bg-gray-100 rounded-lg transition md:hidden"
          >
            <CloseIcon className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 space-y-1">
          {menuItems && menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = item.exact
              ? location.pathname === item.path
              : location.pathname === item.path ||
              location.pathname.startsWith(item.path + '/');
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition ${isActive
                  ? 'bg-primary-50 text-primary-700 font-medium'
                  : 'text-gray-700 hover:bg-gray-50'
                  }`}
              >
                <div className="relative">
                  <Icon className="w-5 h-5" />
                  {item.badge && (
                    <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
                      <span className="text-[10px] text-white font-bold">{item.badge}</span>
                    </span>
                  )}
                </div>
                {sidebarOpen && <span>{item.label}</span>}
              </Link>
            );
          })}
        </nav>

        {/* User Section */}
        {user && profilePath && (
          <div className="border-t border-gray-200 p-4">
            <Link
              to={profilePath}
              className={`flex items-center gap-3 mb-3 ${sidebarOpen ? '' : 'justify-center'
                }`}
            >
              {user?.profile_picture ? (
                <img
                  src={user.profile_picture}
                  alt={user.name}
                  className="w-10 h-10 rounded-full object-cover"
                  onError={(e) => {
                    e.target.style.display = 'none';
                    const fallback = e.target.nextElementSibling;
                    if (fallback) fallback.style.display = 'flex';
                  }}
                />
              ) : null}
              <div
                className={`w-10 h-10 bg-primary-600 rounded-full flex items-center justify-center text-white font-semibold ${user?.profile_picture ? 'hidden' : ''
                  }`}
              >
                {user ? getInitials(user.name) : 'A'}
              </div>
              {sidebarOpen && user && (
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">{user.name}</p>
                  <p className="text-xs text-gray-500 truncate">{user.email}</p>
                </div>
              )}
            </Link>
          </div>
        )}
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col w-full h-screen overflow-hidden relative">
        
        {/* Mobile Header Menu */}
        <div className="md:hidden flex-none h-16 bg-white border-b border-gray-200 flex items-center justify-between px-4">
          <div className="flex items-center">
            <img src="/Power Reach Logo.png" alt="Power Reach" className="h-8 w-auto object-contain" />
          </div>
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-2 hover:bg-gray-100 rounded-lg transition"
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>

        <div className="flex-1 overflow-auto">
          {/* Back Button - Show on all pages except dashboard and chat view */}
          {location.pathname !== '/agent/dashboard' &&
            location.pathname !== '/engineers/dashboard' &&
            location.pathname !== '/admin/dashboard' &&
            !location.pathname.startsWith('/agent/messages/') &&
            !location.pathname.startsWith('/engineers/messages/') && (
              <div className="sticky top-0 z-10 bg-white border-b border-gray-200 px-6 py-3">
                <button
                  onClick={() => navigate(-1)}
                  className="flex items-center gap-2 text-gray-700 hover:text-primary-600 transition"
                >
                  <ArrowLeft className="w-5 h-5" />
                  <span>Back</span>
                </button>
              </div>
            )}
          {children}
        </div>
      </main>
    </div>
  );
}
