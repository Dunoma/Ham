import { useState } from 'react';
import { X, FileText } from 'lucide-react';
import { useAgent } from '../context/AgentContext';
import { useNavigate } from 'react-router-dom';

export default function ReportFormModal({ onClose, prefillData = null, onSuccess }) {
  const { users, addReport } = useAgent();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    userId: prefillData?.userId || '',
    title: prefillData?.title || '',
    description: prefillData?.description || '',
    priority: 'medium',
    faultType: prefillData?.faultType || 'Power Outage',
    isSparkyReport: prefillData?.isSparkyReport || false,
  });

  const faultTypes = [
    'Power Outage',
    'Faulty Transformer',
    'Meter Issue',
    'Safety Hazard',
    'Low Voltage',
    'Vandalism',
    'Other'
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.userId || !formData.title || !formData.description) {
      alert('Please fill in all required fields');
      return;
    }

    try {
      const selectedUser = users.find((u) => u.id === formData.userId || u.readableId === formData.userId);
      if (!selectedUser) {
        alert('User not found');
        return;
      }

      const newReport = await addReport({
        ...formData,
        userId: selectedUser.id,
        userName: selectedUser.name,
        userLocation: selectedUser.location,
      });

      console.log('newReport', newReport);

      onClose();
      if (onSuccess) {
        onSuccess();
      } else {
        navigate(`/agent/reports`);
      }
    } catch (error) {
      alert('Failed to create report. Please try again.');
    }
  };

  return (
    <div className="fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]" style={{ margin: 0, padding: 0 }}>
      <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto m-4">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">File New Report</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Customer ID Input */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Customer ID <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={formData.userId}
              onChange={(e) => setFormData({ ...formData, userId: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none font-mono text-sm"
              placeholder="Enter Customer UUID or Readable ID"
              required
            />
            <p className="text-xs text-gray-500 mt-1">Paste the customer's ID here</p>
          </div>

          {/* Fault Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Fault Type <span className="text-red-500">*</span>
            </label>
            <select
              value={formData.faultType}
              onChange={(e) => setFormData({ ...formData, faultType: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none"
              required
            >
              {faultTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </div>

          {/* Title */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Report Title <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none"
              placeholder="Enter report title"
              required
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Description <span className="text-red-500">*</span>
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={4}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none"
              placeholder="Enter detailed description"
              required
            />
          </div>

          {/* Priority */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Priority
            </label>
            <select
              value={formData.priority}
              onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none"
            >
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-6 py-2 rounded-lg transition"
            >
              <FileText className="w-5 h-5" />
              File Report
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
