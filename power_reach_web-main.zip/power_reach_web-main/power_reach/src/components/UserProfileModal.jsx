import { useState, useContext } from 'react';
import { createPortal } from 'react-dom';
import { X, User, Mail, Phone, MapPin, Copy, Check } from 'lucide-react';
import { AgentContext } from '../context/AgentContext';
import { EngineerContext } from '../context/EngineerContext';

export default function UserProfileModal({ userId, userData, onClose }) {
  // Both contexts are available in the app, so we can use both
  // Use whichever has the users data
  const agentContext = useContext(AgentContext);
  const engineerContext = useContext(EngineerContext);

  const users = [
    ...(agentContext?.users || []),
    ...(engineerContext?.customers || [])
  ];
  const [copied, setCopied] = useState(false);
  const user = userData || users.find((u) => u.id === userId);

  const handleCopyId = async () => {
    try {
      await navigator.clipboard.writeText(user.readableId || user.id);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  if (!user) {
    return null;
  }

  return createPortal(
    <div className="fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]" style={{ margin: 0, padding: 0 }}>
      <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 m-4">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900">User Profile</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 bg-primary-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
              {user.name
                .split(' ')
                .map((n) => n[0])
                .join('')
                .toUpperCase()
                .slice(0, 2)}
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">{user.name}</h3>
            </div>
          </div>

          <div className="space-y-3 pt-4 border-t border-gray-200">
            <div className="flex items-center gap-3">
              <User className="w-5 h-5 text-gray-400" />
              <div className="flex-1">
                <p className="text-sm text-gray-500">Name</p>
                <p className="font-medium text-gray-900">{user.name}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-5 h-5 flex items-center justify-center">
                <span className="text-xs font-mono text-gray-400">ID</span>
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-500">Customer ID</p>
                <div className="flex items-center gap-2">
                  <p className="font-mono text-sm text-gray-900">{user.readableId || user.id}</p>
                  <button
                    onClick={handleCopyId}
                    className="p-1 hover:bg-gray-100 rounded transition"
                    title="Copy ID"
                  >
                    {copied ? (
                      <Check className="w-4 h-4 text-green-600" />
                    ) : (
                      <Copy className="w-4 h-4 text-gray-400" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Phone className="w-5 h-5 text-gray-400" />
              <div className="flex-1">
                <p className="text-sm text-gray-500">Phone</p>
                <p className="font-medium text-gray-900">{user.phone}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Mail className="w-5 h-5 text-gray-400" />
              <div className="flex-1">
                <p className="text-sm text-gray-500">Email</p>
                <p className="font-medium text-gray-900">{user.email}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <MapPin className="w-5 h-5 text-gray-400" />
              <div className="flex-1">
                <p className="text-sm text-gray-500">Location</p>
                <p className="font-medium text-gray-900">{user.location}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
}

