import { useState } from 'react';
import { X, Send, Users, MapPin, Radio } from 'lucide-react';
import { useAgent } from '../context/AgentContext';

const abujaLocations = ['Wuse II', 'Gwarimpa', 'Jabi', 'Maitama', 'Asokoro'];

export default function NotificationModal({ onClose, onSuccess }) {
  const { users, addNotification } = useAgent();
  const [targetType, setTargetType] = useState('broadcast'); // broadcast, single, multiple, location
  const [singleUserId, setSingleUserId] = useState('');
  const [multipleUserIds, setMultipleUserIds] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title || !message) {
      alert('Please fill in both title and message');
      return;
    }

    let targetUsers = [];
    if (targetType === 'broadcast') {
      targetUsers = users.map((u) => u.id);
    } else if (targetType === 'single') {
      if (!singleUserId.trim()) {
        alert('Please enter a Customer UUID');
        return;
      }
      targetUsers = [singleUserId.trim()];
    } else if (targetType === 'multiple') {
      if (!multipleUserIds.trim()) {
        alert('Please enter Customer UUIDs');
        return;
      }
      targetUsers = multipleUserIds
        .split(',')
        .map((id) => id.trim())
        .filter((id) => id.length > 0);
    } else if (targetType === 'location') {
      if (!selectedLocation) {
        alert('Please select a location');
        return;
      }
      targetUsers = users.filter((u) => u.location === selectedLocation).map((u) => u.id);
    }

    if (targetUsers.length === 0) {
      alert('Please select at least one target');
      return;
    }

    targetUsers.forEach((userId) => {
      addNotification({
        userId,
        title,
        message,
        type: 'broadcast',
        createdAt: new Date().toISOString(),
      });
    });

    onClose();
    if (onSuccess) {
      onSuccess();
    }
  };

  return (
    <div className="fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]" style={{ margin: 0, padding: 0 }}>
      <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto m-4">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">Send Notification</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Target Type Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Target Audience
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setTargetType('broadcast')}
                className={`p-4 border-2 rounded-lg transition ${targetType === 'broadcast'
                    ? 'border-primary-600 bg-primary-50'
                    : 'border-gray-200 hover:border-gray-300'
                  }`}
              >
                <Radio className="w-6 h-6 mx-auto mb-2 text-primary-600" />
                <span className="font-medium">Broadcast All</span>
              </button>
              <button
                type="button"
                onClick={() => setTargetType('single')}
                className={`p-4 border-2 rounded-lg transition ${targetType === 'single'
                    ? 'border-primary-600 bg-primary-50'
                    : 'border-gray-200 hover:border-gray-300'
                  }`}
              >
                <Users className="w-6 h-6 mx-auto mb-2 text-primary-600" />
                <span className="font-medium">Single User</span>
              </button>
              <button
                type="button"
                onClick={() => setTargetType('multiple')}
                className={`p-4 border-2 rounded-lg transition ${targetType === 'multiple'
                    ? 'border-primary-600 bg-primary-50'
                    : 'border-gray-200 hover:border-gray-300'
                  }`}
              >
                <Users className="w-6 h-6 mx-auto mb-2 text-primary-600" />
                <span className="font-medium">Multiple Users</span>
              </button>
              <button
                type="button"
                onClick={() => setTargetType('location')}
                className={`p-4 border-2 rounded-lg transition ${targetType === 'location'
                    ? 'border-primary-600 bg-primary-50'
                    : 'border-gray-200 hover:border-gray-300'
                  }`}
              >
                <MapPin className="w-6 h-6 mx-auto mb-2 text-primary-600" />
                <span className="font-medium">Specific Location</span>
              </button>
            </div>
          </div>

          {/* Single User UUID Input */}
          {targetType === 'single' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Customer UUID
              </label>
              <input
                type="text"
                value={singleUserId}
                onChange={(e) => setSingleUserId(e.target.value)}
                placeholder="Paste Customer UUID here"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none font-mono text-sm"
              />
            </div>
          )}

          {/* Multiple Users UUID Input */}
          {targetType === 'multiple' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Customer UUIDs (comma-separated)
              </label>
              <input
                type="text"
                value={multipleUserIds}
                onChange={(e) => setMultipleUserIds(e.target.value)}
                placeholder="Paste comma-separated Customer UUIDs here"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none font-mono text-sm"
              />
            </div>
          )}

          {/* Location Selection */}
          {targetType === 'location' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Select Location
              </label>
              <select
                value={selectedLocation}
                onChange={(e) => setSelectedLocation(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none"
              >
                <option value="">Choose a location...</option>
                {abujaLocations.map((location) => (
                  <option key={location} value={location}>
                    {location}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Title */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Notification Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none"
              placeholder="Enter notification title"
              required
            />
          </div>

          {/* Message */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Message
            </label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={4}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none"
              placeholder="Enter notification message"
              required
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-6 py-2 rounded-lg transition"
            >
              <Send className="w-5 h-5" />
              Send Notification
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
