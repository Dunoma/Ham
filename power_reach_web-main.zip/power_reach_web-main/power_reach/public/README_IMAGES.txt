IMPORTANT: Image Setup Required

Please add the following images to this public/ folder:

1. Power Reach Logo.png
   - The lightning bolt logo with dark blue curved shapes
   - This will be used in the sidebar and login page
   - Note: File name has spaces and capital letters

2. profile_picture.jpg  
   - The agent's headshot photo
   - This will be used as the profile picture

Once you add these images, the application will automatically display them.
If images are missing, fallback UI elements will be shown.
